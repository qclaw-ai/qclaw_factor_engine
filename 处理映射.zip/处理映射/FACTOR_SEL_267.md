# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_267  
因子名称: 杠杆比率  
分类: : 质量指标  
标签: : 流动性, 质量指标, 质量, 杠杆比率, 动量, 成长, 价值, 量化交易  
原始公式: \frac{\text{Total Liabilities}_{t}}{\text{Total Shareholders' Equity}_{t}}

\text{Total Liabilities}_{t}

\text{Total Shareholders' Equity}_{t}  
DSL公式: /\textTotal Liabilities_t\textTotal Shareholders' Equity_t
\textTotal Liabilities_t
\textTotal Shareholders' Equity_t  
描述: 负债权益比是衡量企业财务杠杆的重要指标。它揭示了企业资产的构成中，债权人提供的资金与股东提供的资金之间的比例关系。较高的负债权益比意味着企业更多的资金来源于债务，这可能增加企业的财务风险，因为企业需要支付利息并承担还款义务。当企业盈利能力下降或面临经济下行压力时，较高的负债水平可能导致违约风险增加。相反，较低的负债权益比则意味着企业主要依靠自有资本运营，财务结构更为稳健，偿债能力较强，债权人权益相...
因子类型: : 质量指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/quality/quality-debt-to-equity-ratio
