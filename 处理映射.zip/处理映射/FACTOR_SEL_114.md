# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_114  
因子名称: 资金流量指标  
分类: : 技术指标  
标签: : 流动性, 技术指标, 技术分析, 质量, 动量, 成长, 价值, 量化交易  
原始公式: TP = \frac{HIGH + LOW + CLOSE}{3}

MF = TP \times VOL

PF(N) = \sum_{i=1}^{N} IF(TP_i > TP_{i-1}, MF_i, 0)

NF(N) = \sum_{i=1}^{N} IF(TP_i \leq TP_{i-1}, MF_i, 0)

MR(N) = \frac{PF(N)}{NF(N)}

MFI(N) = 100 - \frac{100}{1 + MR(N)}

HIGH

LOW

CLOSE

VOL

参数说明：HIGHHIGHHIGH：最高价 (High Price)，表示在特定交易日内达到的最高成交价格。LOWLOWLOW:最低价 (Low Price)，表示在特定交易日内达到的最低成交价格。CLOSECLOSECLOSE:收盘价 (Close Price)，表示在特定交易日结束时最后一次的成交价格。VOLVOLVOL:成交量 (Volume)，表示在特定交易日内该资产的总成交量。TPTPTP:典型价格 (Typical Price)，是最高价、最低价和收盘价的平均值，用于代表该交易日的价格水平。MFMFMF:货币流量 (Money Flow)，是典型价格与成交量的乘积，表示该交易日的资金流动量。PF(N)PF(N)PF(N):N日内正向货币流量之和 (Positive Money Flow over N days)，表示在过去N个交易日内，当典型价格上涨时流入该资产的资金总和。这里用累加符号$\sum$表示求和。NF(N)NF(N)NF(N):N日内负向货币流量之和 (Negative Money Flow over N days)，表示在过去N个交易日内，当典型价格下跌或持平时流出该资产的资金总和。这里用累加符号$\sum$表示求和。MR(N)MR(N)MR(N):...  
DSL公式: TP = /high + low + close3
MF = TP * VOL
PF(N) = SUM_i=1**N IF(TP_i > TP_i-1, MF_i, 0)
NF(N) = SUM_i=1**N IF(TP_i <= TP_i-1, MF_i, 0)
MR(N) = /PF(N)NF(N)
MFI(N) = 100 - /1001 + MR(N)
high
low
close
VOL  
描述: 货币比率 MR(N):MR(N)=PF(N)NF(N) MR(N) = \frac{PF(N)}{NF(N)} MR(N)=NF(N)PF(N)​货币比率（MR(N)）是正向货币流量之和（PF(N)）与负向货币流量之和（NF(N)）的比值，用于衡量特定时期内买方和卖方力量的相对强弱。当MR(N)值大于1，则代表买方力量大于卖方力量，反之，则卖方力量大于买方力量。 蔡金资金流向指标 相对强弱指标 (...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/money-flow-index
