# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_297  
因子名称: 去杠杆经营性资产盈利收益率  
分类: : 基本面指标  
标签: : 去杠杆经营性资产盈利收益率, 流动性, 基本面指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: GrossProfit_{TTM}

OperatingAssetMarketValue

OperatingAssetMarketValue = MarketCapitalization + FinancialLiabilities - FinancialAssets

GrossProfit_{TTM}

OperatingAssetMarketValue

MarketCapitalization

FinancialLiabilities

FinancialAssets

参数说明：GrossProfitTTMGrossProfit_：{TTM}GrossProfitTTM​:为最近12个月的毛利润总额，使用滚动计算方式，可以更好地体现企业最近的盈利能力。OperatingAssetMarketValueOperatingAssetMarketValueOperatingAssetMarketValue:为经营性净资产市值，代表企业主要经营活动相关的资产的市场价值总和，计算方式为市值加上金融负债减去金融资产。MarketCapitalizationMarketCapitalizationMarketCapitalization:为企业的总市值，通常指流通在外的股票市场总价值。FinancialLiabilitiesFinancialLiabilitiesFinancialLiabilities:为企业的金融负债，主要包括有息负债等，这些负债与企业的金融活动直接相关，而非经营活动。FinancialAssetsFinancialAssetsFinancialAssets:为企业的金融资产，主要包括交易性金融资产等，这些资产与企业的金融活动直接相关，而非经营活动。 因子解释本因子是市盈率（PE）倒数的一种改进形式，通过引入经营性净资产市值和毛利润，有效地剔除了企业杠杆、非经营性资产以及可操纵费用的影响。具体而言：  
DSL公式: GrossProfit_TTM
OperatingAssetMarketValue
OperatingAssetMarketValue = MarketCapitalization + FinancialLiabilities - FinancialAssets
GrossProfit_TTM
OperatingAssetMarketValue
MarketCapitalization
FinancialLiabilities
FinancialAssets  
描述: 因子公式去杠杆经营性资产盈利收益率:最近12个月的毛利润 (TTM)GrossProfitTTM GrossProfit_{TTM} GrossProfitTTM​经营性净资产市值OperatingAssetMarketValue OperatingAssetMarketValue OperatingAssetMarketValue经营性净资产市值 = OperatingAssetMarketVa...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/profit-market-capitalization-ratio-after-deleveraging
