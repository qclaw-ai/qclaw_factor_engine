# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_085  
因子名称: 分析师一致预期市盈率倒数  
分类: : 基本面指标  
标签: : 流动性, 分析师一致预期市盈率倒数, 基本面指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: 一致预期EPS

股票价格  
DSL公式: 一致预期EPS
股票价格  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。朱剑涛. (2017). 分析师研报的数据特征与alpha. 东方证券 预期市盈率调整幅度 分析师一致预期EPS修正比率 一致预期PEG比率 分析师预期EPS调整幅度 市盈率相对盈利增长率 60日盈利市值比率变动 一致预期收益率 (Consensus Target Price Return) 每股盈余公积金 盈利率 ⚠️ 因子风险警告...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/consistent-eps
