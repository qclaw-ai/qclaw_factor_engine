# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_250  
因子名称: 时间序列动量 (TSMOM)  
分类: : 动量指标  
标签: : 流动性, 质量, 动量, tsmom, 成长, 价值, 量化交易, 时间序列动量  
原始公式: TSMOM_{m,i} = sign\left(\frac{1}{N}\sum_{j=1}^{12}\hat{r}_{m-j,i}\right) * \frac{\hat{r}_{m,i}}{\hat{\sigma}_{m,i}}

\hat{r}_{m,i} = r_{m,i} - \bar{r}_{m,i}

\bar{r}_{m,i} = \sum_{j=0}^{\infty}(1 - \delta) * \delta^{j} * r_{m-j,i}

\hat{\sigma}_{m,i} = \sqrt{\sum_{j=0}^{\infty}(1-\delta) * \delta^{j} * (r_{m-1-j,i} - \bar{r}_{m-1-j,i})^2}

\hat{r}_{m,i}

r_{m,i}

\bar{r}_{m,i}

\hat{\sigma}_{m,i}

\delta

参数说明：mmm：表示月份，用于标识时间序列数据中的特定时间点。iii:表示特定的股票，用于标识横截面数据中的特定个体。r^m,i\hat{r}_{m,i}r^m,i​:表示股票 $i$ 在第 $m$ 个月相对其自身历史收益的超额收益。它是当月实际收益 $r_{m,i}$ 与过去收益的指数移动平均值 $\bar{r}_{m,i}$ 的差值。超额收益旨在捕捉个股收益相对于自身历史水平的偏差。rm,ir_{m,i}rm,i​:表示股票 $i$ 在第 $m$ 个月的收益率，通常定义为该月股票价格变动的百分比。rˉm,i\bar{r}_{m,i}rˉm,i​:表示股票 $i$ 在第 $m$ 个月之前月份收益率的指数移动平均值，用于平滑收益率的时间序列，并消除噪音，捕捉潜在的趋势。其计算方法是对历史收益率进行加权平均，权重随着时间推移呈指数衰减，使得近期收益率对当前移动平均值的影响更大。σ^m,i\hat{\sigma}_{m,i}σ^m,i​:表示股票 $i$ 在第 $m$ 个月的收益率波动率，它是过去收益率与指数移动平均值偏差的加权平均的平方根，其中权重随着时间推移呈指数衰减。该指标衡量了收益率在一段时间内的变动程度，反映了股票的风险水平。δ\deltaδ:表示指数衰减系数，它是一个介于 0 和 1 之间的参数，决定了历史收益率对指数移动平均值的影响程度。越小的 $\delta$ 值表示历史收益率的衰减速度更快，使得移动平均值更关注近期收益率。NNN:表示用于计算过去收益均值的月数，此处为 12个月。$\frac{1}{N}\sum_{j=1}^{12}\hat{r}_{m-j,i}$  代表了过去12个月的超额收益均值。因子解释时间序列动量 (TSMOM) 因子通过分析个股自身历史收益率的趋势来预测未来收益。其核心思想是，如果过去一段时间内个股表现出正（负）的超额收益，那么该趋势在未来有可能会持续（尽管研究表明通常是反向的）。该因子首先计算过去12个月的超额收益的均值，并取其符号作为方向性指标。然后，使用当月的超额收益除以当月的波动率，进行标准化处理。这样做的目的是使动量信号更加稳健，并且降低了高波动股票的权重。因此，TSMOM 因子可以用于捕捉股票价格的短期反转效应，并构建相应的投资组合。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Moskowitz, T. J., Ooi, Y. H., & Pedersen, L. H.. (2012). Time series momentum. Journal of Financial Economics朱剑涛. (2017). 技术类新 Alpha 因子的批量测试. 东方证券Related Factors 月度收益季节性动量因子 多时域移动平均动量因子 过去K个月累计收益率动量因子 排序动量因子 CAPM残差动量因子 月度超额收益季节性反转因子 多周期标准化移动平均动量因子 系统偏度风险溢价因子 Fama-French三因子模型残差动量 因子公式时间...  
DSL公式: TSMOM_m,i = sign(/1NSUM_j=1**12\hatr_m-j,i) * /\hatr_m,i\hatsigma_m,i
\hatr_m,i = r_m,i - \barr_m,i
\barr_m,i = SUM_j=0**\infty(1 - delta) * delta**j * r_m-j,i
\hatsigma_m,i = SQRTSUM_j=0**\infty(1-delta) * delta**j * (r_m-1-j,i - \barr_m-1-j,i)**2
\hatr_m,i
r_m,i
\barr_m,i
\hatsigma_m,i
delta  
描述: 时间序列动量 (TSMOM)动量因子因子公式时间序列动量因子 (TSMOM):TSMOMm,i=sign(1N∑j=112r^m−j,i)∗r^m,iσ^m,i TSMOM_{m,i} = sign\left(\frac{1}{N}\sum_{j=1}^{12}\hat{r}_{m-j,i}\right) * \frac{\hat{r}_{m,i}}{\hat{\sigma}_{m,i}} TSM...
因子类型: : 动量指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/momentum/time-series-momentum
