# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_187  
因子名称: 市场反应滞后因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 市场反应滞后因子, 动量, 成长, 价值, 量化交易  
原始公式: r_{i,t} = \alpha_i + \beta_i MKT_t + \sum_{k=1}^{n} \delta^{(k)}_i MKT_{t-k} + \epsilon_{i,t}

PriceDelay = 1 - \frac{R^2_{\delta^{(k)}=0}}{R^2}

r_{i,t}

MKT_t

MKT_{t-k}

\alpha_i

\beta_i

\delta^{(k)}_i

\epsilon_{i,t}

R^2_{\delta^{(k)}=0}

参数说明：ri：,tr_{i,t}ri,t​:股票 i 在 t 期的收益率，通常采用对数收益率计算。MKTtMKT_tMKTt​:t 期市场整体收益率，通常使用代表性的市场指数（例如沪深300，标普500）的收益率。MKTt−kMKT_{t-k}MKTt−k​:滞后 k 期的市场整体收益率。滞后期数 k 可以根据具体情况调整，通常取 1 到 5 个交易日。nnn:滞后期数的上限，决定了需要考虑的市场滞后效应的最大时长。通常取值为3或5，表示考虑最多3或5个交易日的滞后效应。αi\alpha_iαi​:股票 i 的回归截距项，代表了股票 i 与市场无关的收益部分。βi\beta_iβi​:股票 i 对市场风险的暴露程度，衡量了市场收益率变化对股票 i 收益率的影响。δi(k)\delta^{(k)}_iδi(k)​:滞后 k 期市场收益率对股票 i 收益率的影响系数，衡量了市场收益率滞后效应对个股收益率的影响。ϵi,t\epsilon_{i,t}ϵi,t​:股票 i 在 t 期的回归残差项，代表了模型无法解释的股票收益率的波动。Rδ(k)=02R^2_{\delta^{(k)}=0}Rδ(k)=02​:当回归模型中所有市场滞后项的系数 $\delta^{(k)}_i$ 均强制设为 0 时，回归模型的拟合优度（R平方值）。这表示模型仅考虑当期市场收益率对个股的影响。R2R^2R2:包含当期及滞后市场收益率的完整回归模型的拟合优度（R平方值）。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors市场反应滞后技术因子因子公式市场收益回归模型:ri,t=αi+βiMKTt+∑k=1nδi(k)MKTt−k+ϵi,t r_{i,t} = \alpha_i + \beta_i MKT_t + \sum_{k=1}^{n} \delta^{(k)}_i MKT_{t-k} + \epsilon_{i,t} ri,t​=αi​+βi​MKTt​+k=1∑n​δi(k)​MKTt−k​+ϵi,t​市场反应滞后:PriceDelay=1−Rδ(k)=02R2 PriceDelay = 1 - \frac{R^2_{\delta^{(k)}=0}}{R^2} PriceDelay=1−R2Rδ(k)=02​​其中：ri,tr_{i,t}ri,t​:股票 i 在 t 期的收益率，通常采用对数收益率计算。MKTtMKT_tMKTt​:t 期市场整体收益率，通常使用代表性的市场指数（例如沪深300，标普500）的收益率。MKTt−kMKT_{t-k}MKTt−k​:滞后 k 期的市场整体收益率。滞后期数 k 可以根据具体情况调整，通常取 1 到 5 个交易日。nnn:滞后期数的上限，决定了需要考虑的市场滞后效应的最大时长。通常取值为3或5，表示考虑最多3或5个交易日的滞后效应。αi\alpha_iαi​:股票 i 的回归截距项，代表了股票 i 与市场无关的收益部分。βi\beta_iβi​:股票 i 对市场风险的暴露程度，衡量了市场收益率变化对股票 i 收益率的影响。δi(k)\delta^{(k)}_iδi(k)​:滞后 k 期市场收益率对股票 i 收益率的影响系数，衡量了市场收益率滞后效应对个股收益率的影响。ϵi,t\epsilon_{i,t}ϵi,t​:股票 i 在 t 期的回归残差项，代表了...  
DSL公式: r_i,t = alpha_i + beta_i MKT_t + SUM_k=1**n delta**(k)_i MKT_t-k + epsilon_i,t
PriceDelay = 1 - /R**2_delta**(k)=0R**2
r_i,t
MKT_t
MKT_t-k
alpha_i
beta_i
delta**(k)_i
epsilon_i,t
R**2_delta**(k)=0  
描述: 市场反应滞后因子衡量了个股价格对市场整体信息反应的及时性。该因子数值越大，表明个股价格对市场信息的反应越滞后，可能受到更多非市场因素的影响，投资者可能过度关注个股层面信息，从而可能导致股价出现高估或低估的情况。 因子值越接近0，表示个股价格对市场信息反应越及时，而越接近1，表示反应越滞后。高市场反应滞后因子通常预示着更高的投机风险和潜在的定价偏差，可用于构建风险预测和量化选股模型。 因子公式市场收...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/price-delay
