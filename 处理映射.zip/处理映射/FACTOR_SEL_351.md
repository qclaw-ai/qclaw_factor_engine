# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_351  
因子名称: 非流动性经营资产变动率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 动量, 成长, 价值, 量化交易, 非流动性经营资产变动率  
原始公式: \frac{NCOA_{t} - NCOA_{t-1}}{AvgTotalAssets_{t}}

NCOA \approx NonCurrentAssets - LongTermInvestments

AvgTotalAssets = \frac{TotalAssets_{begin} + TotalAssets_{end}}{2}  
DSL公式: /NCOA_t - NCOA_t-1AvgTotalAssets_t
NCOA ≈ NonCurrentAssets - LongTermInvestments
AvgTotalAssets = /TotalAssets_begin + TotalAssets_end2  
描述: 该公式计算的是非流动性经营资产的同比变动率，并使用平均总资产进行标准化，以消除公司规模的影响。具体而言，先计算本期非流动性经营资产与上年同期非流动性经营资产的差额，再除以平均总资产，得到一个相对比例值。 因子解释非流动性经营资产主要包括无形资产、固定资产等，这些资产的计量通常涉及较多的会计估计和主观判断，因此其变动可能受到公司盈余管理的影响，进而降低了财务报表的可靠性。研究表明，非流动性经营资产的...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/non-current-operating-assets-change
