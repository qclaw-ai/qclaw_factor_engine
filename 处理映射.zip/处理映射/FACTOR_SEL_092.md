# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_092  
因子名称: 十大股东持股分散度标准差  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 质量, 十大股东持股分散度标准差, 动量, 成长, 价值, 量化交易  
原始公式: \sigma(w_1, w_2, ..., w_{10})

\sigma(w_1, w_2, ..., w_{10})  
DSL公式: sigma(w_1, w_2, ..., w_10)
sigma(w_1, w_2, ..., w_10)  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。胡骥聪,刘均伟. (2020). 股东大类因子:拆解股东数据中的多元信息. 光大证券 十大股东持股分散度标准差情绪因子因子公式十大股东持股分散度标准差 (Top10_Shareholder_Dispersion):σ(w1,w2,...,w10) \sigma(w_1, w_2, ..., w_{10}) σ(w1​,w2​,...,...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/top-10-shareholder-dispersion
