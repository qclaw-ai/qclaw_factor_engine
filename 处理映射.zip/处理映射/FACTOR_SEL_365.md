# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_365  
因子名称: 股东权利指数  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 动量, 成长, 股东权利指数, 价值, 量化交易  
原始公式:   
DSL公式:   
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors股东权利指数基础面因子因子公式该指数的构建方法为：逐一分析公司章程中是否包含对股东权利构成限制的条款。每发现一项限制股东权利的条款，则指数...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/corporate-governance-index
