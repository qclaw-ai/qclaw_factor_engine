# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_324  
因子名称: 销售收入市值比率 (Sales-to-Market Capitalization Ratio)  
分类: : 基本面指标  
标签: : 销售收入市值比率, 流动性, ratio, 基本面指标, market, 质量, 动量, 成长  
原始公式: \frac{\text{最近12个月营业收入(TTM)}}{\text{总市值}}

\text{最近12个月营业收入(TTM)}

\text{总市值}  
DSL公式: /\text最近12个月营业收入(TTM)\text总市值
\text最近12个月营业收入(TTM)
\text总市值  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Barbee, William C., Sandip Mukherji Jr., and Gary A. Raines. (1996). Do sales-price and debt- equity explain stock returns better than book-market and firm size?. Finan...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/sales-to-market-cap
