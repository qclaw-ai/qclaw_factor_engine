# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_124  
因子名称: 价格偏离移动均线百分比 (Price Deviation from Moving Average Percentage)  
分类: : 技术指标  
标签: : 流动性, 技术指标, 技术分析, moving, from, 质量, average, deviation  
原始公式: BIAS = 100 \times \frac{(CLOSE - SMA(CLOSE, N))}{SMA(CLOSE, N)}

CLOSE

SMA(CLOSE, N)

参数说明：CLOSECLOSECLOSE：当前交易周期的收盘价 (Closing Price)， 代表了该周期内最后一次交易的价格，是计算价格偏离均值的基础。SMA(CLOSE,N)SMA(CLOSE, N)SMA(CLOSE,N):收盘价的 N 周期简单移动平均值 (Simple Moving Average of Closing Price over N periods)，表示过去 N 个周期内收盘价的算术平均值，用于平滑价格波动，形成一个基准参考线。NNN:计算简单移动平均线的周期长度，通常选取短期、中期和长期参数，如6, 12, 20, 24, 60等。N值的选择会影响移动平均线的平滑程度和对价格变化的敏感度，较小的N值对价格变化更敏感，较大的N值更平滑。 Related Factors 多空意愿指标 (Bull-Bear Index, BBI) 商品通道指数 异同离差乖离率振荡器 随机动量指标 (SMI) 相对波动性指标 动态趋向指标 累计振荡指标 蔡金波动率指标 (Chaikin Volatility Index) 多周期标准化移动平均动量因子 计算简单移动平均线的周期长度，通常选取短期、中期和长期参数，如6, 12, 20, 24, 60等。N值的选择会影响移动平均线的平滑程度和对价格变化的敏感度，较小的N值对价格变化更敏感，较大的N值更平滑。 因子解释价格偏离移动均线百分比 (BIAS) 通过计算当前收盘价与 N 周期简单移动平均线的偏离百分比，来量化价格在短期内相对于其均值的波动程度。正的 BIAS 值表示当前收盘价高于其移动平均线，暗示市场可能处于超买状态，价格可能面临回调风险，数值越大，短期价格超买程度越高，反转的可能性也越大。负的 BIAS 值表示当前收盘价低于其移动平均线，暗示市场可能处于超卖状态，价格可能存在反弹机会，数值越小，短期价格超卖程度越高，反转的可能性也越大。该指标常用于辅助判断价格反转的时机，并与其他技术指标结合使用，以提高预测的准确性。在量化交易中，BIAS可以作为构建反转策略的一个重要组成部分。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 其中：CLOSECLOSECLOSE:当前交易周期的收盘价 (Closing Price)， 代表了该周期内最后一次交易的价格，是计算价格偏离均值的基础。SMA(CLOSE,N)SMA(CLOSE, N)SMA(CLOSE,N):收盘价的 N 周期简单移动平均值 (Simple Moving Average of Closing Price over N periods)，表示过去 N 个周期内收盘价的算术平均值，用于平滑价格波动，形成一个基准参考线。NNN:计算简单移动平均线的周期长度，通常选取短期、中期和长期参数，如6, 12, 20, 24, 60等。N值的选择会影响移动平均线的平滑程度和对价格变化的敏感度，较小的N值对价格变化更敏感，较大的N值更平滑。 价格偏离移动均线百分比技术因子因子公式BIAS:BIAS=100×(CLOSE−SMA(CLOSE,N))SMA(CLOSE,N) BIAS = 100 \times \frac{(CLOSE - SMA(CLOSE, N))}{SMA(CLOSE, N)} BIAS=100×SMA(CLOSE,N)(CLOSE−SMA(CLOSE,N))​其中：CLOSECLOSECLOSE:当前交易周期的收盘价 (Closing Price)， 代表了该周期内最后一次交易的价格，是计算价格偏离均值的基础。SMA(CLOSE,N)SMA(CLOSE, N)SMA(CLOSE,N):收盘价的 N 周期简单移动平均值 (Simple Moving Average of Closing Price over N periods)，表示过去 N 个周期内收盘价的算术平均值，用于平滑价格波动，形成一个基准参考线。NNN:计算简单移动平均线的周期长度，通常选取短期、中期和长期参数，如6, 12, 20, 24, 60等。N值的选择会影响移动平均线的平滑程度和对价格变化的敏感度，较小的N值对价格变化更敏感，较大的N值更平滑。因子解释价格偏离移动均线百分比 (BIAS) 通过计算当前收盘价与 N 周期简单移动平均线的偏离百分比，来量化价格在短期内相对于其...  
DSL公式: BIAS = 100 * /(close - SMA(close, N))SMA(close, N)
close
SMA(close, N)  
描述: 因子公式BIAS:BIAS=100×(CLOSE−SMA(CLOSE,N))SMA(CLOSE,N) BIAS = 100 \times \frac{(CLOSE - SMA(CLOSE, N))}{SMA(CLOSE, N)} BIAS=100×SMA(CLOSE,N)(CLOSE−SMA(CLOSE,N))​其中：CLOSECLOSECLOSE:当前交易周期的收盘价 (Closing Pric...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/bias
