# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_306  
因子名称: 标准化存货变动率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 标准化存货变动率, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{Inventory_{t} - Inventory_{t-1}}{\frac{TotalAssets_{t} + TotalAssets_{t-1}}{2}}

\frac{TotalAssets_{t} + TotalAssets_{t-1}}{2}

Inventory_{t}

Inventory_{t-1}

TotalAssets_{t}

TotalAssets_{t-1}

参数说明：，平均总资产 = TotalAssetst+TotalAssetst−12 \frac{TotalAssets_{t} + TotalAssets_{t-1}}{2} 2TotalAssetst​+TotalAssetst−1​​该公式计算了最近报告期（t期）与上年同期（t-1期）存货水平的差额，并使用两期平均总资产进行标准化，以消除公司规模差异带来的影响。InventorytInventory_{t}Inventoryt​:最近报告期（t期）的存货金额Inventoryt−1Inventory_{t-1}Inventoryt−1​:上年同期（t-1期）的存货金额TotalAssetstTotalAssets_{t}TotalAssetst​:最近报告期（t期）的总资产金额TotalAssetst−1TotalAssets_{t-1}TotalAssetst−1​:上年同期（t-1期）的总资产金额 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Thomas, Jacob K., and Huai Zhang. (2002). Inventory changes and future returns. Review of Accounting Studies 因子解释该因子基于Thomas, Jacob K., and Huai Zhang (2002) 的研究，他们发现存货变化与公司未来的表现之间存在相关性。具体来说，存货的增加通常被解读为公司对未来需求的乐观预期，但也可能预示着库存积压和销售困难，因此存货增加后的公司表现可能出现反转。反之，存货减少可能反映了公司需求下降或者积极去库存，这种变化也会影响公司未来的盈利能力和成长性，并可能出现反转。因此，该因子可以作为识别公司基本面可能发生变化的信号，并与其他因子结合使用以进行量化投资策略的构建。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 营收增长率-存货增长率差 存货周转率 (Inventory Turnover Ratio) 存货同比增速 流动性经营资产变动率 月度消费指数同比变动率 标准化异常财务变动率 双向价格差分自相关性标准化因子 季度总资产环比增长率 负收益成交额加权非流动性因子 Related Factors 营收增长率-存货增长率差 存货周转率 (Inventory Turnover Ratio) 存货同比增速 流动性经营资产变动率 月度消费指数同比变动率 标准化异常财务变动率 双向价格差分自相关性标准化因子 季度总资产环比增长率 负收益成交额加权非流动性因子 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors标准化存货变动率基础面因子因子公式标准化存货变动率 = Inventoryt−Inventoryt−1TotalAssetst+TotalAssetst−12 \frac{Inventory_{t} - Inventory_{t-1}}{\frac{TotalAssets_{t} + TotalAssets_{t-1}}{2}} 2TotalAssetst​+TotalAssetst−1​​Inventoryt​−Inventoryt−1​​其中，平均总资产 = TotalAssetst+TotalAssetst−12 \frac{TotalAssets_{t} + TotalAssets_{t-1}}{2} 2TotalAssetst​+TotalAssetst−1​​该公式计算了最近报告期（t期）与上年同期（t-1期）存货水平的差额，并使用两期平均总资产进行标准化，以消除公司规模差异带来的影响。InventorytInventory_{t}Inventoryt​:最近报告期（t期）的存货金额Inventoryt−1In...  
DSL公式: /Inventory_t - Inventory_t-1/TotalAssets_t + TotalAssets_t-12
/TotalAssets_t + TotalAssets_t-12
Inventory_t
Inventory_t-1
TotalAssets_t
TotalAssets_t-1  
描述: 该公式计算了最近报告期（t期）与上年同期（t-1期）存货水平的差额，并使用两期平均总资产进行标准化，以消除公司规模差异带来的影响。 因子公式标准化存货变动率 = Inventoryt−Inventoryt−1TotalAssetst+TotalAssetst−12 \frac{Inventory_{t} - Inventory_{t-1}}{\frac{TotalAssets_{t} + Tota...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/inventory-changes
