# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_240  
因子名称: 集合竞价成交量占比因子  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 质量, 动量, 成长, 价值, 量化交易, 规模  
原始公式: OCVP_t = \frac{1}{d}\sum_{i=1}^{d} w_{t-i} \left( \frac{VOL_{call,open,t-i}}{VOL_{total,t-i}} \right)

CCVP_t = \frac{1}{d}\sum_{i=1}^{d} \left( \frac{VOL_{call,close,t-i}}{VOL_{total,t-i}} \right)

ACVP_t = \alpha OCVP_t + (1 - \alpha)CCVP_t

w_{t-i}

VOL_{call,open,t-i}

VOL_{call,close,t-i}

VOL_{total,t-i}

\alpha

参数说明：wt：−iw_{t-i}wt−i​:时间窗口内第t-i天的开盘集合竞价成交量权重，可以设置为等权重或时间衰减权重。例如，使用指数衰减权重，给予最近的交易日更高的权重，以反映市场情绪的短期变化。ddd:计算因子所使用的历史时间窗口大小，单位为交易日。例如，d=5 表示使用过去5个交易日的数据。VOLcall,open,t−iVOL_{call,open,t-i}VOLcall,open,t−i​:第t-i天开盘集合竞价阶段的成交量。具体而言，指的是开盘前一段时间（例如，9:15-9:25）的成交量。VOLcall,close,t−iVOL_{call,close,t-i}VOLcall,close,t−i​:第t-i天收盘集合竞价阶段的成交量。具体而言，指的是收盘前一段时间（例如，14:55-15:00）的成交量。VOLtotal,t−iVOL_{total,t-i}VOLtotal,t−i​:第t-i天该股票全天的总成交量。α\alphaα:开盘集合竞价成交量占比因子(OCVP)在复合因子中的权重，取值范围为0到1，反映投资者对开盘集合竞价和收盘集合竞价的重视程度差异。$\alpha$ 越大，则越强调开盘集合竞价成交量占比的重要性；反之，则越强调收盘集合竞价成交量占比的重要性。可以通过回测确定最优的 $\alpha$ 值。 集合竞价成交量占比复合因子 (Aggregated Call Auction Volume Percentage, ACVP):ACVPt=αOCVPt+(1−α)CCVPt ACVP_t = \alpha OCVP_t + (1 - \alpha)CCVP_t ACVPt​=αOCVPt​+(1−α)CCVPt​ 集合竞价成交量占比复合因子 开盘时段大单净额占比 开盘时段主动买入意愿强度 开盘时段主动买入强度 日内开盘净委买增额成交额比率 开盘后主动买入强度标准化均值 开盘时段主动净买额占比 实体K线一致性买入强度因子 成交量价背离度 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子仅供教育和研究目的，不构成投资建议。•在做出任何投资决策之前，请咨询合格的财务顾问。 开盘集合竞价成交量占比因子 (Opening Call Auction Volum...  
DSL公式: OCVP_t = /1dSUM_i=1**d w_t-i ( /VOL_call,open,t-iVOL_total,t-i )
CCVP_t = /1dSUM_i=1**d ( /VOL_call,close,t-iVOL_total,t-i )
ACVP_t = alpha OCVP_t + (1 - alpha)CCVP_t
w_t-i
VOL_call,open,t-i
VOL_call,close,t-i
VOL_total,t-i
alpha  
描述: Related Factors 集合竞价成交量占比复合因子 开盘时段大单净额占比 开盘时段主动买入意愿强度 开盘时段主动买入强度 日内开盘净委买增额成交额比率 开盘后主动买入强度标准化均值 开盘时段主动净买额占比 实体K线一致性买入强度因子 成交量价背离度 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。刘均伟. (2017). 见微知著：成交量占比高频因子解析. 光大证券 收盘集...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/emotion-volume-ratio
