# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_232  
因子名称: 流通股股权集中度 (Top3)  
分类: : 基本面指标  
标签: : 流动性, top, 基本面指标, 流通股股权集中度, 质量, 动量, 成长, 价值  
原始公式: Top3_{circulated_holders}

Total_{circulated_shares}

frac{Top3_{circulated_holders}}{Total_{circulated_shares}}

Top3_{circulated_holders}

Total_{circulated_shares}  
DSL公式: Top3_circulated_holders
Total_circulated_shares
fracTop3_circulated_holdersTotal_circulated_shares
Top3_circulated_holders
Total_circulated_shares  
描述: Factors DirectoryQuantitative Trading Factors流通股股权集中度 (Top3)基础面因子因子公式前三大流通股东持股数Top3circulatedholders Top3_{circulated_holders} Top3circulatedh​olders​流通股股本Totalcirculatedshares Total_{circulated_share...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/equity-concentration-circulation
