# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_030  
因子名称: 成交量相对强度指标  
分类: : 技术指标  
标签: : 流动性, 技术指标, 技术分析, 质量, 动量, 成长, 基本面分析, 量化交易  
原始公式: U_t = \begin{cases} V_t & \text{if } P_t > P_{t-1} \\  V_t / 2 & \text{if } P_t = P_{t-1} \\ 0 & \text{if } P_t < P_{t-1} \end{cases}

D_t = \begin{cases} V_t & \text{if } P_t < P_{t-1} \\  V_t / 2 & \text{if } P_t = P_{t-1} \\ 0 & \text{if } P_t > P_{t-1} \end{cases}

UU_t = \frac{(N-1) \times UU_{t-1} + U_t}{N}

DD_t = \frac{(N-1) \times DD_{t-1} + D_t}{N}

VRSI_t = 100 \times \frac{UU_t}{UU_t + DD_t}

V_t

P_t

P_{t-1}

参数说明：，N 为计算周期，通常设置为20。$UU_{t-1}$ 代表前一日的向上成交量平均值，$U_t$ 代表当日的向上成交量。 UU (向上成交量平均值):UUt=(N−1)×UUt−1+UtN UU_t = \frac{(N-1) \times UU_{t-1} + U_t}{N} UUt​=N(N−1)×UUt−1​+Ut​​向上成交量的指数移动平均值(EMA)。其中，N 为计算周期，通常设置为20。$UU_{t-1}$ 代表前一日的向上成交量平均值，$U_t$ 代表当日的向上成交量。 DD (向下成交量平均值):DDt=(N−1)×DDt−1+DtN DD_t = \frac{(N-1) \times DD_{t-1} + D_t}{N} DDt​=N(N−1)×DDt−1​+Dt​​向下成交量的指数移动平均值(EMA)。其中，N 为计算周期，通常设置为20。$DD_{t-1}$ 代表前一日的向下成交量平均值，$D_t$ 代表当日的向下成交量。 成交量相对强度指标 相对波动性指标 区域强度指数 相对强弱指标 (RSI) 相对强弱指标 (Relative Strength Index) 价格成交量趋势指标 相对强弱人气指标 成交量价背离度 成交量能量潮指标 (On-Balance Volume) ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 向下成交量的指数移动平均值(EMA)。其中，N 为计算周期，通常设置为20。$DD_{t-1}$ 代表前一日的向下成交量平均值，$D_t$ 代表当日的向下成交量。 参数说明:NNN:计算VRSI的周期长度，通常设置为20。该参数决定了指标的敏感程度，较小的N值会使指标更敏感，较大的N值则会使指标更平滑。VtV_tVt​:t日的成交量。PtP_tPt​:t日的收盘价格。Pt−1P_{t-1}Pt−1​:t-1日的收盘价格。 VRSI (成交量相对强度指标):VRSIt=100×UUtUUt+DDt VRSI_t = 100 \times \frac{UU_t}{UU_t + DD_t} VRSIt​=100×UUt​+DDt​UUt​​成交量相对强度指标，表示向上成交量平均值在总成交量平均值中的占比，以百分比形式呈现。$UU_t$ 代表当日的向上成交量平均值，$DD_t$ 代表当日的向下成交量平均值。 ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子仅供教育和研究目的，不构成投资建议。•在做出任何投资决策之前，请咨询合格的财务顾问。 因子公式U (当日向上成交量):Ut={Vtif Pt>Pt−1Vt/2if Pt=Pt−10if Pt<Pt−1 U_t = \begin{cases} V_t & \text{if } P_t > P_{t-1} \\  V_t / 2 & \text{if } P_t = P_{t-1} \\ 0 & \text{if } P_t < P_{t-1} \end{cases} Ut​=⎩⎨⎧​Vt​Vt​/20​if Pt​>Pt−1​if Pt​=Pt−1​if Pt​<Pt−1​​当日向上成交量。如果当日收盘价高于前一日，则当日成交量计为向上成交量；如果相等，则计为一半；如果低于前一日，则计为0。 其中，$V_t$ 代表当日成交量，$P_t$ 代表当日收盘价，$P_{t-1}$代表前一日收盘价。D (当日向下成交量):Dt={Vtif Pt<Pt−1Vt/2if Pt=Pt−10if Pt>Pt−1 D_t = \begin{cases} V_t & \text{if } P_t < P_{t-1} \\  V_t / 2 & \text{if } P_t = P_{t-1} \\ 0 & \text{if } P_t > P_{t-1} \end{cases} Dt​=⎩⎨⎧​Vt​Vt​/20​if Pt​<Pt−1​if Pt​=Pt−1​if Pt​>Pt−1​​当日向下成交量。如果当日收盘价低于前一日，则当日成交量计为向下成交量；如果相等，则计为一半；如果高于前一日，则计为0。 其中，$V_t$ 代表当日成交量，$P_t$ 代表当日收盘价，$P_{t-1}$代表前一日收盘价。UU (向上成交量平均值):UUt=(N−1)×UUt−1+UtN UU_t = \frac{(N-1) \times UU_{t-1} + U_t}{N} UUt​=N(N−1)×UUt−1​+Ut​​向上成交量的指数移动平均值(EMA)。其中，N 为计算周期，...  
DSL公式: U_t = \begincases V_t & \textif P_t > P_t-1 \\ V_t / 2 & \textif P_t = P_t-1 \\ 0 & \textif P_t < P_t-1 \endcases
D_t = \begincases V_t & \textif P_t < P_t-1 \\ V_t / 2 & \textif P_t = P_t-1 \\ 0 & \textif P_t > P_t-1 \endcases
UU_t = /(N-1) * UU_t-1 + U_tN
DD_t = /(N-1) * DD_t-1 + D_tN
VRSI_t = 100 * /UU_tUU_t + DD_t
V_t
P_t
P_t-1  
描述: 向上成交量的指数移动平均值(EMA)。其中，N 为计算周期，通常设置为20。$UU_{t-1}$ 代表前一日的向上成交量平均值，$U_t$ 代表当日的向上成交量。 UU (向上成交量平均值):UUt=(N−1)×UUt−1+UtN UU_t = \frac{(N-1) \times UU_{t-1} + U_t}{N} UUt​=N(N−1)×UUt−1​+Ut​​向上成交量的指数移动平均值(EM...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/volume-relative-strength
