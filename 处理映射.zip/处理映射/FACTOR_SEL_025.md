# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_025  
因子名称: 动态趋向指标  
分类: : 技术指标  
标签: : 流动性, 技术指标, 动态趋向指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: DTM = \begin{cases} 0 & OPEN < OPEN[1] \\  \max(HIGH - OPEN, OPEN - OPEN[1]) & OPEN \geq OPEN[1] \end{cases}

DBM = \begin{cases} 0 & OPEN \geq OPEN[1] \\ \max(OPEN - LOW, OPEN[1] - OPEN) & OPEN < OPEN[1] \end{cases}

STM = \sum_{i=0}^{N-1} DTM_i

SBM = \sum_{i=0}^{N-1} DBM_i

DTMI = \begin{cases} \frac{STM - SBM}{STM} & STM > SBM \\ 0 & STM = SBM \\ \frac{STM - SBM}{SBM} & STM < SBM \end{cases}

DTMIMA = SMA(DTMI, M)

OPEN

OPEN[1]

HIGH

LOW

参数说明：OPENOPENOPEN：当日开盘价。该价格反映了市场对该股票在当日开盘时的初始估值。OPEN[1]OPEN[1]OPEN[1]:前一日的开盘价。该价格作为基准，用于比较当日开盘价的波动方向。HIGHHIGHHIGH:当日最高价。该价格反映了当日市场情绪推动下，股票达到的最高成交价格。LOWLOWLOW:当日最低价。该价格反映了当日市场情绪推动下，股票达到的最低成交价格。DTMDTMDTM:当日向上动能。若当日开盘价低于前一日开盘价，则DTM为0；否则，取当日最高价与开盘价之差或当日开盘价与前一日开盘价之差的最大值，表示当日向上波动的最大幅度。DBMDBMDBM:当日向下动能。若当日开盘价高于等于前一日开盘价，则DBM为0；否则，取当日开盘价与最低价之差或前一日开盘价与当日开盘价之差的最大值，表示当日向下波动的最大幅度。STMSTMSTM:过去N个交易日DTM的总和，表示一段时间内的向上动能累计。SBMSBMSBM:过去N个交易日DBM的总和，表示一段时间内的向下动能累计。NNN:计算STM和SBM的窗口大小，表示累计动能的时间周期。默认值为23，通常可根据不同交易周期和策略进行调整。N值越大，指标的敏感度越低，反之则越高。DTMIDTMIDTMI:动态趋向指标。表示多空力量的相对强弱。当STM大于SBM时，DTMI为多头力量占比；当STM小于SBM时，DTMI为空头力量占比；当STM等于SBM时，DTMI为0，表示多空平衡...  
DSL公式: DTM = \begincases 0 & open < open[1] \\ MAX(high - open, open - open[1]) & open >= open[1] \endcases
DBM = \begincases 0 & open >= open[1] \\ MAX(open - low, open[1] - open) & open < open[1] \endcases
STM = SUM_i=0**N-1 DTM_i
SBM = SUM_i=0**N-1 DBM_i
DTMI = \begincases /STM - SBMSTM & STM > SBM \\ 0 & STM = SBM \\ /STM - SBMSBM & STM < SBM \endcases
DTMIMA = SMA(DTMI, M)
open
open[1]
high
low  
描述: 计算DTMIMA的窗口大小，表示移动平均线平滑的周期。默认值为8，通常可根据不同交易周期和策略进行调整。M值越大，移动平均线越平滑，对价格波动不敏感。 动态趋向指标(DTMI)通过对比开盘价的向上波动幅度与向下波动幅度，来衡量市场情绪和买卖压力。指标的核心在于使用当日开盘价与前一日开盘价的相对位置及当日最高价、最低价来计算多空动能，并据此构建买卖信号。DTMI的取值范围在-1到+1之间，数值越接近...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/dynamic-buy-sell-indicator
