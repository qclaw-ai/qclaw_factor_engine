# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_359  
因子名称: 基于中心性加权的客户动量因子  
分类: : 情绪指标  
标签: : 流动性, 基于中心性加权的客户动量因子, 情绪指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: cmom_i^{1M} = \sum_{j=1}^{N_i} w_{ij}^{centrality} \times mom_{ij}^{1M} , \quad i = 1, 2, ..., N

cmom_i^{1M}

mom_{ij}^{1M}

w_{ij}^{centrality}

c_{ij}

N_i

参数说明：$k$ 为公司 i 的所有客户，确保权重之和为1。cijc_{ij}cij​:表示客户j与公司i之间供应链网络边的中介中心性 (Edge Betweenness Centrality)。具体而言，它衡量了网络中经过客户j与公司i之间边的最短路径的数量。较高的中介中心性意味着客户j与公司i之间的关系在供应链网络中更为重要，对信息传递和资源流动有更大的影响。NiN_iNi​:表示公司 i 的客户总数因子解释传统的客户动量因子通常以客户的销售额占比作为权重，然而，这种方法容易受到销售数据缺失或不完整的影响。本因子创新性地引入供应链图网络的边中介中心性（Edge Betweenness Centrality）作为权重。中介中心性捕捉了供应链网络中各节点间的结构重要性，能够更好地反映客户对于供应商的影响力。实证研究表明，边中介中心性与销售占比呈现显著的正相关关系，这为使用中心性度量替代销售占比提供了理论支持。此外，使用边中介中心性还有助于避免因销售数据缺失而导致的因子失效问题，增强了因子的稳健性和适用性。本因子通过网络结构来衡量客户动量，更贴切地反映了客户关系在供应链中的重要程度和传递效应。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Hamuro, Y., and K. Okada. (2018). Predicting Stock Returns Based on the Time Lag in Information Diffusion through Supply Chain Networks. Special Interest Group on Financial Informatics Technical Reports 40-45, Japanese Society for Artificial IntelligenceRelated Factors 多层客户关系加权动量因子 客户加权动量因子 供应链议价能力及资金占用因子 财务相似度加权收益动量 分析师共识覆盖加权动量 行业领头羊动量溢价因子 外资券商关联网络牵引强度因子 科技关联加权动量因子 新闻共现注意力溢出因子 表示客户j与公司i之间供应链网络边的中介中心性 (Edge Betweenness Centrality)。具体而言，它衡量了网络中经过客户j与公司i之间边的最短路径的数量。较高的中介中心性意味着客户j与公司i之间的关系在供应链网络中更为重要，对信息传递和资源流动有更大的影响。 基于中心性加权的客户动量因子 (Weighted Customer Momentum):cmomi1M=∑j=1Niwijcentrality×momij1M,i=1,2,...,N cmom_i^{1M} = \sum_{j=1}^{N_i}...  
DSL公式: cmom_i**1M = SUM_j=1**N_i w_ij**centrality * mom_ij**1M , \quad i = 1, 2, ..., N
cmom_i**1M
mom_ij**1M
w_ij**centrality
c_ij
N_i  
描述: 多层客户关系加权动量因子 客户加权动量因子 供应链议价能力及资金占用因子 财务相似度加权收益动量 分析师共识覆盖加权动量 行业领头羊动量溢价因子 外资券商关联网络牵引强度因子 科技关联加权动量因子 新闻共现注意力溢出因子 Factors DirectoryQuantitative Trading Factors基于中心性加权的客户动量因子-单层客户关系视角情绪因子因子公式基于中心性加权的客户动量因...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/customer-momentum
