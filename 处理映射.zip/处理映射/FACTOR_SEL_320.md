# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_320  
因子名称: 应计盈余资产比率 (Accruals-to-Assets Ratio)  
分类: : 基本面指标  
标签: : 流动性, accruals, ratio, 基本面指标, 应计盈余资产比率, assets, 动量, 成长  
原始公式: \frac{Accruals_{TTM}}{AverageAssets}

Accruals = NetIncome - CFO_{from Operations}

AverageAssets = \frac{TotalAssets_{beginning} + TotalAssets_{ending}}{2}

Accruals_{TTM}

NetIncome

CFO_{from Operations}

AverageAssets

TotalAssets_{beginning}

TotalAssets_{ending}

参数说明：AccrualsTTMAccruals_：{TTM}AccrualsTTM​:最近12个月（Trailing Twelve Months, TTM）的应计盈余。它是指公司在过去12个月内发生的，非现金的收入和费用。计算方式为净利润减去经营活动产生的现金流量净额。NetIncomeNetIncomeNetIncome:公司在特定期间的净利润，通常取自利润表。它是公司所有收入扣除所有支出后的最终利润。CFOfromOperationsCFO_{from Operations}CFOfromOperations​:经营活动产生的现金流量净额，取自现金流量表。它代表了公司在主营业务运营中产生的实际现金流入和流出。AverageAssetsAverageAssetsAverageAssets:平均总资产，表示在计算期间公司所拥有的资产平均值。它是期初和期末总资产的平均值，用于衡量公司的规模，并作为应计盈余的标准化基准。TotalAssetsbeginningTotalAssets_{beginning}TotalAssetsbeginning​:期初总资产，表示计算期间开始时公司的总资产价值。通常取自期初资产负债表。TotalAssetsendingTotalAssets_{ending}TotalAssetsending​:期末总资产，表示计算期间结束时公司的总资产价值。通常取自期末资产负债表。因子解释应计盈余资产比率是一种衡量公司盈余质量的指标。较高的比率可能表明公司在盈余中过度依赖非现金项目，这会增加盈余的可操控性和不确定性，从...  
DSL公式: /Accruals_TTMAverageAssets
Accruals = NetIncome - CFO_from Operations
AverageAssets = /TotalAssets_beginning + TotalAssets_ending2
Accruals_TTM
NetIncome
CFO_from Operations
AverageAssets
TotalAssets_beginning
TotalAssets_ending  
描述: 因子解释应计盈余资产比率是一种衡量公司盈余质量的指标。较高的比率可能表明公司在盈余中过度依赖非现金项目，这会增加盈余的可操控性和不确定性，从而降低盈余的持续性。这种情况下，投资者可能对公司的真实盈利能力产生误判，导致证券定价错误。反之，较低的比率则可能表明公司盈余更具有现金基础，更可靠。因此，该指标不仅可用于识别盈余管理风险，也能辅助投资者评估公司的财务稳健性和盈利可持续性。在量化投资中，可作为构...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/basic-surface-total-accrued-surplus
