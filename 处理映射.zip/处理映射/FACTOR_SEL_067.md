# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_067  
因子名称: 换手率波动率  
分类: : 波动率指标  
标签: : 流动性, 换手率波动率, 质量, 动量, 成长, 价值, 量化交易, 波动率指标  
原始公式: \sigma(\text{Turnover}_t, t \in [T-K+1, T])

\text{Turnover}_t = \frac{\text{Volume}_t}{\text{FreeFloat}_t}

\sigma

\text{Turnover}_t

\text{Volume}_t

\text{FreeFloat}_t

参数说明：日度换手率（Turnover）的计算公式为：Turnovert=VolumetFreeFloatt \text{Turnover}_t = \frac{\text{Volume}_t}{\text{FreeFloat}_t} Turnovert​=FreeFloatt​Volumet​​公式中各参数解释如下：σ\sigmaσ:标准差函数，用于计算日度换手率序列的波动程度。Turnovert\text{Turnover}_tTurnovert​:t日股票的日度换手率。ttt:表示时间，此处为自然日。TTT:当前日期。KKK:回溯期，表示计算换手率波动率所使用的历史月份数。K值的大小需要根据市场情况和投资策略进行调整，常见的取值范围包括3、6、12个月等。更大的K值会考虑更长期的波动，较小的K值更敏感于近期的波动变化。Volumet\text{Volume}_tVolumet​:t日股票的成交量。FreeFloatt\text{FreeFloat}_tFreeFloatt​:t日股票的流通股本。 日度换手率（Turnover）的计算公式为：Turnovert=VolumetFreeFloatt \text{Turnover}_t = \frac{\text{Volume}_t}{\text{FreeFloat}_t} Turnovert​=FreeFloatt​Volumet​​ 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Chordia, Tarun, Avanidhar Subrahmanyam, and V. Ravi Anshuman. (2001). Trading activity and expected stock returns. Journal of Financial Economics 公式中各参数解释如下：σ\sigmaσ:标准差函数，用于计算日度换手率序列的波动程度。Turnovert\text{Turnover}_tTurnovert​:t日股票的日度换手率。ttt:表示时间，此处为自然日。TTT:当前日期。KKK:回溯期，表示计算换手率波动率所使用的历史月份数。K值的大小需要根据市场情况和投资策略进行调整，常见的取值范围包括3、6、12个月等。更大的K值会考虑更长期的波动，较小的K值更敏感于近期的波动变化。Volumet\text{Volume}_tVolumet​:t日股票的成交量。FreeFloatt\text{FreeFloat}_tFreeFloatt​:t日股票的流通股本。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors换手率波动率波动率因子因子公式换手率波动率定义为最近K个月日度换手率序列的标准差，计算公式为：σ(Turnovert,t∈[T−K+1,T]) \sigma(\text{Turnover}_t, t \in [T-K+1, T]) σ(Turnovert​,t∈[T−K+1,T])其中：日度换手率（Turnover）的计算公式为：Turnovert=VolumetFreeFloatt \text{Turnover}_t = \frac{\text{Volume}_t}{\text{FreeFloat}_t} Turnovert​=FreeFloatt​Volumet​​公式中各参数解释如下：σ\sigmaσ:标准差函数，用于计算日度换手率序列的波动程度。Turnovert\text{Turnover}_tTurnovert​:t日股票的日度换手率。ttt:表示时间，此处为自然日。TTT:当前日期。KKK:回溯期，表示计算换手率波动率所使用的历史月份数。K值的大小需要根据市场情况和投资策略进行调整，常见的取值范围包括3、6、12个月等。更大的K值会考虑更长期的波动，较小的K值更敏感于近期的波动变化。Volumet\text{Volume}_tVolumet​:t日股票的成交量。FreeFloatt\text{FreeFloat}_tFreeFloatt​:t日股票的流通股本。因...  
DSL公式: sigma(\textTurnover_t, t \in [T-K+1, T])
\textTurnover_t = /\textVolume_t\textFreeFloat_t
sigma
\textTurnover_t
\textVolume_t
\textFreeFloat_t  
描述: 因子公式换手率波动率定义为最近K个月日度换手率序列的标准差，计算公式为：σ(Turnovert,t∈[T−K+1,T]) \sigma(\text{Turnover}_t, t \in [T-K+1, T]) σ(Turnovert​,t∈[T−K+1,T])其中：日度换手率（Turnover）的计算公式为：Turnovert=VolumetFreeFloatt \text{Turnover}_t...
因子类型: : 波动率指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/volatility/turnover-volatility
