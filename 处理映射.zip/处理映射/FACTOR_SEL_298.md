# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_298  
因子名称: 市盈率增长率-股息收益率比率 (PEG-DY Ratio)  
分类: : 成长性指标  
标签: : 流动性, ratio, 成长性指标, peg, 质量, 股息收益率比率, 动量, 成长  
原始公式: PEG_{TTM} = \frac{P/E_{TTM}}{EPS Growth Rate_{TTM}}

DividendYield_{TTM} = \frac{Dividend_{TTM}}{Price}

PEG\text{-}DY_{TTM} = \frac{PEG_{TTM}}{DividendYield_{TTM}}

PEG_{TTM}

P/E_{TTM}

EPS Growth Rate_{TTM}

DividendYield_{TTM}

Dividend_{TTM}

Price

PEG\text{-}DY_{TTM}  
DSL公式: PEG_TTM = /P/E_TTMEPS Growth Rate_TTM
DividendYield_TTM = /Dividend_TTMPrice
PEG\text-DY_TTM = /PEG_TTMDividendYield_TTM
PEG_TTM
P/E_TTM
EPS Growth Rate_TTM
DividendYield_TTM
Dividend_TTM
Price
PEG\text-DY_TTM  
描述: ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors市盈率增长率-股息收益率比率 ...
因子类型: : 成长性指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/growth/pe-growth-rate-dividend-yield
