# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_301  
因子名称: 情绪敏感度因子  
分类: : 情绪指标  
标签: : 情绪敏感度因子, 流动性, 情绪指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: r_i^t = \alpha_i + \beta_i \cdot (\frac{CSMS_t}{CSMS_{t-1}} - 1) + \epsilon_i^t

SentimentSensitivity = -1 \cdot |\beta_i|

r_i^t

CSMS_t

CSMS_{t-1}

\alpha_i

\beta_i

\epsilon_i^t  
DSL公式: r_i**t = alpha_i + beta_i * (/CSMS_tCSMS_t-1 - 1) + epsilon_i**t
SentimentSensitivity = -1 * |beta_i|
r_i**t
CSMS_t
CSMS_t-1
alpha_i
beta_i
epsilon_i**t  
描述: 股票 i 在 t 日的日度收益率，计算方法通常为 (当日收盘价 - 前一日收盘价) / 前一日收盘价。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。(2021). Sentiment Beta: Risk or Alpha?. 量化投资与机器学习 因子解释情绪敏感度因子通过时序回归模型衡量市场情绪变化对个股收益率的影响，并使用回归得到的 Beta 系数的绝对值取反作为最终的因子...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/sentiment-beta
