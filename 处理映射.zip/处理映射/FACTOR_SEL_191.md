# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_191  
因子名称: 阿隆指标  
分类: : 技术指标  
标签: : 流动性, 技术指标, 技术分析, 质量, 动量, 成长, 价值, 量化交易  
原始公式: AroonUp = \frac{N - DaysSinceHigh}{N} * 100

AroonDown = \frac{N - DaysSinceLow}{N} * 100

Aroon = AroonUp - AroonDown

DaysSinceHigh

DaysSinceLow  
DSL公式: AroonUp = /N - DaysSinceHighN * 100
AroonDown = /N - DaysSinceLowN * 100
Aroon = AroonUp - AroonDown
DaysSinceHigh
DaysSinceLow  
描述: 因子公式阿隆上升线 (Aroon Up):AroonUp=N−DaysSinceHighN∗100 AroonUp = \frac{N - DaysSinceHigh}{N} * 100 AroonUp=NN−DaysSinceHigh​∗100阿隆下降线 (Aroon Down):AroonDown=N−DaysSinceLowN∗100 AroonDown = \frac{N - DaysSi...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/aroon-index
