# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_146  
因子名称: 利息覆盖倍数 (Interest Coverage Ratio)  
分类: : 基本面指标  
标签: : 流动性, coverage, ratio, interest, 基本面指标, 质量, 动量, 成长  
原始公式: \frac{EBIT_{TTM}}{Interest Expense_{TTM}}

EBIT_{TTM}

Interest Expense_{TTM}  
DSL公式: /EBIT_TTMInterest Expense_TTM
EBIT_TTM
Interest Expense_TTM  
描述: ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 因子解释利息覆盖倍数反映了企业利用其盈利能力（息税前利润）支付利息的能力。该比率越高，表示企业支付利息的能力越强，其财务结构越稳健，面临的债务风险越低。通常，较高的利息覆盖倍数被视为更安全、更稳健的财务信号，表明企业有足够的利润来承担其债务利息，从而降低违约风险。投资者和债权人通常会关注该指...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/interest-coverage-ratio
