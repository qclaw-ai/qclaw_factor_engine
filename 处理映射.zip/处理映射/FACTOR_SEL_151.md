# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_151  
因子名称: 单季度营业利润同比增速  
分类: : 基本面指标  
标签: : 流动性, 单季度营业利润同比增速, 基本面指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{Q_t^{op} - Q_{t-4}^{op}}{|Q_{t-4}^{op}|}

Q_t^{op}

Q_{t-4}^{op}

|  |

整体公式  
DSL公式: /Q_t**op - Q_t-4**op|Q_t-4**op|
Q_t**op
Q_t-4**op
| |
整体公式  
描述: 单季度营业利润同比增速基础面因子因子公式单季度营业利润同比增速:Qtop−Qt−4op∣Qt−4op∣ \frac{Q_t^{op} - Q_{t-4}^{op}}{|Q_{t-4}^{op}|} ∣Qt−4op​∣Qtop​−Qt−4op​​公式说明：QtopQ_t^{op}Qtop​:表示公司最近一个季度的营业利润。营业利润是指企业在销售商品或提供劳务等主营业务活动中所产生的利润，是衡量企业主...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/1q-operating-profit-yoy-growth-rate
