# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_058  
因子名称: 系统性风险暴露 (Market Beta)  
分类: : 波动率指标  
标签: : 流动性, market, 质量, beta, 动量, 成长, 价值, 量化交易  
原始公式: \beta_i = \frac{cov (r_i, r_m)}{var (r_m)}

E(r_i) = r_f + \beta_i (E(r_m) - r_f)

r_i

r_m

E(r_i)

E(r_m)

r_f

cov(r_i, r_m)

var(r_m)

参数说明：rir_iri：​:股票i在过去K个月的月度收益率，计算公式为：$r_{i,t} = (P_{i,t} - P_{i,t-1})/P_{i,t-1}$，其中$P_{i,t}$为股票i在t月末的收盘价。rmr_mrm​:市场在过去K个月的月度收益率，通常使用市场指数（如沪深300指数，标普500指数等）的收益率作为代理。计算公式为：$r_{m,t} = (I_{t} - I_{t-1})/I_{t-1}$，其中$I_{t}$为市场指数在t月末的收盘价。E(ri)E(r_i)E(ri​):股票i的预期收益率。E(rm)E(r_m)E(rm​):市场组合的预期收益率。rfr_frf​:无风险利率，通常使用短期国债收益率作为代理。例如，可以使用同期国债的年化到期收益率，然后将其换算为月度收益率。cov(ri,rm)cov(r_i, r_m)cov(ri​,rm​):股票i的月度收益率$r_i$和市场月度收益率$r_m$的协方差，衡量两者的同向变动关系强度。var(rm)var(r_m)var(rm​):市场月度收益率$r_m$的方差，衡量市场收益率的波动程度。因子解释系统性风险暴露 (市场Beta) 反映了个股收益率对市场整体收益率波动的敏感性，是衡量股票系统性风险的重要指标。Beta值大于1的股票，其收益率波动幅度通常大于市场平均水平，属于高风险高收益类型；Beta值小于1的股票，其收益率波动幅度通常小于市场平均水平，属于低风险低收益类型；Beta值等于1的股票，其收益率波动幅度与市场平均水平一致。 CAPM模型假设，市场Beta与股票的预期收益率呈正相关关系，即Beta值越高，股票的预期收益率也越高，反之亦然。在实际应用中，可以通过滚动计算的方式，动态跟踪股票的Beta值变化。需要注意的是，CAPM模型是理论模型，实际市场中可能存在各种因素影响，例如，个股的特质风险，投资者情绪等等，使得实际收益率与CAPM模型预测值存在偏差。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Fama, Eugene F., and James D. MacBeth. (1973). Risk, return, and equilibrium: Empirical tests. Journal of Political EconomyRelated Factors 下行风险贝塔 下尾风险贝塔 Frazzini-Pedersen 调整贝塔 系统性尾部风险暴露 特异性收益波动因子 系统偏度风险溢价因子 个股特质波动率 市场收益率协偏度因子 Dimson调整贝塔 市场在过去K个月的月度收益率，通常使用市场指数（如沪深300指数，标普500指数等）的收益率作为代理。计算公式为：$r_{m,t} = (I_{t} - I_{t-1})/I_{t-1}$，其中$I_{t}$为市场指数在t月末的收盘价。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 其中：rir_iri​:股票i在过去K个月的月度收益率，计算公式为：$r_{i,t} = (P_{i,t} - P_{i,t-1})/P_{i,t-1}$，其中$P_{i,t}$为股票i在t月末的收盘价。rmr_mrm​:市场在过去K个月的月度收益率，通常使用市场指数（如沪深300指数，标普500指数等）的收益率作为代理。计算公式为：$r_{m,t} = (I_{t} - I_{t-1})/I_{t-1}$，其中$I_{t}$为市场指数在t月末的收盘价。E(ri)E(r_i)E(ri​):股票i的预期收益率。E(rm)E(r_m)E(rm​):市场组合的预期收益率。rfr_frf​:无风险利率，通常使用短期国债收益率作为代理。例如，可以使用同期国债的年化到期收益率，然后将其换算为月度收益率。cov(ri,rm)cov(r_i, r_m)cov(ri​,rm​):股票i的月度收益率$r_i$和市场月度收益率$r_m$的协方差，衡量两者的同向变动关系强度。var(rm)var(r_m)var(rm...  
DSL公式: beta_i = /cov (r_i, r_m)var (r_m)
E(r_i) = r_f + beta_i (E(r_m) - r_f)
r_i
r_m
E(r_i)
E(r_m)
r_f
cov(r_i, r_m)
var(r_m)  
描述: 系统性风险暴露 (Market Beta)波动率因子因子公式Beta 系数计算公式:βi=cov(ri,rm)var(rm) \beta_i = \frac{cov (r_i, r_m)}{var (r_m)} βi​=var(rm​)cov(ri​,rm​)​CAPM 模型:E(ri)=rf+βi(E(rm)−rf) E(r_i) = r_f + \beta_i (E(r_m) - r_f) E...
因子类型: : 波动率指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/volatility/market-beta
