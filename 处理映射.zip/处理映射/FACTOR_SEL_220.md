# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_220  
因子名称: 每股自由现金流（FCF Per Share）  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, fcf, 每股自由现金流, 质量, share, 动量, 成长  
原始公式: Average Shares Outstanding = \frac{Beginning Shares Outstanding + Ending Shares Outstanding}{2}

FCF Per Share = \frac{Trailing Twelve Months Free Cash Flow (TTM)}{Average Shares Outstanding}

Beginning Shares Outstanding

Ending Shares Outstanding

Average Shares Outstanding

Trailing Twelve Months Free Cash Flow (TTM)

FCF Per Share  
DSL公式: Average Shares Outstanding = /Beginning Shares Outstanding + Ending Shares Outstanding2
FCF Per Share = /Trailing Twelve Months Free Cash Flow (TTM)Average Shares Outstanding
Beginning Shares Outstanding
Ending Shares Outstanding
Average Shares Outstanding
Trailing Twelve Months Free Cash Flow (TTM)
FCF Per Share  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。斯蒂芬·佩因（Stephen Penman）. (2018). 企业财务报表分析与估值. 清华大学出版社麦肯锡公司（McKinsey & Company）. (2022). 价值评估：公司价值的衡量与管理（第七版）. 机械工业出版社 每股自由现金流 (FCF Per Share) 提供了公司每股普通股对应的自由现金流规模，比单纯的自由...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/free-cash-flow-per-share
