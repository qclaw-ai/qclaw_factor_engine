# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_152  
因子名称: 单季度成本费用利润率同比增速  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 动量, 成长, 价值, 单季度成本费用利润率同比增速, 量化交易  
原始公式: \frac{CurrentQuarterCostExpenseMargin - PreviousYearSameQuarterCostExpenseMargin}{abs(PreviousYearSameQuarterCostExpenseMargin)}

CurrentQuarterCostExpenseMargin

PreviousYearSameQuarterCostExpenseMargin  
DSL公式: /CurrentQuarterCostExpenseMargin - PreviousYearSameQuarterCostExpenseMarginabs(PreviousYearSameQuarterCostExpenseMargin)
CurrentQuarterCostExpenseMargin
PreviousYearSameQuarterCostExpenseMargin  
描述: 因子解释该因子属于成长性因子，具体而言，它衡量的是公司在单季度维度下，成本费用利润率的同比增长情况。相比于环比增长率，同比增长率更能反映公司盈利能力的真实增长趋势，减少季节性波动的影响。该因子使用单季度数据，而非TTM（最近12个月）数据，更能捕捉公司盈利能力短期内的变化。选择使用增长率而非增量，是因为增长率更具可比性，能更好地反映不同规模公司之间的增长情况。成本费用利润率是衡量公司盈利能力的重要...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/year-over-year-growth-in-single-quarter-cost-expense-margins
