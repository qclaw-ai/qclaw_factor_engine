# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_212  
因子名称: 归母净利润加速增长动量因子  
分类: : 基本面指标  
标签: : 归母净利润加速增长动量因子, 流动性, 基本面指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \text{NetProfitTTMGrowth}_{q} = \frac{\text{NetProfitTTM}_{q} - \text{NetProfitTTM}_{q-1}}{\text{NetProfitTTM}_{q-1}}

通过回归模型拟合连续N个季度的单季度归母净利润数据，并提取二次项系数作为增长加速度的代理变量。回归模型公式如下:

\text{NetProfit}_{t} = \alpha t^2 + \beta t + c

\text{NetProfitTTMGrowth}_{q}

\text{NetProfitTTM}_{q}

\text{NetProfitTTM}_{q-1}

\text{NetProfit}_{t}

\alpha

\beta

参数说明：TTM：为滚动12个月数据。NetProfitTTMq\text{NetProfitTTM}_{q}NetProfitTTMq​:第q季度的滚动12个月归母净利润。NetProfitTTMq−1\text{NetProfitTTM}_{q-1}NetProfitTTMq−1​:第q-1季度的滚动12个月归母净利润。NetProfitt\text{NetProfit}_{t}NetProfitt​:第t季度的单季度归母净利润α\alphaα:业绩增长加速度的代理变量，即二次回归模型中的二次项系数。该系数大于0表示业绩增长加速，小于0表示增长减速。β\betaβ:二次回归模型中的一次项系数，表示业绩增长的线性趋势。ccc:二次回归模型中的常数项，表示基期业绩水平。ttt:季度序号，从最早的季度开始计数，例如，若选取连续四个季度进行回归，则t取值为1，2，3，4 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors归母净利润加速增长动量基础面因子因子公式归母净利润TTM环比增速:NetProfitTTMGrowthq=NetProfitTTMq−NetProfitTTMq−1NetProfitTTMq−1 \t...  
DSL公式: \textNetProfitTTMGrowth_q = /\textNetProfitTTM_q - \textNetProfitTTM_q-1\textNetProfitTTM_q-1
通过回归模型拟合连续N个季度的单季度归母净利润数据，并提取二次项系数作为增长加速度的代理变量。回归模型公式如下:
\textNetProfit_t = alpha t**2 + beta t + c
\textNetProfitTTMGrowth_q
\textNetProfitTTM_q
\textNetProfitTTM_q-1
\textNetProfit_t
alpha
beta  
描述: 通过回归模型拟合连续N个季度的单季度归母净利润数据，并提取二次项系数作为增长加速度的代理变量。回归模型公式如下: 通过回归模型拟合连续N个季度的单季度归母净利润数据，并提取二次项系数作为增长加速度的代理变量。回归模型公式如下: 通过回归模型拟合连续N个季度的单季度归母净利润数据，并提取二次项系数作为增长加速度的代理变量。回归模型公式如下: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/performance-trend
