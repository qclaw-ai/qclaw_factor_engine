# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_354  
因子名称: 标准化意外盈余  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 动量, 成长, 规模, 价值, 量化交易  
原始公式: \frac{UE_t}{std(UE_{t-7}, ..., UE_t)}

EPS_t - EPS_{t,expected}

SUE

UE_t

std(UE_{t-7}, ..., UE_t)

EPS_t

EPS_{t,expected}

参数说明：SUESUESUE：标准化意外盈余（Standardized Unexpected Earnings）。UEtUE_tUEt​:当前第t季度的盈余意外值（Unexpected Earnings），即实际每股收益与市场预期每股收益之差。std(UEt−7,...,UEt)std(UE_{t-7}, ..., UE_t)std(UEt−7​,...,UEt​):过去八个季度（包括当前季度）的盈余意外值 (UE) 的标准差，用于衡量公司盈利预测偏差的波动程度。EPStEPS_tEPSt​:当前第t季度的实际每股收益 (Earnings Per Share).EPSt,expectedEPS_{t,expected}EPSt,expected​:当前第t季度的市场预期每股收益 (Expected Earnings Per Share).因子解释标准化意外盈余（SUE）是衡量盈余公告后价格漂移效应（Post-Earnings Announcement Drift, PEAD）的经典指标。该效应是指，当公司实际盈利显著高于（或低于）市场预期盈利时，在盈余公告发布后的一段时间内（通常为3-6个月），其股票价格会持续出现正向（或负向）的超额回报。SUE可以用于识别这种盈余意外带来的投资机会，高SUE值通常预示着股票价格的潜在上行空间，反之亦然。需要注意的是，SUE的有效性可能受到市场情绪、行业特性以及公司具体情况等多种因素的影响，不宜作为单一投资决策依据。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Foster, George, Chris Olsen, and Terry Shevlin. (1984). Earnings releases, anomalies, and the behavior of security returns. Accounting ReviewRelated Factors 标准化季度营收意外 标准化盈利超预期因子 盈余公告超额收益率 每股盈余公积金 预期市盈率调整幅度 分析师一致预期EPS修正比率 分析师预期EPS调整幅度 每股留存收益 盈余波动率因子 (Earnings Volatility Factor) ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 标准化意外盈余（SUE）是衡量盈余公告后价格漂移效应（Post-Earnings Announcement Drift, PEAD）的经典指标。该效应是指，当公司实际盈利显著高于（或低于）市场预期盈利时，在盈余公告发布后的一段时间内（通常为3-6个月），其股票价格会持续出现正向（或负向）的超额回报。SUE可以用于识别这种盈余意外带来的投资机会，高SUE值通常预示着股票价格的潜在上行空间，反之亦然。需要注意的是，SUE的有效性可能受到市场情绪、行业特性以及公司具体情况等多种因素的影响，不宜作为单一投资决策依据。 因子公式标准化意外盈余 (SUE) = UEtstd(UEt−7,...,UEt) \frac{UE_t}{std(UE_{t-7}, ..., UE_t)} std(UEt−7​,...,UEt​)UEt​​盈余意外值 (UE) = EPSt−EPSt,expected EPS_t - EPS_{t,expected} EPSt​−EPSt,expected​其中：SUESUESUE:标准化意外盈余（Standardized Unexpected Earnings）。UEtUE_tUEt​:当前第t季度的盈余意外值（Unexpected Earnings），即实际每股收益与市场预期每股收益之差。std(UEt−7,...,UEt)std(UE_{t-7}, ..., UE_t)std(UEt−7​,...,UEt​):过去八个季度（包括当前季度）的盈余意外值 (UE) 的标准差，用于衡量公司盈利预测偏差的波动程度。EPStEPS_tEPSt​:当前第t季度的实际每股收益 (Earnings Per S...  
DSL公式: /UE_tstd(UE_t-7, ..., UE_t)
EPS_t - EPS_t,expected
SUE
UE_t
std(UE_t-7, ..., UE_t)
EPS_t
EPS_t,expected  
描述: 标准化意外盈余 (Standardized Unexpected Earnings, SUE)基础面因子因子公式标准化意外盈余 (SUE) = UEtstd(UEt−7,...,UEt) \frac{UE_t}{std(UE_{t-7}, ..., UE_t)} std(UEt−7​,...,UEt​)UEt​​盈余意外值 (UE) = EPSt−EPSt,expected EPS_t - EPS...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/standardized-unexpected-earnings
