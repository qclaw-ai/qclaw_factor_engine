# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_262  
因子名称: 财务相似度加权收益动量  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 质量, 动量, 成长, 财务相似度加权收益动量, 价值, 量化交易  
原始公式: F-Moment_{it} = \frac{\sum_{j \neq i} F-link_{ijt} \cdot Ret_{jt}}{\sum_{j \neq i} F-link_{ijt}}

F-link_{ijt} = \frac{\sum_{k=1}^{10} C_{itk} \cdot C_{jtk}}{\sqrt{\sum_{k=1}^{10} C_{itk}^2} \cdot \sqrt{\sum_{k=1}^{10} C_{jtk}^2}}

F-Moment_{it}

F-link_{ijt}

C_{itk}

Ret_{jt}

参数说明：F：−MomentitF-Moment_{it}F−Momentit​:表示公司 i 在 t 时刻的财务相似度加权收益动量因子值。F−linkijtF-link_{ijt}F−linkijt​:为公司 i 和 j 在 t 时刻的财务关联度，使用余弦相似度计算得出，衡量两家公司在财务指标上的相似程度。数值越高，表示两家公司财务结构越相似。CitkC_{itk}Citk​:为公司 i 在 t 时刻第 k 个财务因子的标准化取值。这里的 k 涵盖了10个经过筛选的低相关性财务因子，这些因子分别来自偿债能力、营运能力、盈利能力和企业发展能力四个维度，例如资产负债率、存货周转率、净利润率、营收增长率等。通过标准化处理（例如z-score标准化），确保不同量纲的因子具有可比性。RetjtRet_{jt}Retjt​:表示公司 j 在 t 时刻的月度收益率，可以是算术收益率或对数收益率，但需保持一致性。该收益率用于衡量公司 j 在当月的股票表现。因子解释该财务相似度加权收益动量因子，计算核心是先构建一个基于财务数据相似度的权重矩阵，然后对各公司的月度收益率进行加权求和。公式的分母是对相似度权重进行归一化处理，使最终的因子值更具可比性。为了消除收益率数据中可能存在的月度反转效应，通常会对生成的因子与月度收益率进行正交化处理。该因子反映了财务结构相似的公司在股票收益上的协同效应，即财务基本面相似的公司，其股票价格波动也可能存在同步性或相互影响。该因子具有潜在的选股价值。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。郑兆磊. (2021). 财报季的财务效应研究和因子构建. 兴业证券Related Factors 排序动量因子 分析师共识覆盖加权动量 科技关联加权动量因子 多时域移动平均动量因子 收益动量一致性因子 客户加权动量因子 行业领头羊动量溢价因子 过去K个月累计收益率动量因子 时间序列动量 (TSMOM) Factors DirectoryQuantitative Trading Factors财务相似度加权收益动量情绪因子因子公式财务相似度加权收益动量因子 (F-Moment):F−Momentit=∑j≠iF−linkijt⋅Retjt∑j≠iF−linkijt F-Moment_{it} = \frac{\sum_{j \neq i} F-link_{ijt} \cdot Ret_{jt}}{\sum_{j \neq i} F-link_{ijt}} F−Momentit​=∑j=i​F−linkijt​∑j=i​F−linkijt​⋅Retjt​​公司 i 和 j 在 t 时刻的财务关联度 (F-link):F−linkijt=∑k=110Citk⋅Cjtk∑k=110Citk2⋅∑k=110Cjtk2 F-link_{ijt} = \frac{\sum_{k=1}^{10} C_{itk} \cdot C_{jtk}}{\sqrt{\sum_{k=1}^{10} C_{itk}^2} \cdot \sqrt{\sum_{k=1}^{10} C...  
DSL公式: F-Moment_it = /SUM_j != i F-link_ijt * Ret_jtSUM_j != i F-link_ijt
F-link_ijt = /SUM_k=1**10 C_itk * C_jtkSQRTSUM_k=1**10 C_itk**2 * SQRTSUM_k=1**10 C_jtk**2
F-Moment_it
F-link_ijt
C_itk
Ret_jt  
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors财务相似度加权收益动量情绪因子因子公式财务相似度加权收益动量因子 (F-Moment):F−Momentit=∑j≠iF−linkijt⋅...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/financial-momentum
