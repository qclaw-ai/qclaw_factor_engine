# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_340  
因子名称: 最小收益率 (MinReturn)  
分类: : 动量指标  
标签: : 流动性, 波动率, 质量, 动量, 成长, 价值, minreturn, 量化交易  
原始公式: MinReturn = - \min(R_t, R_{t-1}, ..., R_{t-K+1})

MinReturn

R_t

min()  
DSL公式: MinReturn = - MIN(R_t, R_t-1, ..., R_t-K+1)
MinReturn
R_t
min()  
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors最小收益率 (MinReturn)动量因子因子公式MinReturn = -min(R_t, R_{t-1}, ..., R_{t-K+1...
因子类型: : 动量指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/momentum/minimum-yield
