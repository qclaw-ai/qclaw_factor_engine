# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_105  
因子名称: 开盘后主动买入强度标准化均值  
分类: : 技术指标  
标签: : 开盘后主动买入强度标准化均值, 流动性, 技术指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{1}{T}\sum_{n=t}^{t-T+1} \frac{mean(NetBuyVolume_{i,n})}{std(NetBuyVolume_{i,n})}

NetBuyVolume_{i,n} = BuyVolume_{i,n} - SellVolume_{i,n}

NetBuyVolume_{i,n}

mean(NetBuyVolume_{i,n})

std(NetBuyVolume_{i,n})

\frac{mean(NetBuyVolume_{i,n})}{std(NetBuyVolume_{i,n})}

参数说明：NetBuyVolumei：,nNetBuyVolume_{i,n}NetBuyVolumei,n​:第i只股票在第n个交易日内，开盘后指定时间段（通常为30分钟）内的净主动买入成交额。该值等于主动买入成交额减去主动卖出成交额。主动买入/卖出成交额的判定基于逐笔成交数据中的BS标志，其中B表示主动买入（买方主动以卖方报价成交），S表示主动卖出（卖方主动以买方报价成交）。为避免极端价格影响，已剔除了涨跌停分钟的成交额数据。mean(NetBuyVolumei,n)mean(NetBuyVolume_{i,n})mean(NetBuyVolumei,n​):第i只股票在第n个交易日内，开盘后指定时间段（通常为30分钟）内，净主动买入成交额的均值。这里是对该时间段内的分钟级别净主动买入额取平均。std(NetBuyVolumei,n)std(NetBuyVolume_{i,n})std(NetBuyVolumei,n​):第i只股票在第n个交易日内，开盘后指定时间段（通常为30分钟）内，净主动买入成交额的标准差。这里是对该时间段内的分钟级别净主动买入额计算标准差，衡量该时间段内的净主动买入成交额的波动性。mean(NetBuyVolumei,n)std(NetBuyVolumei,n)\frac{mean(NetBuyVolume_{i,n})}{std(NetBuyVolume_{i,n})}std(NetBuyVolumei,n​)mean(NetBuyVolumei,n​)​:第i只股票在第n个交易日内，开盘后指定时间段（通常为30分钟）内，净主动买入成交额的均值除以标准差，用于衡量该股票在该时间段内主动买入强度的标准化值，其值越高，代表该股票在开盘后一段时间内主动买入意愿更强烈和稳定。TTT:回溯计算的时间窗口长度。对于月度选股，T通常设置为20个交易日；对于周度选股，T通常设置为5个交易日。这个参数决定了在计算因子值时，考虑过去多少个交易日的净主动买入成交额。ttt:当前交易日。 第i只股票在第n个交易日内，开盘后指定时间段（通常为30分钟）内，净主动买入成交额的标准差。这里是对该时间段内的分钟级别净主动买入额计算标准差，衡量该时间段内的净主动买入成交额的波动性。 第i只股票在第n个交易日内，开盘后指定时间段（通常为30分钟）内，净主动买入成交额的均值除以标准差，用于衡量该股票在该时间段内主动买入强度的标准化值，其值越高，代表该股票在开盘后一段时间内主动买入意愿更强烈和稳定。 回溯计算的时间窗口长度。对于月度选股，T通常设置为20个交易日；对于周度选股，T通常设置为5个交易日。这个参数决定了在计算因子值时，考虑过去多少个交易日的净主动买入成交额。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 开盘后主动买入强度标准化均值技术因子因子公式开盘后主动买入强度标准化均值:1T∑n=tt−T+1mean(NetBuyVolumei,n)std(NetBuyVolumei,n) \frac{1}{T}\sum_{n=t}^{t-T+1} \frac{mean(NetBuyVolume_{i,n})}{std(NetBuyVolume_{i,n})} T1​n=t∑t−T+1​std(NetBuyVolumei,n​)mean(NetBuyVolumei,n​)​净主动买入成交额:NetBuyVolumei,n=BuyVolumei,n−SellVolumei,n NetBuyVolume_{i,n} = BuyVolume_{i,n} - SellVolume_{i,n} NetBuyVolumei,n​=BuyVolumei,n​−SellVolumei,n​其中:NetBuyVolumei,nNetBuyVolume_{i,n}NetBuyVolumei,n​:第i只股票在第n个交易日内，开盘后指定时间段（通常为30分钟）内的净主动买入成交额。该值等于主动买入成交额减去主动卖出成交额。主动买入/卖出成交额的判定基于逐笔成交数据中的BS标志，其中B表示主动买入（买方主动以卖方报价成交），S表示主动卖出（卖方主动以买方报价成交）。为避免极端价格影响，已剔除了涨跌停分钟的成交额数据。mean(NetBuyVolumei,n)mean(NetBuyVolume_{i,n})mean(NetBuyVolumei,n​):第i只股票在第n个交易日内，开盘后指定时间段（通常为30分钟）内，净主动买入成交额的均值。这里是对该时间段内的分钟级别净主动买入额取平均。std(NetBuyVolumei,n)std(NetBuyVolume_{i,n})std(NetBuyVolumei...  
DSL公式: /1TSUM_n=t**t-T+1 /mean(NetBuyVolume_i,n)std(NetBuyVolume_i,n)
NetBuyVolume_i,n = BuyVolume_i,n - SellVolume_i,n
NetBuyVolume_i,n
mean(NetBuyVolume_i,n)
std(NetBuyVolume_i,n)
/mean(NetBuyVolume_i,n)std(NetBuyVolume_i,n)  
描述: 其中:NetBuyVolumei,nNetBuyVolume_{i,n}NetBuyVolumei,n​:第i只股票在第n个交易日内，开盘后指定时间段（通常为30分钟）内的净主动买入成交额。该值等于主动买入成交额减去主动卖出成交额。主动买入/卖出成交额的判定基于逐笔成交数据中的BS标志，其中B表示主动买入（买方主动以卖方报价成交），S表示主动卖出（卖方主动以买方报价成交）。为避免极端价格影响，已剔...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/net-buyer-intensity-after-opening
