# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_285  
因子名称: 权益乘数倒数 (Equity-to-Asset Ratio)  
分类: : 基本面指标  
标签: : 流动性, ratio, 基本面指标, 权益乘数倒数, asset, equity, 动量, 成长  
原始公式: \frac{\text{Total Shareholders' Equity}}{\text{Total Assets}}

\text{Total Shareholders' Equity}

\text{Total Assets}  
DSL公式: /\textTotal Shareholders' Equity\textTotal Assets
\textTotal Shareholders' Equity
\textTotal Assets  
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors权益乘数倒数基础面因子因子公式权益乘数倒数 (Equity-to-Asset Ratio):Total Shareholders’ Equ...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/equity-ratio
