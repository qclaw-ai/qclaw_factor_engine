# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_226  
因子名称: 应计盈余比率（经标准化）  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 动量, 成长, 经标准化, 价值, 量化交易  
原始公式: AccrualsRatio = \frac{(\Delta CA - \Delta Cash) - (\Delta CL - \Delta STD - \Delta TP) - Dep}{AverageTotalAssets}

\Delta CA - \Delta Cash

\Delta CA

\Delta Cash

\Delta CL - \Delta STD - \Delta TP

\Delta CL

\Delta STD

\Delta TP

Dep

AverageTotalAssets

参数说明：ΔCA−ΔCash\Delta CA - \Delta CashΔCA−ΔCash:流动资产的净变动，扣除现金及现金等价物净增加额，反映了非现金流动资产的变动。ΔCA\Delta CAΔCA:流动资产的变动，指报告期末流动资产总额减去报告期初流动资产总额的差值。ΔCash\Delta CashΔCash:现金及现金等价物净增加额，指报告期内现金和现金等价物的净流入减去净流出的差额。ΔCL−ΔSTD−ΔTP\Delta CL - \Delta STD - \Delta TPΔCL−ΔSTD−ΔTP:流动负债的净变动，扣除短期借款变动和应付税款变动，反映了由经营活动产生的非现金流动负债的变动。ΔCL\Delta CLΔCL:流动负债的变动，指报告期末流动负债总额减去报告期初流动负债总额的差值。ΔSTD\Delta STDΔSTD:流动负债中的短期借款的变动，指报告期末短期借款总额减去报告期初短期借款总额的差值。ΔTP\Delta TPΔTP:应付税款的变动，指报告期末应付税款总额减去报告期初应付税款总额的差值。DepDepDep:折旧与摊销，指报告期内计提的折旧和摊销费用总额，代表非现金费用。AverageTotalAssetsAverageTotalAssetsAverageTotalAssets:平均总资产，指报告期期初总资产和期末总资产的平均值。用以对分子中的应计盈余进行标准化，消除不同规模公司之间的可比性差异。 应计质量 应计盈余比率（总额） 应计盈余资产比率 (Accruals-to-Assets Ratio) 修正琼斯模型操纵性应计盈余 非操纵性应计利润比率 应计盈余比率 (Accruals Ratio) 现金资产占比因...  
DSL公式: AccrualsRatio = /(\Delta CA - \Delta Cash) - (\Delta CL - \Delta STD - \Delta TP) - DepAverageTotalAssets
\Delta CA - \Delta Cash
\Delta CA
\Delta Cash
\Delta CL - \Delta STD - \Delta TP
\Delta CL
\Delta STD
\Delta TP
Dep
AverageTotalAssets  
描述: 应计盈余比率计算公式:AccrualsRatio=(ΔCA−ΔCash)−(ΔCL−ΔSTD−ΔTP)−DepAverageTotalAssets AccrualsRatio = \frac{(\Delta CA - \Delta Cash) - (\Delta CL - \Delta STD - \Delta TP) - Dep}{AverageTotalAssets} AccrualsRati...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/total-accrued-surplus
