# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_184  
因子名称: Dimson调整贝塔  
分类: : 技术指标  
标签: : 流动性, 技术指标, dimson, 质量, 动量, 调整贝塔, 成长, 价值  
原始公式: r_{i,t} - r_{f,t} = \alpha_i + \beta_{i,lag} (r_{m,t-1} - r_{f,t-1}) + \beta_{i,current} (r_{m,t} - r_{f,t}) + \beta_{i,lead} (r_{m,t+1} - r_{f,t+1}) + \epsilon_{i,t}

\beta_{Dimson} = \hat{\beta}_{i,lag} + \hat{\beta}_{i,current} + \hat{\beta}_{i,lead}

r_{i,t}

r_{m,t}

r_{f,t}

r_{i,t-1}

r_{m,t-1}

r_{f,t-1}

r_{i,t+1}

r_{m,t+1}

参数说明：ri：,tr_{i,t}ri,t​:在时间 $t$ 时刻，股票 $i$ 的收益率。rm,tr_{m,t}rm,t​:在时间 $t$ 时刻，市场组合的收益率。rf,tr_{f,t}rf,t​:在时间 $t$ 时刻，无风险利率。ri,t−1r_{i,t-1}ri,t−1​:在时间 $t-1$ 时刻，股票 $i$ 的收益率。rm,t−1r_{m,t-1}rm,t−1​:在时间 $t-1$ 时刻，市场组合的收益率。rf,t−1r_{f,t-1}rf,t−1​:在时间 $t-1$ 时刻，无风险利率。ri,t+1r_{i,t+1}ri,t+1​:在时间 $t+1$ 时刻，股票 $i$ 的收益率。rm,t+1r_{m,t+1}rm,t+1​:在时间 $t+1$ 时刻，市场组合的收益率。rf,t+1r_{f,t+1}rf,t+1​:在时间 $t+1$ 时刻，无风险利率。αi\alpha_iαi​:股票 $i$ 的截距项，表示市场风险溢价为0时，股票的期望收益率。βi,lag\beta_{i,lag}βi,lag​:股票 $i$ 收益率对市场收益率滞后一期的敏感度（回归系数），反映了市场收益率前一期变动对股票当前收益率的影响。βi,current\beta_{i,current}βi,current​:股票 $i$ 收益率对当前市场收益率的敏感度（回归系数），表示当前市场收益率变动对股票当前收益率的影响。βi,lead\beta_{i,lead}βi,lead​:股票 $i$ 收益率对市场收益率超前一期的敏感度（回归系数），反映了市场收益率后一期变动对股票当前收益率的影响。ϵi,t\epsilon_{i,t}ϵi,t​:回归模型的残差项，代表了模型无法解释的股票收益率波动。βDimson{\beta}_{Dimson}βDimson​:Dimson调整贝塔，是对滞后、当前和超前市场风险溢价的贝塔系数之和，用于度量股票的系统性风险。 其中:ri,tr_{i,t}ri,t​:在时间 $t$ 时刻，股票 $i$ 的收益率。rm,tr_{m,t}rm,t​:在时间 $t$ 时刻，市场组合的收益率。rf,tr_{f,t}rf,t​:在时间 $t$ 时刻，无风险利率。ri,t−1r_{i,t-1}ri,t−1​:在时间 $t-1$ 时刻，股票 $i$ 的收益率。rm,t−1r_{m,t-1}rm,t−1​:在时间 $t-1$ 时刻，市场组合的收益率。rf,t−1r_{f,t-1}rf,t−1​:在时间 $t-1$ 时刻，无风险利率。ri,t+1r_{i,t+1}ri,t+1​:在时间 $t+1$ 时刻，股票 $i$ 的收益率。rm,t+1r_{m,t+1}rm,t+1​:在时间 $t+1$ 时刻，市场组合的收益率。rf,t+1r_{f,t+1}rf,t+1​:在时间 $t+1$ 时刻，无风险利率。αi\alpha_iαi​:股票 $i$ 的截距项，表示市场风险溢价为0时，股票的期望收益率。βi,lag\beta_{i,lag}β...  
DSL公式: r_i,t - r_f,t = alpha_i + beta_i,lag (r_m,t-1 - r_f,t-1) + beta_i,current (r_m,t - r_f,t) + beta_i,lead (r_m,t+1 - r_f,t+1) + epsilon_i,t
beta_Dimson = \hatbeta_i,lag + \hatbeta_i,current + \hatbeta_i,lead
r_i,t
r_m,t
r_f,t
r_i,t-1
r_m,t-1
r_f,t-1
r_i,t+1
r_m,t+1  
描述: Related Factors Frazzini-Pedersen 调整贝塔 系统性风险暴露 (Market Beta) 下尾风险贝塔 下行风险贝塔 市场反应滞后因子 Fama-French三因子模型残差动量 情绪敏感度因子 残差市值偏离度 系统性尾部风险暴露 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 因子公式Dimson回归模型:...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/dimson-beta
