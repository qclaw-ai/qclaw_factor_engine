# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_003  
因子名称: 价格成交量趋势指标  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 价格成交量趋势指标, 动量, 成长, 价值, 量化交易  
原始公式: PVT_t = PVT_{t-1} + \frac{CLOSE_t - CLOSE_{t-1}}{CLOSE_{t-1}} \times VOL_t
PVT_1 =  \frac{CLOSE_1 - CLOSE_0}{CLOSE_0} \times VOL_1
PVT_t
PVT_{t-1}
CLOSE_t
CLOSE_{t-1}
VOL_t  
DSL公式: PVT_t = PVT_t-1 + /CLOSE_t - CLOSE_t-1CLOSE_t-1 * VOL_t
PVT_1 = /CLOSE_1 - CLOSE_0CLOSE_0 * VOL_1
PVT_t
PVT_t-1
CLOSE_t
CLOSE_t-1
VOL_t  
描述: 价格成交量趋势指标 (PVT) 通过将价格变动幅度与成交量相乘，从而更好地反映了成交量在价格上涨或下跌过程中的动态变化。相较于仅累加成交量的 OBV 指标，PVT 更能体现价格变动对成交量累加的加权影响。具体而言，当收盘价上涨时，成交量会根据涨幅大小被加权，涨幅越大，则累加到 PVT 的成交量越多；反之亦然。因此，PVT 可以更准确地揭示市场参与者在不同价格水平下的活跃程度，以及潜在的市场趋势和动...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/price-volume-trend
