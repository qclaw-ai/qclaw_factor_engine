# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_277  
因子名称: 应收账款周转率（年化）  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 年化, 应收账款周转率, 质量, 动量, 成长, 价值  
原始公式: \frac{\text{最近12个月营业收入(TTM)}}{\text{平均应收账款}}

\text{平均应收账款} = \frac{\text{期初应收账款} + \text{期末应收账款}}{2}

\text{最近12个月营业收入(TTM)}

\text{平均应收账款}

\text{期初应收账款}

\text{期末应收账款}  
DSL公式: /\text最近12个月营业收入(TTM)\text平均应收账款
\text平均应收账款 = /\text期初应收账款 + \text期末应收账款2
\text最近12个月营业收入(TTM)
\text平均应收账款
\text期初应收账款
\text期末应收账款  
描述: Related Factors 应收账款周转率 流动资产周转率 (Current Asset Turnover Ratio) 应付账款周转率(TTM) 应付账款周转天数 (Days Sales Outstanding in Accounts Payable) 权益周转率 固定资产周转率(TTM) 总资产周转率(TTM) 应收账款周转天数 (Days Sales Outstanding, DSO) ...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/accounts-receivable-turnover
