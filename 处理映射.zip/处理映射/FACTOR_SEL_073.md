# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_073  
因子名称: 月度相对换手率溢出  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 质量, 动量, 成长, 月度相对换手率溢出, 价值, 量化交易  
原始公式: \frac{mean(Turnover_{t-20:t})}{mean(Turnover_{t-250:t})}

Turnover

t-20:t

t-250:t

mean()  
DSL公式: /mean(Turnover_t-20:t)mean(Turnover_t-250:t)
Turnover
t-20:t
t-250:t
mean()  
描述: Related Factors 月均换手率因子 换手率波动率 股票换手率 (Turnover Rate) 日均负向成交额占比相对强度 市值中性化换手率残差 日均换手率 日内换手率分布离散度 成交额分位数反转强度因子 流动性调整成交量零值天数比率 月度相对换手率溢出因子捕捉短期交易活跃度相对于长期平均水平的偏离。较高的因子值（即短期换手率高于长期平均水平）通常意味着市场情绪高涨，过度交易活跃，股价可...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/monthly-abnormal-turnover
