# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_066  
因子名称: 非流动性变异系数  
分类: : 波动率指标  
标签: : 非流动性变异系数, 流动性, 质量, 动量, 成长, 价值, 量化交易, 波动率指标  
原始公式: ILLIQ_{i,t} = \frac{|r_{i,t}|}{Amount_{i,t}}

CVILLIQ_{i} = \frac{\sigma(ILLIQ_{i})}{\overline{ILLIQ_{i}}}

Amount_{i,t}

r_{i,t}

时间窗口

\sigma(ILLIQ_{i})

\overline{ILLIQ_{i}}

参数说明：Amounti：,tAmount_{i,t}Amounti,t​:股票 i 在 t 时刻的交易金额，通常以成交额（单位为人民币或其他货币）表示，反映了该时刻的市场活跃度。ri,tr_{i,t}ri,t​:股票 i 在 t 时刻的收益率，通常为简单收益率或对数收益率，表示该时刻股票价格的变化幅度。时间窗口时间窗口时间窗口:计算变异系数的时间窗口期，此处为过去20个交易日。时间窗口的选择会影响最终结果，选择时需考虑因子的适用性和时效性。σ(ILLIQi)\sigma(ILLIQ_{i})σ(ILLIQi​):股票 i 的非流动性指标ILLIQ在指定时间窗口内的标准差，衡量了ILLIQ指标在时间窗口内的波动幅度。标准差越大，说明非流动性波动性越高，反之则越低。ILLIQi‾\overline{ILLIQ_{i}}ILLIQi​​:股票 i 的非流动性指标ILLIQ在指定时间窗口内的平均值，反映了该股票在窗口期内的平均非流动性水平。因子解释非流动性变异系数 (CVILLIQ) 衡量了股票非流动性指标（ILLIQ）在一段时间内的波动程度。较高的CVILLIQ值意味着该股票的非流动性波动较大，即买入或卖出该股票时，所面临的市场冲击成本（例如，由于流动性不足导致的价格波动）存在更高的不确定性。因此，投资者可能会要求更高的风险溢价以补偿这种不确定性。该指标可用于识别那些交易成本可能不稳定的股票，或作为量化模型中衡量风险的输入。；具体来说，较高的非流动性变异系数可能暗示以下风险：  
DSL公式: ILLIQ_i,t = /|r_i,t|Amount_i,t
CVILLIQ_i = /sigma(ILLIQ_i)\overlineILLIQ_i
Amount_i,t
r_i,t
时间窗口
sigma(ILLIQ_i)
\overlineILLIQ_i  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Akbas, F.. (2011). The volatility of liquidity and expected stock returns. Doctoral dissertation, Texas A&M University朱剑涛. (2017). 技术类新 Alpha 因子的批量测试. 东方证券 非流动性变异系数波动率因...
因子类型: : 波动率指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/volatility/illiquidity-coefficient-of-variation
