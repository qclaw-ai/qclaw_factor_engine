# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_150  
因子名称: 有形资本回报率环比增长率 (TTM)  
分类: : 成长性指标  
标签: : 流动性, 成长性指标, ttm, 质量, 动量, 成长, 价值, 有形资本回报率环比增长率  
原始公式: \frac{ROTC_{TTM,t} - ROTC_{TTM,t-1}}{|ROTC_{TTM,t-1}|}

ROTC_{TTM,t}

ROTC_{TTM,t-1}  
DSL公式: /ROTC_TTM,t - ROTC_TTM,t-1|ROTC_TTM,t-1|
ROTC_TTM,t
ROTC_TTM,t-1  
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading FactorsTTM有形资本回报率环比增长率成长因子因子公式[(当前报告期TTM有形资本回报率 - 上一报告期TTM有形资本回报率) / |上一报告期T...
因子类型: : 成长性指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/growth/return-on-tangible-capital-rotc-mom-growth-rate
