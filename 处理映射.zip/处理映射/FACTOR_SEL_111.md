# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_111  
因子名称: 价格变动速率因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 价格变动速率因子, 质量, 动量, 成长, 价值, 量化交易  
原始公式: ROC = \frac{P_t - P_{t-N}}{P_{t-N}} = \frac{P_t}{P_{t-N}} - 1

ROCMA_t = SMA(ROC, M) = \frac{ROC_t + ROC_{t-1} + ... + ROC_{t-M+1}}{M}

P_t

P_{t-N}

ROC_t

参数说明：PtP_tPt：​:当前时间t的资产价格，通常为收盘价（CLOSE）。Pt−NP_{t-N}Pt−N​:N个周期前的资产价格，通常为收盘价（CLOSE）。NNN:回溯期，即计算价格变动速率的时间窗口大小，表示使用过去N个周期的价格进行比较。默认值为12，可根据交易频率和市场特性进行调整。较小的N值对价格变化更敏感，可能产生较多噪音；较大的N值则更平滑，但对价格变化反应较慢。ROCtROC_tROCt​:当前时间t的价格变动速率MMM:ROC的移动平均线的窗口大小，用于平滑ROC指标并降低噪音。默认值为6，可根据市场波动性和交易策略进行调整。较小的M值使ROCMA对ROC变化更敏感，较大的M值则更平滑，可过滤短期波动。因子解释价格变动速率（ROC）指标通过比较当前价格与N周期前的价格差异来衡量价格动能。ROC为正值表示价格在上涨，负值表示价格在下跌，数值越大代表动能越强。ROC指标的应用场景包括：  
DSL公式: ROC = /P_t - P_t-NP_t-N = /P_tP_t-N - 1
ROCMA_t = SMA(ROC, M) = /ROC_t + ROC_t-1 + ... + ROC_t-M+1M
P_t
P_t-N
ROC_t  
描述: 阿隆指标 科波克曲线 蔡金资金流量震荡指标 随机摆动指标 随机动量指标 (SMI) 相对强弱指标 (RSI) 商品通道指数 成交量动量摆动指标 钱德动量振荡器 Factors DirectoryQuantitative Trading Factors价格变动速率技术因子因子公式价格变动速率 (ROC):ROC=Pt−Pt−NPt−N=PtPt−N−1 ROC = \frac{P_t - P_{t-...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/rate-of-change
