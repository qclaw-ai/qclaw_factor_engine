# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_017  
因子名称: 成交量动量摆动指标  
分类: : 技术指标  
标签: : 流动性, 技术指标, 成交量动量摆动指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: TR = IF(HIGH+LOW+CLOSE>HIGH[1]+LOW[1]+CLOSE[1],1,-1)

DM = HIGH-LOW

CM = IF(TR=TR[1],CM[1]+DM,DM[1]+DM)

VF = VOL*ABS(2*(DM/CM-1))*TR*100

KVO(N1,N2) = EMA(VF,N1)-EMA(VF,N2)

VOL

EMA

IF(condition, value_if_true, value_if_false)

ABS  
DSL公式: TR = IF(high+low+close>high[1]+low[1]+close[1],1,-1)
DM = high-low
CM = IF(TR=TR[1],CM[1]+DM,DM[1]+DM)
VF = VOL*ABS(2*(DM/CM-1))*TR*100
KVO(N1,N2) = EMA(VF,N1)-EMA(VF,N2)
VOL
EMA
IF(condition, value_if_true, value_if_false)
ABS  
描述: 因子公式TR:TR=IF(HIGH+LOW+CLOSE>HIGH[1]+LOW[1]+CLOSE[1],1,−1) TR = IF(HIGH+LOW+CLOSE>HIGH[1]+LOW[1]+CLOSE[1],1,-1) TR=IF(HIGH+LOW+CLOSE>HIGH[1]+LOW[1]+CLOSE[1],1,−1)真实范围（Trend Reversal）：用于判断当日价格相对前一日的动向。如...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/kvo-indicator
