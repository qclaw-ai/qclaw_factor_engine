# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_090  
因子名称: 分析师一致预期EPS修正比率  
分类: : 情绪指标  
标签: : 流动性, 分析师一致预期, 情绪指标, 质量, 动量, 成长, 修正比率, 价值  
原始公式: EpsRevisionRatio = \frac{N_{up} - N_{down}}{N_{up} + N_{down}}

N_{up}

N_{down}

参数说明：NupN_：{up}Nup​:在过去三个月内，给出该股票每股收益（EPS）上调预测的分析师数量。NdownN_{down}Ndown​:在过去三个月内，给出该股票每股收益（EPS）下调预测的分析师数量。 因子公式分析师一致预期EPS修正比率:EpsRevisionRatio=Nup−NdownNup+Ndown EpsRevisionRatio = \frac{N_{up} - N_{down}}{N_{up} + N_{down}} EpsRevisionRatio=Nup​+Ndown​Nup​−Ndown​​其中:NupN_{up}Nup​:在过去三个月内，给出该股票每股收益（EPS）上调预测的分析师数量。NdownN_{down}Ndown​:在过去三个月内，给出该股票每股收益（EPS）下调预测的分析师数量。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 分析师预期EPS调整幅度 标准化盈利超预期因子 预期市盈率调整幅度 分析师一致预期市盈率倒数 60日盈利市值比率变动 分析师目标价调整动量因子 一致预期收益率 (Consensus Target Price Return) 分析师一致预期偏差度 分析师盈利预测修订动量 因子解释该因子通过计算分析师上调和下调每股收益（EPS）预测的数量差异的相对比例，反映了市场对公司盈利前景的共识预期变化。正值表示市场对公司盈利能力的预期在过去三个月内趋于乐观，负值表示预期趋于悲观。该因子可以捕捉分析师情绪的变动，并作为预测未来股票收益的潜在信号。具体来说，当分析师普遍上调EPS预期时，可能预示着公司未来盈利能力增强，从而股价具有上涨潜力；反之，当分析师普遍下调EPS预期时，则可能预示着公司未来盈利能力减弱，从而股价具有下跌风险。该因子属于分析师情绪因子，同时兼具盈利预期因子的特征。需要注意的是，该因子并非绝对的投资信号，需要结合其他因子和基本面信息进行综合分析。 ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子仅供教育和研究目的，不构成投资建议。•在做出任何投资决策之前，请咨询合格的财务顾问。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。曹春晓. (2018). 基于分析师一致预期的选股研究. 申万宏源 Related Factors 分析师预期EPS调整幅度 标准化盈利超预期因子 预期市盈率调整幅度 分析师一致预期市盈率倒数 60日盈利市值比率变动 分析师目标价调整动量因子 一致预期收益率 (Consensus Target Price Return) 分析师一致预期偏差度 分析师盈利预测修订动量 分析师一致预期EPS修正比率:EpsRevisionRatio=Nup−NdownNup+Ndown EpsRevisionRatio = \frac{N_{up} - N_{down}}{N_{up} + N_{down}} EpsRevisionRatio=Nup​+Ndown​Nup​−Ndown​​ 金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。 该因子通过计算分析师上调和下调每股收益（EPS）预测的数量差异的相对比例，反映了市场对公司盈利前景的共识预期变化。正值表示市场对公司盈利能力的预期在过去三个月内趋于乐观，负值表示预期趋于悲观。该因子可以捕捉分析师情绪的变动，并作为预测未来股票收益的潜在信号。具体来说，当分析师普遍上调EPS预期时，可能预示着公司未来盈利能力增强，从而股价具有上涨潜力；反之，当分析师普遍下调EPS预期时，则可能预示着公司未来盈利能力减弱，从而股价具有下跌风险。该因子属于分析师情绪因子，同时兼具盈利预期因子的特征。需要注意的是，该因子并非绝对的投资信号，需要结合其他因子和基本面信息进行综合分析。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors分析师一致预期EPS修正比率情绪因子因子公式分析师一致预期EPS修正比率:EpsRevisionRatio=Nup−NdownNup+Ndown EpsRevisionRatio = \frac{N_{up} - N_{down}}{N_{up} + N_{down}} EpsRevisionRatio=Nup​+Ndown​Nup​−Ndow...  
DSL公式: EpsRevisionRatio = /N_up - N_downN_up + N_down
N_up
N_down  
描述: 其中:NupN_{up}Nup​:在过去三个月内，给出该股票每股收益（EPS）上调预测的分析师数量。NdownN_{down}Ndown​:在过去三个月内，给出该股票每股收益（EPS）下调预测的分析师数量。 因子公式分析师一致预期EPS修正比率:EpsRevisionRatio=Nup−NdownNup+Ndown EpsRevisionRatio = \frac{N_{up} - N_{down...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/eps-revision-ratio
