# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_194  
因子名称: Amihud非流动性冲击因子  
分类: : 情绪指标  
标签: : 流动性, 非流动性冲击因子, amihud, 情绪指标, 质量, 动量, 成长, 价值  
原始公式: LIQU_{i,t} = - (ILLIQ_{i,t} - AVGILLIQ_{i,t-12,t-1})

ILLIQ_{i,t}

AVGILLIQ_{i,t-12,t-1}

参数说明：ILLIQi：,tILLIQ_{i,t}ILLIQi,t​:为股票 i 在 t 月的 Amihud 非流动性因子。Amihud 非流动性因子 ($ILLIQ_{i,t}$) 通常定义为股票 i 在 t 月的每日绝对收益与每日成交量的比率的平均值。其公式为：$ILLIQ_{i,t} = \frac{1}{D} \sum_{d=1}^{D} \frac{|R_{i,d}|}{V_{i,d}}$, 其中 $R_{i,d}$ 代表股票 i 在 t 月第 d 天的收益， $V_{i,d}$ 代表股票 i 在 t 月第 d 天的成交量（通常以金额或股数计量），D代表t月总交易天数。 该值越高，表明该股票的流动性越差。AVGILLIQi,t−12,t−1AVGILLIQ_{i,t-12,t-1}AVGILLIQi,t−12,t−1​:为股票 i 的Amihud非流动性因子在过去12个月的平均值。计算方式是将股票 i 在 t-12月到 t-1月这12个月的每个月的Amihud非流动性因子 ($ILLIQ_{i,m}$) 求和，然后除以...  
DSL公式: LIQU_i,t = - (ILLIQ_i,t - AVGILLIQ_i,t-12,t-1)
ILLIQ_i,t
AVGILLIQ_i,t-12,t-1  
描述: 为股票 i 的Amihud非流动性因子在过去12个月的平均值。计算方式是将股票 i 在 t-12月到 t-1月这12个月的每个月的Amihud非流动性因子 ($ILLIQ_{i,m}$) 求和，然后除以12。  公式为：$AVGILLIQ_{i,t-12,t-1} = \frac{1}{12} \sum_{m=t-12}^{t-1} ILLIQ_{i,m}$ 。该值反映了过去一年该股票流动性的平均...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/liquidity-shock
