# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_323  
因子名称: 资本支出异常增长率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 动量, 成长, 资本支出异常增长率, 量化交易, 价值  
原始公式: CI_{t-1} = \frac{CE_{t-1}}{\frac{CE_{t-2} + CE_{t-3} + CE_{t-4}}{3}} - 1

CE_{t} = \frac{CAPEX_{t}}{Revenue_{t}}

CI_{t-1}

CE_{t}

CAPEX_{t}

Revenue_{t}  
DSL公式: CI_t-1 = /CE_t-1/CE_t-2 + CE_t-3 + CE_t-43 - 1
CE_t = /CAPEX_tRevenue_t
CI_t-1
CE_t
CAPEX_t
Revenue_t  
描述: 资本支出比率计算公式:CEt=CAPEXtRevenuet CE_{t} = \frac{CAPEX_{t}}{Revenue_{t}} CEt​=Revenuet​CAPEXt​​ 资本支出增长率-N年（CAGR-N） 发行股本增长率 单季度经营活动净现金流同比增速 标准化异常财务变动率 单季度成本费用利润率同比增速 运营成本-固定资产残差因子 应计盈余比率（经标准化） 月度消费指数同比变动率 ...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/abnormal-capital-investment
