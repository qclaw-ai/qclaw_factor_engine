# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_282  
因子名称: 流动性经营资产变动率  
分类: : 基本面指标  
标签: : 流动性, 流动性经营资产变动率, 基本面指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{CurrentOperatingAssets_{t} - CurrentOperatingAssets_{t-1}}{AverageTotalAssets_{t}}

CurrentOperatingAssets_{t} = AccountsReceivable_{t} + NotesReceivable_{t} +  Prepayments_{t} + OtherReceivables_{t} + Inventory_{t} + DeferredExpenses_{t}

AverageTotalAssets_{t} = \frac{TotalAssets_{beginning} + TotalAssets_{end}}{2}

CurrentOperatingAssets_{t}

CurrentOperatingAssets_{t-1}

AverageTotalAssets_{t}

AccountsReceivable_{t}

NotesReceivable_{t}

Prepayments_{t}

OtherReceivables_{t}

参数说明：CurrentOperatingAssetstCurrentOperatingAssets_：{t}CurrentOperatingAssetst​:代表最近报告期（t期）的流动性经营资产总额。CurrentOperatingAssetst−1CurrentOperatingAssets_{t-1}CurrentOperatingAssetst−1​:代表上年同期（t-1期）的流动性经营资产总额。AverageTotalAssetstAverageTotalAssets_{t}AverageTotalAssetst​:代表报告期（t期）的平均总资产。AccountsReceivabletAccountsReceivable_{t}AccountsReceivablet​:代表最近报告期（t期）的应收账款。NotesReceivabletNotesReceivable_{t}NotesReceivablet​:代表最近报告期（t期）的应收票据。PrepaymentstPrepayments_{t}Prepaymentst​:代表最近报告期（t期）的预付款项。OtherReceivablestOtherReceivables_{t}OtherReceivablest​:代表最近报告期（t期）的其他应收款。InventorytInventory_{t}Inventoryt​:代表最近报告期（t期）的存货。DeferredExpensestDeferredExpenses_{t}DeferredExpenses...  
DSL公式: /CurrentOperatingAssets_t - CurrentOperatingAssets_t-1AverageTotalAssets_t
CurrentOperatingAssets_t = AccountsReceivable_t + NotesReceivable_t + Prepayments_t + OtherReceivables_t + Inventory_t + DeferredExpenses_t
AverageTotalAssets_t = /TotalAssets_beginning + TotalAssets_end2
CurrentOperatingAssets_t
CurrentOperatingAssets_t-1
AverageTotalAssets_t
AccountsReceivable_t
NotesReceivable_t
Prepayments_t
OtherReceivables_t  
描述: 流动性经营资产计算公式:CurrentOperatingAssetst=AccountsReceivablet+NotesReceivablet+Prepaymentst+OtherReceivablest+Inventoryt+DeferredExpensest CurrentOperatingAssets_{t} = AccountsReceivable_{t} + NotesReceivab...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/current-asset-turnover
