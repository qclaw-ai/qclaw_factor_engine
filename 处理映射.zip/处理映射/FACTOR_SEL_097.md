# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_097  
因子名称: 集合竞价成交量占比复合因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 动量, 成长, 价值, 量化交易, 集合竞价成交量占比复合因子  
原始公式: OCVR_t = \frac{1}{d}\sum_{i=1}^{d} w_{t-i} \left( \frac{VOL_{call,open,t-i}}{VOL_{total,t-i}} \right)

BCVR_t = \frac{1}{d}\sum_{i=1}^{d} \left( \frac{VOL_{call,close,t-i}}{VOL_{total,t-i}} \right)

OBCVR_t = \alpha OCVR_t + (1 - \alpha)BCVR_t

w_{t-i}

VOL_{call,open,t-i}

VOL_{call,close,t-i}

VOL_{total,t-i}

\alpha

参数说明：wt：−iw_{t-i}wt−i​:开盘集合竞价期间不同时间...  
DSL公式: OCVR_t = /1dSUM_i=1**d w_t-i ( /VOL_call,open,t-iVOL_total,t-i )
BCVR_t = /1dSUM_i=1**d ( /VOL_call,close,t-iVOL_total,t-i )
OBCVR_t = alpha OCVR_t + (1 - alpha)BCVR_t
w_t-i
VOL_call,open,t-i
VOL_call,close,t-i
VOL_total,t-i
alpha  
描述: 计算时间窗口的大小，表示回溯计算的天数。例如，d=5 表示使用过去5个交易日的成交量数据来计算该因子。时间窗口大小的选择会影响因子的平滑度和敏感性，需要根据具体策略进行调整。较小的 d 值会使得因子对近期变化更敏感，较大的 d 值会使因子更平滑。 通过复合开盘和收盘的成交量占比，该因子能更全面地反映市场在一天中不同时段的情绪变化。经验研究表明，在某些情况下，集合竞价成交量占比与股票收益率之间存在一...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/volume-ratio
