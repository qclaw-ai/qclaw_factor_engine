# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_313  
因子名称: 综合质量因子  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 动量, 成长, 价值, 综合质量因子, 量化交易  
原始公式: \frac{Price}{Book Value} = \frac{Dividend/BookValue}{Required Return - Growth}

= \frac{(Profit/BookValue) * (Dividend/Profit)}{Required Return - Growth}

=\frac{Profitability \times PayoutRatio}{Required Return - Growth}

Price

Book Value

Dividend

Profit

Required Return

Growth

Profitability  
DSL公式: /PriceBook Value = /Dividend/BookValueRequired Return - Growth
= /(Profit/BookValue) * (Dividend/Profit)Required Return - Growth
=/Profitability * PayoutRatioRequired Return - Growth
Price
Book Value
Dividend
Profit
Required Return
Growth
Profitability  
描述: 价格/账面价值 ==(Profit/BookValue)∗(Dividend/Profit)RequiredReturn−Growth = \frac{(Profit/BookValue) * (Dividend/Profit)}{Required Return - Growth} =RequiredReturn−Growth(Profit/BookValue)∗(Dividend/Profit)...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/quality-factor
