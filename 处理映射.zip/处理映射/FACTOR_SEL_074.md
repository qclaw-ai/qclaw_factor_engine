# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_074  
因子名称: 对数市值规模  
分类: : 规模指标  
标签: : 流动性, 质量, 动量, 规模指标, 对数市值规模, 成长, 价值, 量化交易  
原始公式: \ln( 	ext{ClosePrice}_{t} \times 	ext{TotalShares}_{t} )

\text{ClosePrice}_{t}

\text{TotalShares}_{t}

\ln()  
DSL公式: LN( extClosePrice_t * extTotalShares_t )
\textClosePrice_t
\textTotalShares_t
LN()  
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors对数市值规模因子规模因子因子公式对数市值规模 = ln(当日收盘价 × 当日总股本)ln⁡(extClosePricet×extTotal...
因子类型: : 规模指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/scale/log-market-cap
