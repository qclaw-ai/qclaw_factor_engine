# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_100  
因子名称: 相对强弱指标 (RSI)  
分类: : 技术指标  
标签: : rsi, 流动性, 技术指标, 波动率, 质量, 动量, 成长, 价值  
原始公式: UM_t = \max(CLOSE_t - CLOSE_{t-1}, 0)

DM_t = \max(CLOSE_{t-1} - CLOSE_t, 0)

UA_t(N) = \frac{UA_{t-1}(N) * (N-1) + UM_t}{N}

DA_t(N) = \frac{DA_{t-1}(N) * (N-1) + DM_t}{N}

RSI_t = 100 * \frac{UA_t(N)}{UA_t(N) + DA_t(N)}

UA_0(N) = SMA(UM, N)

DA_0(N) = SMA(DM, N)

默认: N = 14

CLOSE_t

CLOSE_{t-1}

参数说明：CLOSEtCLOSE_tCLOSEt：​:t 时刻的收盘价CLOSEt−1CLOSE_{t-1}CLOSEt−1​:t-1 时刻的收盘价，即前一日收盘价UMtUM_tUMt​:t 时刻的上涨动能，定义为当日收盘价与前一日收盘价之差，若差值为正，则为差值，若差值为负，则为0，即只记录上涨的幅度DMtDM_tDMt​:t 时刻的下跌动能，定义为前一日收盘价与当日收盘价之差，若差值为正，则为差值，若差值为负，则为0，即只记录下跌的幅度UAt(N)UA_t(N)UAt​(N):t 时刻的N日上涨动能均值，采用平滑移动平均计算DAt(N)DA_t(N)DAt​(N):t 时刻的N日下跌动能均值，采用平滑移动平均计算SMA(X,N)SMA(X, N)SMA(X,N):X的N日简单移动平均，作为UA和DA的初始值计算方法NNN:计算周期，通常设置为14，表示计算最近14个交易日的动能因子解释相对强弱指标 (RSI) 的数值在 0 到 100 之间波动。通常情况下，RSI 值在 30 到 70 之间波动，但并非绝对。当 RSI 值高于 70 时，市场通常被认为是处于超买状态，价格可能面临回调的压力。此时，交易者需要警惕市场可能出现的下跌。相反，当 RSI 值低于 30 时，市场通常被认为是处于超卖状态，价格可能即将出现反弹。此时，交易者可以关注潜在的买入机会。需要注意的是，RSI 指标并非独立使用，需要与其他技术指标和市场分析相结合，才能更准确地判断市场走势。此外，RSI的超买超卖阈值可以根据具体情况进行调整，例如，一些交易者会使用 80 和 20 作为超买超卖的阈值。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。相对强弱指标 (RSI)Related Factors 相对强弱指标 (Relative Strength Index) 区域强度指数 成交量相对强度指标 相对波动性指标 随机动量指标 (SMI) 相对强弱人气指标 成交量相对强度指标 累计振荡指标 随机摆动指标 Factors DirectoryQuantitative Trading Factors相对强弱指标 (RSI)技术因子因子公式上涨动能 (UM):UMt=max⁡(CLOSEt−CLOSEt−1,0) UM_t = \max(CLOSE_t...  
DSL公式: UM_t = MAX(CLOSE_t - CLOSE_t-1, 0)
DM_t = MAX(CLOSE_t-1 - CLOSE_t, 0)
UA_t(N) = /UA_t-1(N) * (N-1) + UM_tN
DA_t(N) = /DA_t-1(N) * (N-1) + DM_tN
RSI_t = 100 * /UA_t(N)UA_t(N) + DA_t(N)
UA_0(N) = SMA(UM, N)
DA_0(N) = SMA(DM, N)
默认: N = 14
CLOSE_t
CLOSE_t-1  
描述: 相对强弱指标 (Relative Strength Index) 区域强度指数 成交量相对强度指标 相对波动性指标 随机动量指标 (SMI) 相对强弱人气指标 成交量相对强度指标 累计振荡指标 随机摆动指标 Related Factors 相对强弱指标 (Relative Strength Index) 区域强度指数 成交量相对强度指标 相对波动性指标 随机动量指标 (SMI) 相对强弱人气指标 ...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/relative-strength-index
