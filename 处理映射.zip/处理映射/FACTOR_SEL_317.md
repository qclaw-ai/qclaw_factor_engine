# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_317  
因子名称: 质量增长动量因子  
分类: : 成长性指标  
标签: : 流动性, 成长性指标, 质量增长动量因子, 质量, 动量, 成长, 价值, 量化交易  
原始公式: QualityGrowth_Momentum_{t} = \frac{Quality_{t} - Quality_{t-n}}{Quality_{t-n}}

QualityGrowth_Momentum_{t} = Quality_{t} - Quality_{t-n}

Quality_t

Quality_{t-n}

QualityGrowth_Momentum_{t}  
DSL公式: QualityGrowth_Momentum_t = /Quality_t - Quality_t-nQuality_t-n
QualityGrowth_Momentum_t = Quality_t - Quality_t-n
Quality_t
Quality_t-n
QualityGrowth_Momentum_t  
描述: 因子公式质量因子同比增速:QualityGrowthMomentumt=Qualityt−Qualityt−nQualityt−n QualityGrowth_Momentum_{t} = \frac{Quality_{t} - Quality_{t-n}}{Quality_{t-n}} QualityGrowthM​omentumt​=Qualityt−n​Qualityt​−Qualityt−...
因子类型: : 成长性指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/growth/quality-growth
