# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_304  
因子名称: 标准化季度营收意外  
分类: : 情绪指标  
标签: : 标准化季度营收意外, 流动性, 情绪指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{ActualRevenue_t - ExpectedRevenue_t}{std(ActualRevenue_{t-k} - ExpectedRevenue_{t-k}), k=0,1,...,7}

ActualRevenue_t

ExpectedRevenue_t

std(ActualRevenue_{t-k} - ExpectedRevenue_{t-k}), k=0,1,...,7

参数说明：ActualRevenuetActualRevenue_tActualRevenuet：​:当前第t季度的实际营业收入ExpectedRevenuetExpectedRevenue_tExpectedRevenuet​:当前第t季度的市场预期营业收入，通常为分析师预估中位数或平均数std(ActualRevenuet−k−ExpectedRevenuet−k),k=0,1,...,7std(ActualRevenue_{t-k} - ExpectedRevenue_{t-k}), k=0,1,...,7std(ActualRevenuet−k​−ExpectedRevenuet−k​),k=0,1,...,7:过去八个季度（包括当前季度）的营收意外标准差，用于标准化营收意外。营收意外计算为当前季度实际营收减去当前季度市场预期营收。因子解释该因子旨在捕捉公司季度营收超出市场预期的程度，并利用过去八个季度的营收意外波动进行标准化。正值表示公司营收表现超出预期，可能引发市场情绪的积极反应，从而推高股价；负值则表示公司营收表现不及预期，可能引发市场情绪的负面反应，从而压低股价。该因子利用了盈余公告后价格漂移效应，该效应表明在盈余公告发布后，股价会继续向公告信息所暗示的方向漂移一段时间。该因子考虑了营收意外的历史波动性，从而对不同公司或不同时间点的营收意外进行更公平的比较。一个较大的标准化营收意外，相比一个较小的标准化营收意外，可能预示着更强的股价反应。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Jegadeesh, Narasimhan, and Joshua Livnat. (2006). Revenue surprises and stock returns. Journal of Accounting and EconomicsRelated Factors 标准化盈利超预期因子 盈余公告超额收益率 分析师一致预期EPS修正比率 分析师预期EPS调整幅度 标准化意外盈余 预期市盈率调整幅度 盈余公告日次日开盘跳空幅度 分析师一致预期偏差度 60日盈利市值比率变动 因子解释该因子旨在捕捉公司季度营收超出市场预期的程度，并利用过去八个季度的营收意外波动进行标准化。正值表示公司营收表现超出预期，可能引发市场情绪的积极反应，从而推高股价；负值则表示公司营收表现不及预期，可能引发市场情绪的负面反应，从而压低股价。该因子利用了盈余公告后价格漂移效应，该效应表明在盈余公告发布后，股价会继续向公告信息所暗示的方向漂移一段时间。该因子考虑了营收意外的历史波动性，从而对不同公司或不同时间点的营收意外进行更公平的比较。一个较大的标准化营收意外，相比一个较小的标准化营收意外，可能预示着更强的股价反应。 ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子仅供教育和研究目的，不构成投资建议。•在做出任何投资决策之前，请咨询合格的财务顾问。 其中:ActualRevenue...  
DSL公式: /ActualRevenue_t - ExpectedRevenue_tstd(ActualRevenue_t-k - ExpectedRevenue_t-k), k=0,1,...,7
ActualRevenue_t
ExpectedRevenue_t
std(ActualRevenue_t-k - ExpectedRevenue_t-k), k=0,1,...,7  
描述: ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 标准化盈利超预期因子 盈余公告超额收益率 分析师一致预期EPS修正比率 分析师预期EPS调整幅度 标准化意外盈余 预期市盈率调整幅度 盈余公告日次日开盘跳空幅度 分析师一致预期偏差度 60日盈利市值比率变动 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/standardized-unexpected-revenue
