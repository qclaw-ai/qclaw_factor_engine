# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_222  
因子名称: 盈利率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 动量, 成长, 价值, 盈利率, 量化交易  
原始公式: \frac{Earning_{TTM}}{MarketCap}

Earning_{TTM}

MarketCap  
DSL公式: /Earning_TTMMarketCap
Earning_TTM
MarketCap  
描述: Factors DirectoryQuantitative Trading Factors盈利率 (Earnings Yield)基础面因子因子公式盈利率:EarningTTMMarketCap \frac{Earning_{TTM}}{MarketCap} MarketCapEarningTTM​​公式中，盈利率通过将公司最近12个月的归属母公司净利润（TTM）除以公司的总市值计算得出。Earn...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/earning-yield
