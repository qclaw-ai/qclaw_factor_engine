# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_263  
因子名称: 企业自由现金流/经营性净资产市值比率 (去杠杆)  
分类: : 基本面指标  
标签: : 企业自由现金流, 流动性, 经营性净资产市值比率, 基本面指标, 质量, 动量, 成长, 去杠杆  
原始公式: \text{FCF}_{TTM}

\text{EV}_{Operating}

\text{EV}_{Operating} = \text{Market Cap} + \text{Financial Liabilities} - \text{Financial Assets}

\text{FCF}_{TTM}

\text{EV}_{Operating}

参数说明：，FCF_{TTM} 代表最近12个月的企业自由现金流总额；EV_{Operating} 为经营性净资产市值，由市值加上金融负债并减去金融资产计算得出。FCFTTM\text{FCF}_{TTM}FCFTTM​:企业自由现金流（Trailing Twelve Months），指企业在过去12个月中，可以自由支配的现金流量总和，通常通过经营活动现金流量减去资本支出得出。EVOperating\text{EV}_{Operating}EVOperating​:经营性净资产市值，指企业扣除金融性资产和负债后，与经营活动相关的净资产的市场价值。它等于市值加上金融负债并减去金融资产。其中金融负债通常指有息负债，金融资产通常指交易性金融资产等。因子解释该因子使用企业自由现金流（FCF）而非简单的经营现金流，因为它更能反映企业真实的盈利能力。相比直接使用市值，使用经营性净资产市值（EV_Operating）更准确地衡量了企业核心资产价值，有效消除了金融活动对企业价值的扭曲影响。高现金流/经营性净资产市值比率可能意味着企业被市场低估，具有投资价值。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。刘富兵,李林井. (2019). 对价值因子的思考和改进. 国盛证券Related Factors 去杠杆化经营现金流/经营性净资产市值 去杠杆化账面价值/市值比 去杠杆经营性资产盈利收益率 净运营资产收益率 权益报酬环比动量-净资产同比增速差 经营性现金流市值比 去杠杆化企业价值/销售收入比 净经营资产变动率 (Net Operating Assets Change Rate) 单季度经营活动净现金流同比增速 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors去杠杆现金流市值比率基础面因子因子公式企业自由现金流（TTM）FCFTTM \text{FCF}_{TTM} FCFTTM​经营性净资产市值EVOperating \text{EV}_{Operating} EVOperating​经营性净资产市值 =  市值 + 金融负债 - 金融资产EVOperating=Market Cap+Financial Liabilities−Financial Assets \text{EV}_{Operating} = \text{Market Cap} + \text{Financial Liabilities} - \text{Financial Assets} EVOperating​=Market Cap+Financial Liabilities−Financial Assets该因子计算公式为： \frac{\text{FCF}_{TTM}}{\text{EV}_{Operating}}。其中，FCF_{TTM} 代表最近12个月的企业自由现金流总额；EV_{Operating} 为经营性净资产市值，由市值加上金融负债并减去金融资产计算得出。FCFTTM\text{FCF}_{TTM}FCFTTM​:企业自由现金流（Trailing Twelve Months），指企业在过去12个月中，可以自由支配的现金流量总和，通常通过经营活动现金流量减去资本支出得出。EVOperating\text{EV}_{Operating}EVOperating​:经营性净资产市值，指企业扣除金融性资产和负...  
DSL公式: \textFCF_TTM
\textEV_Operating
\textEV_Operating = \textMarket Cap + \textFinancial Liabilities - \textFinancial Assets
\textFCF_TTM
\textEV_Operating  
描述: 去杠杆现金流市值比率基础面因子因子公式企业自由现金流（TTM）FCFTTM \text{FCF}_{TTM} FCFTTM​经营性净资产市值EVOperating \text{EV}_{Operating} EVOperating​经营性净资产市值 =  市值 + 金融负债 - 金融资产EVOperating=Market Cap+Financial Liabilities−Financial A...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/basic-surface-cash-flow-to-market-value
