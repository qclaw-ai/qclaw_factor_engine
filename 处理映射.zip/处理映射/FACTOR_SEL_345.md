# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_345  
因子名称: 杠杆比率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 杠杆比率, 动量, 成长, 价值, 量化交易  
原始公式: \frac{\text{总负债}}{\text{总资产}}

\text{总负债}

\text{总资产}  
DSL公式: /\text总负债\text总资产
\text总负债
\text总资产  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Stephen H. Penman. (2007). 财务报表分析. 清华大学出版社Richard A. Brealey, Stewart C. Myers, Franklin Allen. (2019). 公司财务原理. 机械工业出版社 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/asset-liability-ratio
