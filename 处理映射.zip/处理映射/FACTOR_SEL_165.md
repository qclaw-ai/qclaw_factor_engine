# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_165  
因子名称: 标准化调整营业利润（TTM）  
分类: : 基本面指标  
标签: : 流动性, 标准化调整营业利润, 基本面指标, ttm, 质量, 动量, 成长, 价值  
原始公式: \frac{AdjustedOperatingProfit_{TTM,t} - mean(AdjustedOperatingProfit_{TTM,t-T:t-1})}{std(AdjustedOperatingProfit_{TTM,t-T:t-1})}

AdjustedOperatingProfit_{TTM} = OperatingProfit_{TTM} + AdvancesFromCustomers_{TTM}

AdjustedOperatingProfit_{TTM,t}

mean(AdjustedOperatingProfit_{TTM,t-T:t-1})

std(AdjustedOperatingProfit_{TTM,t-T:t-1})

OperatingProfit_{TTM}

AdvancesFromCustomers_{TTM}

参数说明：TTM：表示滚动12个月的累计值。mean(AdjustedOperatingProfitTTM,t−T:t−1)mean(AdjustedOperatingProfit_{TTM,t-T:t-1})mean(AdjustedOperatingProfitTTM,t−T:t−1​):过去T期调整后营业利润（TTM）的均值。计算时，使用t-T期到t-1期的AdjustedOperatingProfit_{TTM}数据。std(AdjustedOperatingProfitTTM,t−T:t−1)std(AdjustedOperatingProfit_{TTM,t-T:t-1})std(AdjustedOperatingProfitTTM,t−T:t−1​):过去T期调整后营业利润（TTM）的标准差。计算时，使用t-T期到t-1期的AdjustedOperatingProfit_{TTM}数据。TTT:回溯期数，表示计算均值和标准差时所使用的时间跨度，默认T=6，即回溯6个季度的数据。OperatingProfitTTMOperatingProfit_{TTM}OperatingProfitTTM​:滚动12个月的累计营业利润。AdvancesFromCustomersTTMAdvancesFromCustomers_{TTM}AdvancesFromCustomersTTM​:滚动12个月的累计预收账款，反映公司未来确认收入的潜力。 ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子仅供教育和研究目的，不构成投资建议。•在做出任何投资决策之前，请咨询合格的财务顾问。 公式中：AdjustedOperatingProfitTTM,tAdjustedOperatingProfit_{TTM,t}AdjustedOperatingProfitTTM,t​:t期调整后营业利润（TTM）值，其中TTM表示滚动12个月的累计值。mean(AdjustedOperatingProfitTTM,t−T:t−1)mean(AdjustedOperatingProfit_{TTM,t-T:t-1})mea...  
DSL公式: /AdjustedOperatingProfit_TTM,t - mean(AdjustedOperatingProfit_TTM,t-T:t-1)std(AdjustedOperatingProfit_TTM,t-T:t-1)
AdjustedOperatingProfit_TTM = OperatingProfit_TTM + AdvancesFromCustomers_TTM
AdjustedOperatingProfit_TTM,t
mean(AdjustedOperatingProfit_TTM,t-T:t-1)
std(AdjustedOperatingProfit_TTM,t-T:t-1)
OperatingProfit_TTM
AdvancesFromCustomers_TTM  
描述: ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 Related Factors 标准化营业利润(TTM) 单季度营业利润率同比变动率 单季度营业利润同比增速 经营利润率（TTM） 每股营业收入(TTM) 经营效率变动因子 (Operating Efficiency Change Factor) 单季度摊薄净资产收益率同比变动 运营成本利润...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/standardized-adjusted-operating-profit
