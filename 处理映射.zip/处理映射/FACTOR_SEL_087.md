# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_087  
因子名称: 每股盈余公积金  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 每股盈余公积金, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \text{每股盈余公积金} = \frac{\text{盈余公积金}}{\text{总股本}}

\text{盈余公积金}

\text{总股本}  
DSL公式: \text每股盈余公积金 = /\text盈余公积金\text总股本
\text盈余公积金
\text总股本  
描述: 指公司发行的全部股票数量，包括普通股和其他类型的股份。该数值取自与盈余公积金报告期相对应的总股本数量，是计算每股指标的关键分母。 Factors DirectoryQuantitative Trading Factors每股盈余公积金基础面因子因子公式每股盈余公积金:每股盈余公积金=盈余公积金总股本 \text{每股盈余公积金} = \frac{\text{盈余公积金}}{\text{总股本}} ...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/surplus-reserve-per-share
