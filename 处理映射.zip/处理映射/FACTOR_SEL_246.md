# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_246  
因子名称: 多时域移动平均动量因子  
分类: : 技术指标  
标签: : 流动性, 多时域移动平均动量因子, 技术指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: MA_{j,t,L} = \frac{\sum_{k=d-L+1}^{d} P_{j,k}^{t}}{L}

M\bar{A}_{j,t,L} = \frac{MA_{j,t,L}}{P_{j,d}^{t}}

r_{j,t} = \beta_{0,t} + \sum_{i} \beta_{i,t}M\bar{A}_{j,t-1,L_i} + \epsilon_{j,t}

E_t[\beta_{i,t+1}] = \frac{1}{12} \sum_{m=1}^{12} \beta_{i,t+1-m}

E[r_{j,t+1}] = \sum_{i} E_t[\beta_{i,t+1}]M\bar{A}_{j,t,L_i}

P_{j,k}^{t}

MA_{j,t,L}

M\bar{A}_{j,t,L}

r_{j,t}

\beta_{i,t}

参数说明：Pj：,ktP_{j,k}^{t}Pj,kt​:股票 j 在第 t 月的第 k 个交易日的收盘价。k的取值范围为[d-L+1,d], d 为当月最后一天交易日。LLL:移动平均的窗口宽度，即计算移动平均值所使用的时间跨度，例如5天、10天、20天等。不同的L值代表不同的时间尺度。MAj,t,LMA_{j,t,L}MAj,t,L​:股票 j 在第 t 月，以 L 为窗口宽度的移动平均价格。它反映了在特定时间窗口内，股票价格的平均水平。MAˉj,t,LM\bar{A}_{j,t,L}MAˉj,t,L​:标准化后的移动平均价格。通过将移动平均价格除以当月最后一个交易日的收盘价，消除了不同股票价格绝对值的差异，使不同股票的移动平均值具有可比性。rj,tr_{j,t}rj,t​:股票 j 在第 t 期的收益率。这里一般指的是月度收益率，计算公式为 $r_{j,t} = (P_{j,d}^{t} - P_{j,d-1}^{t})/ P_{j,d-1}^{t}$ 。βi,t\beta_{i,t}βi,t​:在第 t 期，由回归模型估计出的，第 i 个时间窗口 $L_i$ 的标准化移动平均价格 $M\bar{A}_{j,t-1,L_i}$ 的因子收益率（或因子载荷）。它代表了该时间窗口的动量信号对股票收益的贡献。ϵj,t\epsilon_{j,t}ϵj,t​:回归模型中的误差项，反映了模型未能解释的收益率部分。Et[βi,t+1]E_t[\beta_{i,t+1}]Et​[βi,t+1​]:基于过去12个月的因子收益率的平均值，得到的对下一个月因子收益率的预期值。使用过去一段时间的因子收益率均值作为未来因子收益率的估计，利用了因子收益率的均值回复特性。E[rj,t+1]E[r_{j,t+1}]E[rj,t+1​]:基于各时间窗口移动平均值及预期因子收益率，计算出的股票 j 在下一期（t+1）的预期收益率。它综合考虑了不同时间尺度下的动量信号对未来收益率的影响。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 股票 j 在第 t 期的收益率。这里一般指的是月度收益率，计算公式为 $r_{j,t} = (P_{j,d}^{t} - P_{j,d-1}^{t})/ P_{j,d-1}^{t}$ 。 因子公式移动平均价格:MAj,t,L=∑k=d−L+1dPj,ktL MA_{j,t,L} = \frac{\sum_{k=d-L+1}^{d} P_{j,k}^{t}}{L} MAj,t,L​=L∑k=d−L+1d​Pj,kt​​标准化移动平均价格：MAˉj,t,L=MAj,t,LPj,dt M\bar{A}_{j,t,L} = \frac{MA_{j,t,L}}{P_{j,d}^{t}} MAˉj,t,L​=Pj,dt​MAj,t,L​​回归模型：rj,t=β0,t+∑iβi,tMAˉj,t−1,Li+ϵj,t r_{j,t} = \beta_{0,t} + \sum_{i} \beta_{i,t}M\ba...  
DSL公式: MA_j,t,L = /SUM_k=d-L+1**d P_j,k**tL
M\barA_j,t,L = /MA_j,t,LP_j,d**t
r_j,t = beta_0,t + SUM_i beta_i,tM\barA_j,t-1,L_i + epsilon_j,t
E_t[beta_i,t+1] = /112 SUM_m=1**12 beta_i,t+1-m
E[r_j,t+1] = SUM_i E_t[beta_i,t+1]M\barA_j,t,L_i
P_j,k**t
MA_j,t,L
M\barA_j,t,L
r_j,t
beta_i,t  
描述: 预期因子收益率：Et[βi,t+1]=112∑m=112βi,t+1−m E_t[\beta_{i,t+1}] = \frac{1}{12} \sum_{m=1}^{12} \beta_{i,t+1-m} Et​[βi,t+1​]=121​m=1∑12​βi,t+1−m​ 多周期标准化移动平均动量因子 排序动量因子 时间序列动量 (TSMOM) 基本面趋势预期收益率 过去K个月累计收益率动量因子 ...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/trend-factor
