# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_140  
因子名称: 60日盈利市值比率变动  
分类: : 成长性指标  
标签: : 流动性, 成长性指标, 质量, 动量, 成长, 价值, 量化交易, 日盈利市值比率变动  
原始公式: EP_t - EP_{t-60}

EP_t

EP_{t-60}  
DSL公式: EP_t - EP_t-60
EP_t
EP_t-60  
描述: 60日盈利市值比率变动成长因子因子公式最新盈利市值比率 - 60个交易日前盈利市值比率EPt−EPt−60 EP_t - EP_{t-60} EPt​−EPt−60​该公式计算的是当前时间点（t）的盈利市值比率（EP_t）与60个交易日前盈利市值比率（EP_{t-60}）之差。该差值反映了在过去60个交易日内盈利市值比率的变化幅度。EPtEP_tEPt​:当前时间点（t）的盈利市值比率，通常计算方...
因子类型: : 成长性指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/growth/profit-market-cap-ratio-60d
