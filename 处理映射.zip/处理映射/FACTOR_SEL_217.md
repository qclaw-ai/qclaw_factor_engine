# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_217  
因子名称: 资本支出增长率-N年（CAGR-N）  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, cagr, 质量, 动量, 资本支出增长率, 成长, 价值  
原始公式: \frac{CapitalExpenditure_{TTM} - CapitalExpenditure_{TTM-N}}{CapitalExpenditure_{TTM-N}}

CapitalExpenditure_{TTM}

CapitalExpenditure_{TTM-N}

参数说明：CapitalExpenditureTTMCapitalExpenditure_：{TTM}CapitalExpenditureTTM​:最近12个月滚动计算的资本性支出 (Trailing Twelve Months Capital Expenditure)。资本性支出指公司为维持或扩大其生产能力、业务规模而进行的长期资产投资，具体计算方法为：购建固定资产、无形资产和其他长期资产支付的现金 - 处置固定资产、无形资产和其他长期资产收回的现金。CapitalExpenditureTTM−NCapitalExpenditure_{TTM-N}CapitalExpenditureTTM−N​:N年前同期（当前时间点的前N年）的12个月滚动资本性支出。例如，如果N=2，则为两年前同一时间点开始的12个月滚动资本性支出。NNN:时间跨度，以年为单位。常用取值包括2年 (N=2) 和 3年 (N=3)，分别对应24个月和36个月的比较基准。因子解释资本支出增长率反映了公司在固定资产、无形资产等长期资产方面的投资扩张力度。 一般而言，较高的资本支出增长率可能暗示公司正在积极扩张业务，为未来发展奠定基础，但也需要结合公司的行业特点、经营情况等进行综合分析。；实证研究表明，资本支出增长率与股票未来收益呈负相关关系，这可能反映了过度投资或者市场对未来增长的预期已在股价中得到体现。 此外，公司资本支出行为还会影响诸如市值、账面市值比等传统基本面因子与股票收益之间的关系，并且可能降低因子的风险暴露。；此因子的逻辑基于以下考虑：  
DSL公式: /CapitalExpenditure_TTM - CapitalExpenditure_TTM-NCapitalExpenditure_TTM-N
CapitalExpenditure_TTM
CapitalExpenditure_TTM-N  
描述: 最近12个月滚动计算的资本性支出 (Trailing Twelve Months Capital Expenditure)。资本性支出指公司为维持或扩大其生产能力、业务规模而进行的长期资产投资，具体计算方法为：购建固定资产、无形资产和其他长期资产支付的现金 - 处置固定资产、无形资产和其他长期资产收回的现金。 实证研究表明，资本支出增长率与股票未来收益呈负相关关系，这可能反映了过度投资或者市场对未...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/capital-expenditure-growth-rate
