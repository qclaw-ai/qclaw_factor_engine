# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_050  
因子名称: 稀释每股收益同比增长率 (TTM)  
分类: : 成长性指标  
标签: : 流动性, 成长性指标, ttm, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{EPS_{diluted, TTM} - EPS_{diluted, TTM, YoY}}{ | EPS_{diluted, TTM, YoY} | }

EPS_{diluted, TTM}

EPS_{diluted, TTM, YoY}

|...|

参数说明：EPSdiluted：,TTMEPS_{diluted, TTM}EPSdiluted,TTM​:表示最近12个月（Trailing Twelve Months，TTM）的稀释每股收益。EPSdiluted,TTM,YoYEPS_{diluted, TTM, YoY}EPSdiluted,TTM,YoY​:表示去年同期（同最近12个月时间跨度相同）的稀释每股收益。例如，如果当前财报周期为2023年Q3，则去年同期值应为2022年Q3财报所计算出的TTM稀释每股收益。∣...∣|...|∣...∣:表示绝对值，用于避免分母为负数导致计算结果失去实际意义。因子解释该因子采用同比增长率的形式，对比最近12个月（TTM）的稀释每股收益与去年同期水平，从而剔除季节性因素的影响，更准确地反映企业盈利的长期增长趋势。TTM数据的使用可以平滑单季度波动，使因子更稳定可靠。该指标对于评估企业的盈利扩张能力，特别是成长性企业的价值发现至关重要。高增长率通常意味着公司具有较强的盈利能力和发展潜力，但同时也应结合其他基本面指标进行综合考量，例如财务杠杆、盈利质量等，以避免高增长率背后隐藏的潜在风险。此外，对比增量和增长率，增长率更具跨公司可比性。此公式使用绝对值分母，是为了避免分母为0的情况导致计算错误或无意义的结果。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。David Hawkins. (2010). 财务报表分析与估值. McGraw-Hill EducationAswath Damodaran. (2012). 投资估值. John Wiley & SonsRelated Factors TTM基本每股收益同比增长率 单季度摊薄净资产收益率同比变动 摊薄扣非净资产收益率（TTM） 扣除非经常损益的摊薄每股收益(TTM) 市盈率相对盈利增长率 有形资本回报率环比增长率 (TTM) 每股净资产同比增速 摊薄每股收益 (Diluted EPS) 母公司股东权益环比增长率 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。David Hawkins. (2010). 财务报表分析与估值. McGraw-Hill EducationAswath Damodaran. (2012). 投资估值. John Wiley & Sons 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors稀释每股收益同比增长率 (TTM)成长因子因子公式计算公式:EPSdiluted,TTM−EPSdiluted,TTM,YoY∣EPSdiluted,TTM,YoY∣ \frac{EPS_{diluted, TTM} - EPS_{diluted, TTM, YoY}}{ | EPS_{diluted, TTM, YoY} | } ∣EPSdiluted,TTM,YoY​∣EPSdiluted,TTM​−EPSdiluted,TTM,YoY​​其中：...  
DSL公式: /EPS_diluted, TTM - EPS_diluted, TTM, YoY | EPS_diluted, TTM, YoY |
EPS_diluted, TTM
EPS_diluted, TTM, YoY
|...|  
描述: 因子解释该因子采用同比增长率的形式，对比最近12个月（TTM）的稀释每股收益与去年同期水平，从而剔除季节性因素的影响，更准确地反映企业盈利的长期增长趋势。TTM数据的使用可以平滑单季度波动，使因子更稳定可靠。该指标对于评估企业的盈利扩张能力，特别是成长性企业的价值发现至关重要。高增长率通常意味着公司具有较强的盈利能力和发展潜力，但同时也应结合其他基本面指标进行综合考量，例如财务杠杆、盈利质量等，以...
因子类型: : 成长性指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/growth/diluted-eps-yoy-growth-rate
