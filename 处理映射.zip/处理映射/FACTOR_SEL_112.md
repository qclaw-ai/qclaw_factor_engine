# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_112  
因子名称: 商品通道指数  
分类: : 技术指标  
标签: : 流动性, 技术指标, 技术分析, 质量, 动量, 成长, 商品通道指数, 量化交易  
原始公式: TP = \frac{HIGH + LOW + CLOSE}{3}

CCI(N) = \frac{TP - SMA(TP, N)}{0.015 \times MAD(TP, N)}

MAD(X, N) = \frac{1}{N}\sum_{i=1}^{N}|X_i - SMA(X,N)|

SMA(TP, N)

MAD(TP, N)

参数说明：TPTPTP：典型价格 (Typical Price), 代表一个交易日内的高、低、收盘价的均值，用于捕捉该交易日的中心价格水平。计算公式为：(最高价 + 最低价 + 收盘价) / 3。SMA(TP,N)SMA(TP, N)SMA(TP,N):N日简单移动平均线 (Simple Moving Average) 指的是对过去N个周期的典型价格(TP)进行算术平均。 它平滑了价格波动，提供了一个价格趋势的基准线。N值通常设置为20，可根据具体交易标的和时间周期进行调整。MAD(TP,N)MAD(TP, N)MAD(TP,N):N日平均绝对偏差 (Mean Absolute Deviation) 是衡量典型价格(TP)在N个周期内波动幅度的指标。它计算每个TP与其N日简单移动平均值(SMA(TP,N))之间差的绝对值的平均值。MAD值越大表示价格波动越大，反之亦然。NNN:计算周期参数，表示用于计算移动平均和平均绝对偏差的时间窗口大小。通常设置为20个交易日，但可以根据交易标的特性和交易策略进行调整。 较小的N值会导致CCI更敏感，而较大的N值会导致CCI更平滑。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors商品通道指数 (Commodity Channel Index)技术因子因子公式典型价格 (TP):TP=HIGH+LOW+CLOSE3 TP = \frac{HIGH + LOW + CLOSE}{3} TP=3HIGH+LOW+CLOSE​商品通道指数 (CCI(N)):CCI(N)=TP−SMA(TP,N)0.015×MAD(TP,N) CCI(N) = \frac{TP - SMA(TP, N)}{0.015 \times MAD(TP, N)} CCI(N)=0.015×MAD(TP,N)TP−SMA(TP,N)​平均绝对偏差 (MAD):MAD(X,N)=1N∑i=1N∣Xi−SMA(X,N)∣ MAD(X, N) = \frac{1}{N}\sum_{i=1}^{N}|X_i - SMA(X,N)| MAD(X,N)=N1​i=1∑N​∣Xi​−SMA(X,N)∣其中:TPTPTP:典型价格 (Typical Price), 代表一个交易日内的高、低、收盘价的均值，用于捕捉该交易日的中心价格水平。计算公式为：(最高价 + 最低价 + 收盘价) / 3。SMA(TP,N)SMA(TP, N)SMA(TP,N):N日简单移动平均线 (Simple Moving Average) 指的是对过去N个周期的典型价格(TP)进行算术平均。 它平滑了价格波动，提供了一个价格趋势的基准线。N值通常设置为20，可根据具体交易标的和时间周期进行调整。MAD(TP,N)MAD(TP, N)MAD(TP,N):N日平均绝对偏差 (Mean Absolute Deviation) 是衡量典型价格(TP)在N个周期内波动幅度的指标。它计算每个TP与其N日简单移动平均值(SMA(TP,N))之间差的绝对值的平均值。MAD值越大表示价格波动越大，反之亦然。NNN:计算周期参数，表示用于计算移动平均和平均绝对偏差的时间窗口大小。通常设置为20个交易日，但可以根据交易标...  
DSL公式: TP = /high + low + close3
CCI(N) = /TP - SMA(TP, N)0.015 * MAD(TP, N)
MAD(X, N) = /1NSUM_i=1**N|X_i - SMA(X,N)|
SMA(TP, N)
MAD(TP, N)  
描述: 随机动量指标 (SMI) 价格偏离移动均线百分比 (Price Deviation from Moving Average Percentage) 蔡金资金流量震荡指标 蔡金波动率指标 (Chaikin Volatility Index) 钱德动量振荡器 动态趋向指标 异同离差乖离率振荡器 多空意愿指标 (Bull-Bear Index, BBI) 累计振荡指标 因子公式典型价格 (TP):TP=...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/commodity-channel-index
