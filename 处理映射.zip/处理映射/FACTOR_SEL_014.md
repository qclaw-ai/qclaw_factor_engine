# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_014  
因子名称: 每股留存收益(Retained Earnings per Share, REPS)  
分类: : 质量指标  
标签: : retained, earnings, 流动性, 质量指标, 波动率, 质量, share, 动量  
原始公式: \frac{\text{最近报告期留存收益}}{\text{最近同期总股本}}

最近报告期留存收益

最近同期总股本  
DSL公式: /\text最近报告期留存收益\text最近同期总股本
最近报告期留存收益
最近同期总股本  
描述: 因子公式每股留存收益(REPS):最近报告期留存收益最近同期总股本 \frac{\text{最近报告期留存收益}}{\text{最近同期总股本}} 最近同期总股本最近报告期留存收益​该公式计算每股留存收益 (REPS)，其分子为最近报告期的留存收益，分母为最近同期总股本。最近报告期留存收益最近报告期留存收益最近报告期留存收益:指公司在最近一个报告期（如季度或年度）末累计的、未向股东分配的利润总额。...
因子类型: : 质量指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/quality/quality-retained-earnings-per-share
