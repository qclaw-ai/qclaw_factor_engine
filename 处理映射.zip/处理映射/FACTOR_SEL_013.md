# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_013  
因子名称: 每股净资产同比增速  
分类: : 成长性指标  
标签: : 流动性, 每股净资产同比增速, 成长性指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{NAVPS_{TTM,t} - NAVPS_{TTM,t-1}}{NAVPS_{TTM,t-1}}

NAVPS_{TTM,t}

NAVPS_{TTM,t-1}

分子 (NAVPS_{TTM,t} - NAVPS_{TTM,t-1})

分母 (NAVPS_{TTM,t-1})

参数说明：NAVPSTTM：,tNAVPS_{TTM,t}NAVPSTTM,t​:代表最近报告期（t期）的每股净资产(TTM)。TTM表示滚动12个月，即过去四个季度的累计值，避免了单季度数据可能存在的季节性波动。NAVPSTTM,t−1NAVPS_{TTM,t-1}NAVPSTTM,t−1​:代表上年同期（t-1期）的每股净资产(TTM)，即t期前一年的同一报告期。 使用上年同期值作为比较基准，能够消除季节性因素的影响，更准确地反映公司净资产规模的真实变化。分子(NAVPSTTM,t−NAVPSTTM,t−1)分子 (NAVPS_{TTM,t} - NAVPS_{TTM,t-1})分子(NAVPSTTM,t​−NAVPSTTM,t−1​):表示最近报告期每股净资产(TTM)与上年同期每股净资产(TTM)的差值，即每股净资产的增长额。分母(NAVPSTTM,t−1)分母 (NAVPS_{TTM,t-1})分母(NAVPSTTM,t−1​):表示上年同期每股净资产(TTM), 用于标准化增长额，得到增长率。因子解释每股净资产同比增速反映了公司每股净资产在过去一年内的相对增长幅度，是一个重要的成长性指标。该指标通过比较当前时点和上年同期时点的每股净资产，可以有效地衡量公司在报告期内的净资产增长能力。使用TTM数据可以平滑季节性影响，更准确地反映公司的长期成长趋势。高增速通常预示着公司拥有良好的盈利能力和价值创造能力，吸引投资者关注。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。丁鹏. (2021). 基本面量化投资. 清华大学出版社博迪，凯恩，马库斯. (2017). 证券投资分析. 机械工业出版社Related Factors 每股净资产 TTM基本每股收益同比增长率 季度总资产环比增长率 归母净利润同比增长率 稀释每股收益同比增长率 (TTM) 单季度摊薄净资产收益率同比变动 摊薄扣非净资产收益率（TTM） 单季度净利润率同比增速 母公司股东权益环比增长率 该公式计算每股净资产的同比增速，其中:NAVPSTTM,tNAVPS_{TTM,t}NAVPSTTM,t​:代表最近报告期（t期）的每股净资产(TTM)。TTM表示滚动12个月，即过去四个季度的累计值，避免了单季度数据可能存在的季节性波动。NAVPSTTM,t−1NAVPS_{TTM,t-1}NAVPSTTM,t−1​:代表上年同期（t-1期）的每股净资产(TTM)，即t期前一年的同一报告期。 使用上年同期值作为比较基准，能够消除季节性因素的影响，更准确地反映公司净资产规模的真实变化。分子(NAVPSTTM,t−NAVPSTTM,t−1)分子 (NAVPS_{TTM,t} - NAVPS_{TTM,t-1})分子(NAVPSTTM,t​−NAVPSTTM,t−1​):表示最近报告期每股净资产(TTM)与上年同期每股净资产(TTM)的差值，即每股净资产的增长额。分母(NAVPSTTM,t−1)分母 (NAVPS_{TTM,t-1})分母(NAVPSTTM,t−1​):表示上年同期每股净资产(TTM), 用于标准化增长额，得到增长率。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。丁鹏. (2021). 基本面量化投资. 清华大学出版社博迪，凯恩，马库斯. (2017). 证券投资分析. 机械工业出版社 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors每股净资产同比增速 (Year-on-Year Growt...  
DSL公式: /NAVPS_TTM,t - NAVPS_TTM,t-1NAVPS_TTM,t-1
NAVPS_TTM,t
NAVPS_TTM,t-1
分子 (NAVPS_TTM,t - NAVPS_TTM,t-1)
分母 (NAVPS_TTM,t-1)  
描述: Factors DirectoryQuantitative Trading Factors每股净资产同比增速 (Year-on-Year Growth Rate of Net Asset Value per Share)成长因子因子公式(最近报告期每股净资产(TTM) - 上年同期每股净资产(TTM)) / 上年同期每股净资产(TTM)NAVPSTTM,t−NAVPSTTM,t−1NAVPSTTM...
因子类型: : 成长性指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/growth/yoy-growth-rate-of-net-assets-per-share
