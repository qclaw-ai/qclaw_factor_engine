# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_179  
因子名称: 个股特质波动率  
分类: : 波动率指标  
标签: : 流动性, 个股特质波动率, 质量, 动量, 成长, 价值, 量化交易, 波动率指标  
原始公式: \sigma(\epsilon_{i,t})

r_{i,t} - r_{f,t} = \alpha_i + \beta_i(r_{m,t} - r_{f,t}) + \epsilon_{i,t}

r_{i,t} = \alpha_i + \beta_{1,i}MKT_t + \beta_{2,i}SMB_t + \beta_{3,i}HML_t + \epsilon_{i,t}

\sigma(\epsilon_{i,t})

r_{i,t}

r_{f,t}

r_{m,t}

\alpha_i

\beta_i

\epsilon_{i,t}  
DSL公式: sigma(epsilon_i,t)
r_i,t - r_f,t = alpha_i + beta_i(r_m,t - r_f,t) + epsilon_i,t
r_i,t = alpha_i + beta_1,iMKT_t + beta_2,iSMB_t + beta_3,iHML_t + epsilon_i,t
sigma(epsilon_i,t)
r_i,t
r_f,t
r_m,t
alpha_i
beta_i
epsilon_i,t  
描述: Fama-French三因子模型 (FF3) 回归:ri,t=αi+β1,iMKTt+β2,iSMBt+β3,iHMLt+ϵi,t r_{i,t} = \alpha_i + \beta_{1,i}MKT_t + \beta_{2,i}SMB_t + \beta_{3,i}HML_t + \epsilon_{i,t} ri,t​=αi​+β1,i​MKTt​+β2,i​SMBt​+β3,i​HMLt...
因子类型: : 波动率指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/volatility/idiosyncratic-volatility
