# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_121  
因子名称: 多空意愿指标 (Bull-Bear Index, BBI)  
分类: : 技术指标  
标签: : 流动性, 技术指标, index, 技术分析, 多空意愿指标, 质量, 动量, 成长  
原始公式: \frac{MA(CLOSE,M1)+MA(CLOSE,M2)+MA(CLOSE,M3)+MA(CLOSE,M4)}{4}

MA(CLOSE, N)

参数说明：MA：(CLOSE,N)MA(CLOSE, N)MA(CLOSE,N):N日简单移动平均线，表示过去N个交易日收盘价的算术平均值。M1M1M1:短期移动平均线周期，通常设置为 3 个交易日。M2M2M2:中短期移动平均线周期，通常设置为 6 个交易日。M3M3M3:中期移动平均线周期，通常设置为 12 个交易日。M4M4M4:中长期移动平均线周期，通常设置为 20 个交易日。因子解释多空意愿指标 (BBI) 通过对不同周期的简单移动平均线进行平均，旨在综合评估市场多空双方的力量。其设计思路在于，短期移动平均线对价格波动更加敏感，能够更快地反映市场情绪，而长期移动平均线则更加平滑，反映了市场的中长期趋势。BBI 通过将不同周期的移动平均线结合起来，可以有效地过滤掉短期噪音，同时捕捉到中长期趋势的变化。当BBI向上运行时，表明市场整体多方力量较强，反之则为空方力量较强。投资者可以结合价格走势和BBI的相对位置，来辅助判断市场趋势，发现潜在的买卖时机。此外，BBI 的参数（M1, M2, M3, M4）可以根据不同的市场和投资偏好进行调整，但通常保持短、中、长期周期的组合。请注意，任何技术指标都应与其他分析工具结合使用，不能单独作为投资决策的依据。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Martin J. Pring. (2002). 技术分析精论. McGraw-HillSteve Nison. (2001). 日本蜡烛图技术. John Wiley & SonsRelated Factors 价格偏离移动均线百分比 (Price Deviation from Moving Average Percentage) 动态趋向指标 商品通道指数 随机动量指标 (SMI) 布林买卖意愿比率 方向性动量离散指标 (Directional Momentum Dispersion Index) 异同离差乖离率振荡器 相对波动性指标 梅斯指数 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 因子公式BBI = (MA(CLOSE, M1) + MA(CLOSE, M2) + MA(CLOSE, M3) + MA(CLOSE, M4)) / 4MA(CLOSE,M1)+MA(CLOSE,M2)+MA(CLOSE,M3)+MA(CLOSE,M4)4 \frac{MA(CLOSE,M1)+MA(CLOSE,M2)+MA(CLOSE,M3)+MA(CLOSE,M4)}{4} 4MA(CLOSE,M1)+MA(CLOSE,M2)+MA(CLOSE,M3)+MA(CLOSE,M4)​其中:MA(CLOSE,N)MA(CLOSE, N)MA(CLOSE,N):N日简单移动平均线，表示过去N个交易日收盘价的算术平均值。M1M1M1:短期移动平均线周期，通常设置为 3 个交易日。M2M2M2:中短期移动平均线周期，通常设置为 6 个交易日。M3M3M3:中期移动平均线周期，通常设置为 12 个交易日。M4M4M4:中长期移动平均线周期，通常设置为 20 个交易日。 多空意愿指标 (Bull-Bear Index, BBI)技术因子因子公式BBI = (MA(CLOSE, M1) + MA(CLOSE, M2) + MA(CLOSE, M3) + MA(CLOSE, M4)) / 4MA(CLOSE,M1)+MA(CLOSE,M2)+MA(CLOSE,M3)+MA(CLOSE,M4)4 \frac{MA(CLOSE,M1)+MA(CLOSE,M2)+MA(CLOSE,M3...  
DSL公式: /MA(close,M1)+MA(close,M2)+MA(close,M3)+MA(close,M4)4
MA(close, N)  
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors多空意愿指标 (Bull-Bear Index, BBI)技术因子因子公式BBI = (MA(CLOSE, M1) + MA(CLOSE,...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/long-void-index
