# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_123  
因子名称: 三重指数移动平均 (TEMA)  
分类: : 技术指标  
标签: : 流动性, 技术指标, 技术分析, 质量, 动量, 成长, 价值, 量化交易  
原始公式: EMA_1(t) = EMA(REAL, N)

EMA_2(t) = EMA(EMA_1(t), N)

EMA_3(t) = EMA(EMA_2(t), N)

TEMA(t) = 3 \times EMA_1(t) - 3 \times EMA_2(t) + EMA_3(t)

REAL(t)

EMA_1(t)

EMA_2(t)

EMA_3(t)

EMA(x, N)

参数说明：$ \alpha = \frac{2}{N + 1} $  。初始值 $EMA(x,N)_0$ 通常取x的第一个值或者取前N个值的简单平均值。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors三重指数移动平均 (TEMA) 指标技术因子因子公式第一层指数移动平均 (EMA1) 计算公式：EMA1(t)=EMA(REAL,N) EMA_1(t) = EMA(REAL, N) EMA1​(t)=EMA(REAL,N)第二层指数移动平均 (EMA2) 计算公式：EMA2(t)=EMA(EMA1(t),N) EMA_2(t) = EMA(EMA_1(t), N) EMA2​(t)=EMA(EMA1​(t),N)第三层指数移动平均 (EMA3) 计算公式：EMA3(t)=EMA(EMA2(t),N) EMA_3(t) = EMA(EMA_2(t), N) EMA3​(t)=EMA(EMA2​(t),N)三重指数移动平均 (TEMA) 计算公式：TEMA(t)=3×EMA1(t)−3×EMA2(t)+EMA3(t) TEMA(t) = 3 \times EMA_1(t) - 3 \times EMA_2(t) + EMA_3(t) TEMA(t)=3×EMA1​(t)−3×EMA2​(t)+EMA3​(t)其中：NNN:时间周期参数，通常为正整数，表示计算移动平均所采用的时间窗口长度。例如，N=5 表示使用过去5个时间单位的数据进行计算。该参数决定了指标对价格变动的敏感程度，较小的N值对近期价格变化更敏感，但可能产生更多噪音；较大的N值平滑效果更好，但对价格变化的反应相对滞后。常用默认值为5，但可以根据交易策略和资产波动性进行调整。REAL(t)REAL(t)REAL(t):在t时刻的输入序列值，通常是资产的价格序列（如收盘价：CLOSE(t)），也可以是其他时间序列数据（如成交量：VOL(t)）。这里时间t可以理解为交易时间点、交易日或其它时间单位，取决于数据频率。EMA1(t)EMA_1(t)EMA1​(t):第一层指数移动平均，表示在t时刻，对输入序列$REAL(t)$进行指数平滑后的值。EMA2(t)EMA_2(t)EMA2​(t):第二层指数移动平均，表示在t时刻，对$EMA_1(t)$进行指数平滑后的值。EMA3(t)EMA_3(t)EMA3​(t):第三层指数移动平均，表示在t时刻，对$EMA_2(t)$进行指数平滑后的值。EMA(x,N)EMA(x, N)EMA(x,N):指数移动平均函数，表示对时间序列 x 使用时间周期 N 进行指数平滑处理，返回结果序列。 其计算公式为：$EMA(x,N)t = \alpha * x_t + (1 - \alpha) * EMA(x,N){t-1} $, 其中 $ \alpha = \frac{2}{N + 1} $  。初始值 $EMA(x,N)_0$ 通常取x的第一个值或者取前N个值的简单平均值。因子解释三重指数移动平均 (TEMA) 指标通过对原始数据进行三次指数平滑，并使用加权平均方法减少移动平均线的滞后性。相比单一和双重指数移动平均，TEMA 在捕捉短期趋势反转方面更为灵...  
DSL公式: EMA_1(t) = EMA(REAL, N)
EMA_2(t) = EMA(EMA_1(t), N)
EMA_3(t) = EMA(EMA_2(t), N)
TEMA(t) = 3 * EMA_1(t) - 3 * EMA_2(t) + EMA_3(t)
REAL(t)
EMA_1(t)
EMA_2(t)
EMA_3(t)
EMA(x, N)  
描述: 因子解释三重指数移动平均 (TEMA) 指标通过对原始数据进行三次指数平滑，并使用加权平均方法减少移动平均线的滞后性。相比单一和双重指数移动平均，TEMA 在捕捉短期趋势反转方面更为灵敏，能够更早地发出交易信号。然而，需要注意的是，由于其敏感性，TEMA 可能会产生较多的噪音，导致误判。因此，在实际应用中，建议与其他技术指标结合使用，以提高交易信号的可靠性。此外，TEMA 的参数 N 也需要根据具...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/triple-exponential-moving-average
