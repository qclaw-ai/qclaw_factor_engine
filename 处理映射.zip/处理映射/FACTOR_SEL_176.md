# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_176  
因子名称: 规模调整后净资产收益率残差  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 动量, 成长, 价值, 量化交易, 规模调整后净资产收益率残差  
原始公式: Residuals_{t} = ROE_{t} - \hat{ROE}_{t}

\hat{ROE}_{t} = \alpha + \beta * TotalAssets_{t}

ROE_{t}

TotalAssets_{t}

Residuals_{t}

\alpha

\beta

参数说明：，$\hat{ROE}_{t}$ 通过OLS回归得到:ROE^t=α+β∗TotalAssetst \hat{ROE}_{t} = \alpha + \beta * TotalAssets_{t} ROE^t​=α+β∗TotalAssetst​公式中：ROEtROE_{t}ROEt​:第t期的滚动净资产收益率（Return on Equity，TTM），计算方式为过去12个月的净利润总和除以股东权益。TotalAssetstTotalAssets_{t}TotalAssetst​:第t期的总资产。年度报告使用当期数据，其余季度报告则使用上一年度的年度报告数据。这样做是为了消除不同报告频率导致的资产规模波动对回归结果的干扰。ResidualstResiduals_{t}Residualst​:通过普通最小二乘法（OLS）回归得到的第t期的残差项，代表实际净资产收益率与基于总资产规模预测的净资产收益率之间的差异。该残差值可以被理解为在控制了资产规模效应后，企业实际表现出的超额净资产收益率。α\alphaα:OLS回归模型的截距项，代表当总资产为零时，预计的净资产收益率值。β\betaβ:OLS回归模型的斜率项，代表总资产每增加一个单位时，预计的净资产收益率的变化幅度。该值反映了资产规模对净资产收益率的敏感度。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。古翔,周萧潇,刘均伟. (2020). 规模调整的盈利因子:从盈余公积谈起. 光大证券 公式中：ROEtROE_{t}ROEt​:第t期的滚动净资产收益率（Return on Equity，TTM），计算方式为过去12个月的净利润总和除以股东权益。TotalAssetstTotalAssets_{t}TotalAssetst​:第t期的总资产。年度报告使用当期数据，其余季度报告则使用上一年度的年度报告数据。这样做是为了消除不同报告频率导致的资产规模波动对回归结果的干扰。ResidualstResiduals_{t}Residualst​:通过普通最小二乘法（OLS）回归得到的第t期的残差项，代表实际净资产收益率与基于总资产规模预测的净资产收益率之间的差异。该残差值可以被理解为在控制了资产规模效应后，企业实际表现出的超额净资产收益率。α\alphaα:OLS回归模型的截距项，代表当总资产为零时，预计的净资产收益率值。β\betaβ:OLS回归模型的斜率项，代表总资产每增加一个单位时，预计的净资产收益率的变化幅度。该值反映了资产规模对净资产收益率的敏感度。 规模调整后净资产收益率残差基础面因子因子公式规模调整后净资产收益率残差:Residualst=ROEt−ROE^t Residuals_{t} = ROE_{t} - \hat{ROE}_{t} Residualst​=ROEt​−ROE^t​其中，$\hat{ROE}_{t}$ 通过OLS回归得到:ROE^t=α+β∗TotalAssetst \hat{ROE}_{t} = \alpha + \beta * TotalAssets_{t} ROE^t​=α+β∗TotalAssetst​公式中：ROEtROE_{t}ROEt​:第t期的滚动净资产收益率（Return on Equity，TTM），计算方式为过去12个月的净利润总和除以股东权益。TotalAssetstTotalAssets_{t}TotalAssetst​:第t期的总资产。年度报告使用当期数据，其余季度报告则使用上一年度的年度报告数据。这样做是为了消除不同报告频率导致的资产规模波动对回归结果的干扰。ResidualstResiduals_{t}Residualst​:通过普通最小二乘法（OLS）回归得到的第t期的残差项，代表实际净资产收益率与基于总资产规模预测的净资产收益率之间的差异。该残差值可以被理解为在控制了资产规模效应后，企业实际表现出的超额净资产收益率。α\alphaα:OLS回归模型的截距项，代表当总资产为零时，预计的净资产收益率值。β\betaβ:OLS回归模型的斜率项，代表总资产每增加一个单位时，预计的净资产收益率的变化幅度。该值反映了资产规模对净资产收益率的敏感度。因子解释规模调整后的净资产收益率残差，通过剥离资产规模的影响，更准确地反映了企业真实的内生盈利能力和经营效率。正向的残差值表示企业在既定规模下，能够创造高于预期水平的盈利能力，反之则表示盈利能力低于预期。该因子可以有效识别具有超额盈利能力的企业，为量化投资提...  
DSL公式: Residuals_t = ROE_t - \hatROE_t
\hatROE_t = alpha + beta * TotalAssets_t
ROE_t
TotalAssets_t
Residuals_t
alpha
beta  
描述: 因子公式规模调整后净资产收益率残差:Residualst=ROEt−ROE^t Residuals_{t} = ROE_{t} - \hat{ROE}_{t} Residualst​=ROEt​−ROE^t​其中，$\hat{ROE}_{t}$ 通过OLS回归得到:ROE^t=α+β∗TotalAssetst \hat{ROE}_{t} = \alpha + \beta * TotalAssets...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/roe-adjustment
