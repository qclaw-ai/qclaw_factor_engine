# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_104  
因子名称: 开盘时段主动净买额占比  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 质量, 动量, 成长, 开盘时段主动净买额占比, 价值, 量化交易  
原始公式: \frac{1}{T} \sum_{n=t}^{t+T-1} \frac{\sum_{j=1}^{N} NetBuyAmount_{i,j,n}}{\sum_{j=1}^{N} TradeAmount_{i,j,n}}

NetBuyAmount_{i,j,n} = BuyAmount_{i,j,n} - SellAmount_{i,j,n}

BuyAmount

SellAmount

NetBuyAmount

TradeAmount

涨跌停分钟

i, j, n

时间范围

参数说明：BuyAmountBuyAmountBuyAmount：表示基于逐笔成交数据中交易方向（BS标志）识别出的主动买入成交金额。当买方主动以市价成交时，该笔成交记录被归为主动买入。计算时，通常会将逐笔成交数据聚合至分钟级别。SellAmountSellAmountSellAmount:表示基于逐笔成交数据中交易方向（BS标志）识别出的主动卖出成交金额。当卖方主动以市价成交时，该笔成交记录被归为主动卖出。计算时，通常会将逐笔成交数据聚合至分钟级别。NetBuyAmountNetBuyAmountNetBuyAmount:表示主动净买额，等于主动买入成交额减去主动卖出成交额。TradeAmountTradeAmountTradeAmount:表示总成交额，等于主动买入成交额和主动卖出成交额之和。涨跌停分钟涨跌停分钟涨跌停分钟:在计算过程中，已剔除处于涨跌停板的分钟数据，以避免涨跌停板对成交量和主动买卖行为的扭曲。i,j,ni, j, ni,j,n:分别代表：股票代码为i的股票，在第n个交易日内的第j分钟的成交额数据。时间范围时间范围时间范围:该因子计算的成交数据时间范围为开盘后特定时段，通常为9:30至10:00，即开盘后的前30分钟。TTT:表示回溯计算的时间窗口长度，即计算因子时所使用的历史交易日数量。 在月度选股策略下，通常取T=20（约为一个月的交易日），在周度选股策略下，通常取T=5（约为一周的交易日）。 因子公式1T∑n=tt+T−1∑j=1NNetBuyAmounti,j,n∑j=1NTradeAmounti,j,n \frac{1}{T} \sum_{n=t}^{t+T-1} \frac{\sum_{j=1}^{N} NetBuyAmount_{i,j,n}}{\sum_{j=1}^{N} TradeAmount_{i,j,n}} T1​n=t∑t+T−1​∑j=1N​TradeAmounti,j,n​∑j=1N​NetBuyAmounti,j,n​​主动净买额定义：NetBuyAmounti,j,n=BuyAmounti,j,n−SellAmounti,j,n NetBuyAmount_{i,j,n} = BuyAmount_{i,j,n} - SellAmount_{i,j,n} NetBuyAmounti,j,n​=BuyAmounti,j,n​−SellAmounti,j,n​其中：BuyAmountBuyAmountBuyAmount:表示基于逐笔成交数据中交易方向（BS标志）识别出的主动买入成交金额。当买方主动以市价成交时，该笔成交记录被归为主动买入。计算时，通常会将逐笔成交数据聚合至分钟级别。SellAmountSellAmountSellAmount:表示基于逐笔成交数据中交易方向（BS标志）识别出的主动卖出成交金额。当卖方主动以市价成交时，该笔成交记录被归为主动卖出。计算时，通常会将逐笔成交数据聚合至分钟级别。NetBuyAmountNetBuyAmountNetBuyAmount:表示主动净买额，等于主动买入成交额减去主动卖出成交额。TradeAmountTradeAmountTradeAmount:表示总成交额，等于主动买入成交额和主动卖出成交额之和。涨跌停分钟涨跌停分钟涨跌停分钟:在计算过程中，已剔除处于涨跌停板的分钟数据，以避免涨跌停板对成交量和主动买卖行为的扭曲。i,j,ni, j, ni,j,n:分别代表：股票代码为i的股票，在第n个交易日内的第j分钟的成交额数据。时间范围时间范围时间范围:该因子计算的成交数据时间范围为开盘后特定时段，通常为9:30至10:00，即开盘后的前30分钟。TTT:表示回溯计算的时间窗口长度，即计算因子时所使用的历史交易日数量。 在月度选股策略下，通常取T=20（约为一个月的交易日），在周度选股策略下，通常取T=5（约为一周的交易日）。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 Factors DirectoryQuantit...  
DSL公式: /1T SUM_n=t**t+T-1 /SUM_j=1**N NetBuyAmount_i,j,nSUM_j=1**N TradeAmount_i,j,n
NetBuyAmount_i,j,n = BuyAmount_i,j,n - SellAmount_i,j,n
BuyAmount
SellAmount
NetBuyAmount
TradeAmount
涨跌停分钟
i, j, n
时间范围  
描述: 表示基于逐笔成交数据中交易方向（BS标志）识别出的主动卖出成交金额。当卖方主动以市价成交时，该笔成交记录被归为主动卖出。计算时，通常会将逐笔成交数据聚合至分钟级别。 该因子通过计算一段时间内（如最近20个交易日）股票在开盘时段（如前30分钟）主动净买额占总成交额的平均比例，从而衡量投资者在开盘阶段的主动买入强度。较高的因子值意味着在开盘时段有较强的买盘力量，可能预示着股票短期内存在上涨动能。反之，...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/net-buy-ratio
