# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_028  
因子名称: 蔡金波动率指标 (Chaikin Volatility Index)  
分类: : 技术指标  
标签: : 流动性, 技术指标, volatility, index, 质量, chaikin, 动量, 蔡金波动率指标  
原始公式: CVI(N) = \frac{EMA(HIGH-LOW,N) - EMA(HIGH-LOW,N)_{lag(N)}}{EMA(HIGH-LOW,N)} * 100

HIGH

LOW

EMA(HIGH-LOW, N)

EMA(HIGH-LOW, N)_{lag(N)}

参数说明：NNN：观察周期，表示计算指数移动平均(EMA)的周期长度，默认值为20。N值越小，CVI对价格波动的变化越敏感；N值越大，CVI对价格波动的变化越平滑。HIGHHIGHHIGH:当前周期的最高价格。LOWLOWLOW:当前周期的最低价格。EMA(HIGH−LOW,N)EMA(HIGH-LOW, N)EMA(HIGH−LOW,N):以N为周期的(HIGH-LOW)的指数移动平均。EMA(HIGH−LOW,N)lag(N)EMA(HIGH-LOW, N)_{lag(N)}EMA(HIGH−LOW,N)lag(N)​:N周期前(HIGH-LOW)的指数移动平均值。即，当前EMA值向前偏移N个周期。 观察周期，表示计算指数移动平均(EMA)的周期长度，默认值为20。N值越小，CVI对价格波动的变化越敏感；N值越大，CVI对价格波动的变化越平滑。 参数说明:NNN:观察周期，表示计算指数移动平均(EMA)的周期长度，默认值为20。N值越小，CVI对价格波动的变化越敏感；N值越大，CVI对价格波动的变化越平滑。HIGHHIGHHIGH:当前周期的最高价格。LOWLOWLOW:当前周期的最低价格。EMA(HIGH−LOW,N)EMA(HIGH-LOW, N)EMA(HIGH−LOW,N):以N为周期的(HIGH-LOW)的指数移动平均。EMA(HIGH−LOW,N)lag(N)EMA(HIGH-LOW, N)_{lag(N)}EMA(HIGH−LOW,N)lag(N)​:N周期前(HIGH-LOW)的指数移动平均值。即，当前EMA值向前偏移N个周期。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors蔡金波动率指标技术因子因子公式CVI(N) =CVI(N)=EMA(HIGH−LOW,N)−EMA(HIGH−LOW,N)lag(N)EMA(HIGH−LOW,N)∗100 CVI(N) = \frac{EMA(HIGH-LOW,N) - EMA(HIGH-LOW,N)_{lag(N)}}{EMA(HIGH-LOW,N)} * 100 CVI(N)=EMA(HIGH−LOW,N)EMA(HIGH−LOW,N)−EMA(HIGH−LOW,N)lag(N)​​∗100参数说明:NNN:观察周期，表示计算指数移动平均(EMA)的周期长度，默认值为20。N值越小，...  
DSL公式: CVI(N) = /EMA(high-low,N) - EMA(high-low,N)_lag(N)EMA(high-low,N) * 100
high
low
EMA(high-low, N)
EMA(high-low, N)_lag(N)  
描述: CVI 指标的计算逻辑如下：

计算周期内价格差： 对于每个时间周期，计算最高价 (HIGH) 与最低价 (LOW) 的差值 (HIGH - LOW)，反映该周期的价格波动范围。
计算指数移动平均 (EMA)： 对价格差 (HIGH - LOW) 计算 N 周期的指数移动平均 (EMA(HIGH-LOW, N))。EMA 比简单移动平均更侧重于近期数据，因此能更快地反映波动性的变化。
计算波动率变...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/cvi
