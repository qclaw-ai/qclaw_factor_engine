# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_122  
因子名称: 梅斯指数  
分类: : 技术指标  
标签: : 流动性, 技术指标, 梅斯指数, 技术分析, 质量, 动量, 成长, 价值  
原始公式: MassIndex_t = \frac{EMA_9(HIGH_t - LOW_t)}{EMA_9(EMA_9(HIGH_t - LOW_t))}

HIGH_t

LOW_t

EMA_9(X)

参数说明：X：可以是(HIGH_t - LOW_t) 或者 EMA_9(HIGH_t - LOW_t)因子解释梅斯指数通过分析价格波动范围（当日最高价与最低价之差）的变化来识别潜在的趋势反转点。 具体而言，该指标首先计算当日最高价与最低价之差，然后对其进行两次指数移动平均平滑处理（首次平滑处理和二次平滑处理）; 再通过第一次平滑后的结果除以第二次平滑后的结果,得到最终的梅斯指数值。 当梅斯指数值出现显著上升或下降，并伴随着价格波幅的扩张或收缩时，通常被视为潜在趋势反转的信号。例如，当梅斯指数先下降后反弹，并且同时价格波动幅度开始收缩时，可能预示着先前趋势的结束和新趋势的开始。该指标主要应用于寻找超买或超卖区域后的价格反转，特别是在价格出现快速上涨或下跌之后, 可以辅助判断趋势的持续性或反转可能性。与单纯的价格波动幅度相比，梅斯指数通过指数移动平均降低了噪音，更加关注价格波动幅度的趋势变化，从而提供更清晰的趋势反转信号。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。John Murphy. (1999). 技术分析指标大全. Technical Analysis of the Financial MarketsRelated Factors 区域强度指数 移动平均汇聚背离指标 蔡金资金流量震荡指标 累计振荡指标 商品通道指数 三重指数移动平均 (TEMA) 多周期标准化移动平均动量因子 成交量异同移动平均线 (VMACD) 动态趋向指标 公式说明:HIGHtHIGH_tHIGHt​:第t个交易日的最高价LOWtLOW_tLOWt​:第t个交易日的最低价EMA9(X)EMA_9(X)EMA9​(X):以X为输入，计算周期为9的指数移动平均。其中X可以是(HIGH_t - LOW_t) 或者 EMA_9(HIGH_t - LOW_t) ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。John Murphy. (1999). 技术分析指标大全. Technical Analysis of the Financial Markets 梅斯指数 (Mass Index)技术因子因子公式梅斯指数计算公式：MassIndext=EMA9(HIGHt−LOWt)EMA9(EMA9(HIGHt−LOWt)) MassIndex_t = \frac{EMA_9(HIGH_t - LOW_t)}{EMA_9(EMA_9(HIGH_t - LOW_t))} MassIndext​=EMA9​(EMA9​(HIGHt​−LOWt​))EMA9​(HIGHt​−LOWt​)​公式说明:HIGHtHIGH_tHIGHt​:第t个交易日的最高价LOWtLOW_tLOWt​:第t个交易日的最低价EMA9(X)EMA_9(X)EMA9​(X):以X为输入，计算周期为9的指数移动平均。其中X可以是(HIGH_t - LOW_t) 或者 EMA_9(HIGH_t - LOW_t)...  
DSL公式: MassIndex_t = /EMA_9(HIGH_t - LOW_t)EMA_9(EMA_9(HIGH_t - LOW_t))
HIGH_t
LOW_t
EMA_9(X)  
描述: 梅斯指数计算公式：MassIndext=EMA9(HIGHt−LOWt)EMA9(EMA9(HIGHt−LOWt)) MassIndex_t = \frac{EMA_9(HIGH_t - LOW_t)}{EMA_9(EMA_9(HIGH_t - LOW_t))} MassIndext​=EMA9​(EMA9​(HIGHt​−LOWt​))EMA9​(HIGHt​−LOWt​)​ 技术因子情绪因子基...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/mass-index
