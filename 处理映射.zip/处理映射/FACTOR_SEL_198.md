# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_198  
因子名称: 日内换手率分布离散度  
分类: : 技术指标  
标签: : 日内换手率分布离散度, 流动性, 技术指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \sigma_{Turnover,Daily} = \sqrt{\frac{1}{N-1} \sum_{i=1}^{N} (Turnover_{i,minute} - \overline{Turnover_{minute}})^2}

Turnover_{minute} = \frac{Volume_{minute}}{SharesOutstanding_{daily}}

UTD = \frac{\sigma_{Daily}(\sigma_{Turnover,Daily})}{\overline{\sigma_{Turnover,Daily}}}

Turnover_{minute}

Volume_{minute}

SharesOutstanding_{daily}

\sigma_{Turnover,Daily}

\sigma_{Daily}(\sigma_{Turnover,Daily})

\overline{\sigma_{Turnover,Daily}}

参数说明：N：代表日内分钟级别交易数据的总个数，$Turnover_{i,minute}$代表第i分钟的换手率，$\overline{Turnover_{minute}}$代表日内分钟级别换手率的均值。该指标反映了日内换手率的波动程度。分钟换手率:Turnoverminute=VolumeminuteSharesOutstandingdaily Turnover_{minute} = \frac{Volume_{minute}}{SharesOutstanding_{daily}} Turnoverminute​=SharesOutstandingdaily​Volumeminute​​计算每分钟的换手率，其中$Volume_{minute}$代表每分钟的成交量，$SharesOutstanding_{daily}$代表当日的流通股本。该指标表示在特定一分钟内，有多少比例的股票发生了交易。日内换手率分布离散度 (UTD):UTD=σDaily(σTurnover,Daily)σTurnover,Daily‾ UTD = \frac{\sigma_{Daily}(\sigma_{Turnover,Daily})}{\overline{\sigma_{Turnover,Daily}}} UTD=σTurnover,Daily​​σDaily​(σTurnover,Daily​)​计算所有交易日每日换手率标准差的波动系数（变异系数），其中$\sigma_{Daily}(\sigma_{Turnover,Daily})$代表每日换手率标准差在所有交易日的标准差，$\overline{\sigma_{Turnover,Daily}}$代表每日换手率标准差在所有交易日的均值。该指标衡量了日内换手率波动程度在不同交易日之间的稳定性。其中:TurnoverminuteTurnover_{minute}Turnoverminute​:分钟换手率VolumeminuteVolume_{minute}Volumeminute​:每分钟成交量SharesOutstandingdailySharesOutstanding_{daily}SharesOutstandingdaily​:当日流通股本σTurnover,Daily\sigma_{Turnover,Daily}σTurnover,Daily​:日内换手率标准差σDaily(σTurnover,Daily)\sigma_{Daily}(\sigma_{Turnover,Daily})σDaily​(σTurnover,Daily​):每日换手率标准差在所有交易日的标准差σTurnover,Daily‾\overline{\sigma_{Turnover,Daily}}σTurnover,Daily​​:每日换手率标准差在所有交易日的均值 日内换手率分布离散度技术因子因子公式日内换手率标准差:σTurnover,Daily=1N−1∑i=1N(Turnoveri,minute−Turnoverminute‾)2 \sigma_{Turnover,Daily} = \sqrt{\frac{1}{N-1} \sum_{i=1}^{N} (Turnover_{i,minute} - \overline{Turnover_{minute}})^2} σTurnover,Daily​=N−11​i=1∑N​(Turnoveri,minute​−Turnoverminute​​)2​计算每日股票分钟级别换手率的标准差，其中N代表日内分钟级别交易数据的总个数，$Turnover_{i,minute}$代表第i分钟的换手率，$\overline{Turnover_{minute}}$代表日内分钟级别换手率的均值。该指标反映了日内换手率的波动程度。分钟换手率:Turnoverminute=VolumeminuteSharesOutstandingdaily Turnover_{minute} = \frac{Volume_{minute}}{SharesOutstanding_{da...  
DSL公式: sigma_Turnover,Daily = SQRT/1N-1 SUM_i=1**N (Turnover_i,minute - \overlineTurnover_minute)**2
Turnover_minute = /Volume_minuteSharesOutstanding_daily
UTD = /sigma_Daily(sigma_Turnover,Daily)\overlinesigma_Turnover,Daily
Turnover_minute
Volume_minute
SharesOutstanding_daily
sigma_Turnover,Daily
sigma_Daily(sigma_Turnover,Daily)
\overlinesigma_Turnover,Daily  
描述: 因子公式日内换手率标准差:σTurnover,Daily=1N−1∑i=1N(Turnoveri,minute−Turnoverminute‾)2 \sigma_{Turnover,Daily} = \sqrt{\frac{1}{N-1} \sum_{i=1}^{N} (Turnover_{i,minute} - \overline{Turnover_{minute}})^2} σTurnover...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/turnover-uniformity
