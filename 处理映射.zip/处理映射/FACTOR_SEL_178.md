# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_178  
因子名称: 估值偏离度(误差修正模型)  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 估值偏离度, 动量, 成长, 价值, 误差修正模型  
原始公式: VR_t^i = Trend_t^i + Deviation_t^i

Trend_t^i \triangleq C^i \times SVR_t^i

\Delta VR_t^i = \alpha^i \times \Delta SVR_t^i + \lambda^i \times ECM_{t-1}^i + \epsilon_t^i

ECM_{t-1}^i = (VR_{t-1}^i - C^i \times SVR_{t-1}^i)

DR_t^i \triangleq (VR_t^i - C^i \times SVR_t^i)/VR_t^i

VR_t^i

SVR_t^i

C^i

\Delta VR_t^i

\Delta SVR_t^i

参数说明：，误差修正项$ECM_{t-1}^i$定义为：ECMt−1i=(VRt−1i−Ci×SVRt−1i) ECM_{t-1}^i = (VR_{t-1}^i - C^i \times SVR_{t-1}^i) ECMt−1i​=(VRt−1i​−Ci×SVRt−1i​)最终，估值偏离度因子 $DR_t^i$ 定义为当前估值与长期趋势的差值，并标准化为相对于当前估值的比例：DRti≜(VRti−Ci×SVRti)/VRti DR_t^i \triangleq (VR_t^i - C^i \times SVR_t^i)/VR_t^i DRti​≜(VRti​−Ci×SVRti​)/VRti​公式中各参数的含义如下：VRtiVR_t^iVRti​:股票i在t时刻的估值水平，例如市净率（PB）的倒数、市销率（PS）的倒数等，代表了股票的相对价值。SVRtiSVR_t^iSVRti​:股票i所属行业在t时刻的估值中位数，代表行业整体的估值水平，用于衡量行业趋势。CiC^iCi:股票i的特异性因素系数，体现了个股相对于行业的估值水平的差异，通常为常数。ΔVRti\Delta VR_t^iΔVRti​:股票i在t时刻估值水平相对于t-1时刻的变化量, 即 $VR_t^i - VR_{t-1}^i$ΔSVRti\Delta SVR_t^iΔSVRti​:股票i所属行业在t时刻估值中位数相对于t-1时刻的变化量, 即 $SVR_t^i - SVR_{t-1}^i$αi\alpha^iαi:股票i的行业估值变化对个股估值变化的影响程度，表示行业估值变化对个股估值的短期弹性。λi\lambda^iλi:误差修正项的系数，表示估值偏离长期趋势的回复速度，通常取值范围为[-1, 0]。$\lambda^i$ 越接近 -1 表示回复速度越快，越接近0 表示回复速度越慢。ECMt−1iECM_{t-1}^iECMt−1i​:误差修正项，表示t-1时刻个股估值与长期趋势的偏离程度。ϵti\epsilon_t^iϵti​:残差项，表示模型无法解释的随机扰动。因子解释该因子旨在衡量个股估值相对于其长期均衡水平的短期偏离程度。通过构建误差修正模型（ECM），将估值水平分解为长期趋势项和短期偏离项，并利用当前估值与长期趋势的差值除以当前估值进行标准化，得到估值偏离度因子。因子绝对值越高，表示当前估值偏离长期趋势越明显，潜在的估值回归空间越大，可能蕴含更高的投资机会。因子为正，表明个股估值被低估；因子为负，表明个股估值被高估。该因子可用于识别估值被错杀或高估的股票，并进行均值回归策略。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。徐寅. (2020). 基于误差修正模型的估值趋势偏离度因子研究. 兴业证券Related Factors 残差市值偏离度 相对组合对数价差偏离度 市值非线性偏离因子 盈余波动率因子 (Earnings Volatility Factor) 60日盈利市值比率变动 特异性收益波动因子 市场反应滞后因子 基本面趋势预期收益率 双向价格差分自相关性标准化因子 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成...  
DSL公式: VR_t**i = Trend_t**i + Deviation_t**i
Trend_t**i \triangleq C**i * SVR_t**i
\Delta VR_t**i = alpha**i * \Delta SVR_t**i + \lambda**i * ECM_t-1**i + epsilon_t**i
ECM_t-1**i = (VR_t-1**i - C**i * SVR_t-1**i)
DR_t**i \triangleq (VR_t**i - C**i * SVR_t**i)/VR_t**i
VR_t**i
SVR_t**i
C**i
\Delta VR_t**i
\Delta SVR_t**i  
描述: Factors DirectoryQuantitative Trading Factors基于误差修正模型的估值偏离度技术因子因子公式假设个股的估值水平$VR_t^i$由长期趋势项$Trend_t^i$和短期偏离项$Deviation_t^i$共同决定:VRti=Trendti+Deviationti VR_t^i = Trend_t^i + Deviation_t^i VRti​=Trendti...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/valuation-deviation
