# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_075  
因子名称: 流通市值对数因子  
分类: : 价值指标  
标签: : 流动性, 质量, 动量, 成长, 流通市值对数因子, 价值, 量化交易, 价值指标  
原始公式: \text{流通市值} = \text{当日收盘价} \times \text{当日流通股本} \newline \text{流通市值因子} = \log(\text{流通市值})

当日收盘价

当日流通股本

流通市值

log()  
DSL公式: \text流通市值 = \text当日收盘价 * \text当日流通股本 \newline \text流通市值因子 = LOG(\text流通市值)
当日收盘价
当日流通股本
流通市值
log()  
描述: Related Factors 对数市值规模 对数自由流通市值 市值中性化换手率残差 市值非线性偏离因子 年度股权发行调整市值增长率 相对组合对数价差偏离度 市场反应滞后因子 自由流通市值 年度总负债对数增长率 指当日股票在交易结束时的最后成交价格，单位为货币单位（如元，美元等）。该数据反映了市场对公司价值的最终评估。 Factors DirectoryQuantitative Trading F...
因子类型: : 价值指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/value/market-cap
