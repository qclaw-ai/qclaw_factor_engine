# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_065  
因子名称: 成交额波动率  
分类: : 波动率指标  
标签: : 流动性, 质量, 成交额波动率, 动量, 成长, 价值, 量化交易, 波动率指标  
原始公式: \sigma(\text{Daily Trading Volume}_{t-K:t})  
DSL公式: sigma(\textDaily Trading Volume_t-K:t)  
描述: Factors DirectoryQuantitative Trading Factors成交额波动率波动率因子因子公式过去K个月日度成交额标准差σ(Daily Trading Volumet−K:t) \sigma(\text{Daily Trading Volume}_{t-K:t}) σ(Daily Trading Volumet−K:t​)公式计算逻辑:1.首先，获取目标股票在过去K个月的...
因子类型: : 波动率指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/volatility/trading-volume-fluctuation
