# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_020  
因子名称: 实体K线一致性买入强度因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 实体, 质量, 动量, 成长, 线一致性买入强度因子, 价值  
原始公式: |close - open| \leq a \cdot |high - low|

CBVR_t = \frac{1}{d} \sum_{i=1}^{d} (\frac{ConsistentVolume_{rise,t-i}}{Volume_{t-i}})

ConsistentVolume_{rise,t-i}

Volume_{t-i}

参数说明：aaa：实体K线阈值参数，取值范围通常为[0,1]。$a$ 值越小，实体K线定义越严格，即开盘价和收盘价的差距需要更小，K线实体部分更长，上下影线更短。该参数反映了对实体K线一致性程度的敏感性。ConsistentVolumerise,t−iConsistentVolume_{rise,t-i}ConsistentVolumerise,t−i​:在第t-i个交易日，所有满足实体K线定义的且收盘价高于开盘价的5分钟K线的总成交量之和，代表了该交易日内实体K线的买入成交量。此指标的目的是捕捉在短期内，具有明显买入意愿的实体K线成交量。Volumet−iVolume_{t-i}Volumet−i​:在第t-i个交易日，所有的5分钟K线的总成交量，代表了该交易日总的成交活跃度。ddd:移动平均窗口期，表示计算均值的历史交易日数量。通过调整 $d$ 可以控制因子对短期和长期趋势的敏感度。$d$ 越大，因子对短期交易波动越不敏感，更关注长期趋势；$d$ 越小，因子对短期交易波动越敏感，更关注短期市场行为。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 因子公式定义实体K线:∣close−open∣≤a⋅∣high−low∣ |close - open| \leq a \cdot |high - low| ∣close−open∣≤a⋅∣high−low∣实体K线一致性买入强度因子(Consistent Buy Volume Ratio, CBVR):CBVRt=1d∑i=1d(ConsistentVolumerise,t−iVolumet−i) CBVR_t = \frac{1}{d} \sum_{i=1}^{d} (\frac{ConsistentVolume_{rise,t-i}}{Volume_{t-i}}) CBVRt​=d1​i=1∑d​(Volumet−i​ConsistentVolumerise,t−i​​)其中：aaa:实体K线阈值参数，取值范围通常为[0,1]。$a$ 值越小，实体K线定义越严格，即开盘价和收盘价的差距需要更小，K线实体部分更长，上下影线更短。该参数反映了对实体K线一致性程度的敏感性。ConsistentVolumerise,t−iConsistentVolume_{rise,t-i}ConsistentVolumerise,t−i​:在第t-i个交易日，所有满足实体K线定义的且收盘价高于开盘价的5分钟K线的总成交量之和，代表了该交易日内实体K线的买入成交量。此指标的目的是捕捉在短期内，具有明显买入意愿的实体K线成交量。Volumet−iVolume_{t-i}Volumet−i​:在第t-i个交易日，所有的5分钟K线的总成交量，代表了该交易日总的成交活跃度。ddd:移动平均窗口期，表示计算均值的历史交易日数量。通过调整 $d$ 可以控制因子对短期和长期趋势的敏感度。$d$ 越大，因子对短期交易波动越不敏感，更关注长期趋势；$d$ 越小，因子对短期交易波动越敏感，更关注短期市场行为。 实体K线一致性买入强度因子（CBVR）旨在量化市场中集体买入行为的强度。当股票的CBVR值在一段时间内较高时，表示该股票的实体K线买入成交量占比相对较大，这意味着市场参与者在这些时间段内买入意愿较强，且价格变动较为一致，这可能预示着潜在的市场趋势或价格突破机会。这种一致性行为往往与市场情绪、信息披露或基本面因素的变化有关。该因子能够帮助交易者识别那些可能存在显著趋势性或突破性机会的股票，辅助量化交易策略的制定。与单纯的价格波动相比，该因子更能有效地捕捉市场情绪的变动和集体行为的共性。需要注意的是，该因子并非绝对的买入信号，需要结合其他因子和市场情况进行综合分析判断。 ⚠️ 重要投资风险披露金融...  
DSL公式: |close - open| <= a * |high - low|
CBVR_t = /1d SUM_i=1**d (/ConsistentVolume_rise,t-iVolume_t-i)
ConsistentVolume_rise,t-i
Volume_t-i  
描述: 一致性下跌成交量比率因子 实体K线一致性交易强度因子 成交量相对强度指标 开盘后主动买入强度标准化均值 开盘时段大单净额占比 开盘时段主动净买额占比 大单成交量价动量 成交量价背离度 成交额波动率 因子解释实体K线一致性买入强度因子（CBVR）旨在量化市场中集体买入行为的强度。当股票的CBVR值在一段时间内较高时，表示该股票的实体K线买入成交量占比相对较大，这意味着市场参与者在这些时间段内买入意愿...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/consistent-buy-transaction
