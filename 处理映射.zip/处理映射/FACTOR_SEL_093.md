# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_093  
因子名称: 年度股权发行调整市值增长率  
分类: : 情绪指标  
标签: : 年度股权发行调整市值增长率, 流动性, 情绪指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \ln\left(\frac{CurrentMarketCap}{LaggedMarketCap}\right) - \ln(1 + CumulativeReturn)

CurrentMarketCap

LaggedMarketCap

CumulativeReturn  
DSL公式: LN(/CurrentMarketCapLaggedMarketCap) - LN(1 + CumulativeReturn)
CurrentMarketCap
LaggedMarketCap
CumulativeReturn  
描述: 当前最新总市值。指在计算该因子时，公司在当前时间点的总市值。总市值等于公司发行的所有股票的市场价格乘以其发行量。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 Related Factors Annual_Share_Issuance_Growth_Rate 发行股本增长率 年度总负债对数增长率 流通市值对数因子 权益报酬环比动量-净资...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/comprehensive-equity-offering-annual
