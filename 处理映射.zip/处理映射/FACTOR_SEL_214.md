# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_214  
因子名称: 资产市值比  
分类: : 基本面指标  
标签: : 资产市值比, 流动性, 基本面指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \text{资产市值比} = \frac{\text{总资产}}{\text{总市值}}

\text{总资产}

\text{总市值}  
DSL公式: \text资产市值比 = /\text总资产\text总市值
\text总资产
\text总市值  
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors资产市值比 (Total Assets to Market Capitalization Ratio)基础面因子因子公式资产市值比:资产市...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/market-capitalization-ratio-of-total-assets
