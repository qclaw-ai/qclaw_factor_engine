# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_231  
因子名称: Top3FreeFloatShareRatio  
分类: : 基本面指标  
标签: : 流动性, top, 基本面指标, freefloatshareratio, 质量, 动量, 成长, 价值  
原始公式: S_{top3_freefloat}

S_{freefloat}

S_{top3_freefloat}

S_{freefloat}  
DSL公式: S_top3_freefloat
S_freefloat
S_top3_freefloat
S_freefloat  
描述: 因子解释该指标计算前三大自由流通股东持股数占自由流通股总股本的比例，反映了公司股权在可交易股票中的集中程度。该指标可用于评估：nn1. 股权结构稳定性: 较高的持股集中度通常意味着较稳定的股权结构，但可能存在大股东控制风险。nn2. 控制权风险:  如果少数股东持有大部分自由流通股，可能导致他们对公司决策有较大的影响力，引发控制权风险。nn3. 市场流动性:  股权过于集中可能导致市场流动性下降，...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/equity-concentration
