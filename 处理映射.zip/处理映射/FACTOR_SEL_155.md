# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_155  
因子名称: 单季度毛利率同比变化率  
分类: : 基本面指标  
标签: : 单季度毛利率同比变化率, 流动性, 基本面指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{GPM_{q} - GPM_{q-4}}{|GPM_{q-4}|}

GPM_q

GPM_{q-4}

|GPM_{q-4}|  
DSL公式: /GPM_q - GPM_q-4|GPM_q-4|
GPM_q
GPM_q-4
|GPM_q-4|  
描述: Factors DirectoryQuantitative Trading Factors单季度毛利率同比变化率基础面因子因子公式单季度毛利率同比变化率:GPMq−GPMq−4∣GPMq−4∣ \frac{GPM_{q} - GPM_{q-4}}{|GPM_{q-4}|} ∣GPMq−4​∣GPMq​−GPMq−4​​该公式计算单季度毛利率的同比变化率，公式中：GPMqGPM_qGPMq​:表示最...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/single-quarter-gross-profit-margin-yoy
