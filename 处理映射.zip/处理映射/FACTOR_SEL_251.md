# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_251  
因子名称: 成交量加权残差反转因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 动量, 成长, 成交量加权残差反转因子, 价值, 量化交易  
原始公式: S_t = \frac{\sum_{\tau=1}^{t} (V_{buy,\tau} - V_{sell,\tau})}{\sum_{\tau=1}^{t} |V_{buy,\tau} + V_{sell,\tau}|}

Ret_{t,20} = \alpha + \beta * S_t + \epsilon_t

V_{buy,\tau}

V_{sell,\tau}

S_t

Ret_{t,20}

\alpha

\beta

\epsilon_t

参数说明：Vbuy：,τV_{buy,\tau}Vbuy,τ​:在 (\tau) 时刻成交的小单买入成交额，代表主动买入的力量。Vsell,τV_{sell,\tau}Vsell,τ​:在 (\tau) 时刻成交的小单卖出成交额，代表主动卖出的力量。StS_tSt​:在 (t) 时刻累计的成交量加权资金流强度。该指标衡量了从初始时刻到 (t) 时刻的净主动买入或卖出力量的累积情况，并进行了成交量标准化。Rett,20Ret_{t,20}Rett,20​:在 (t) 时刻，过去20个交易日的股票收益率，反映了传统的反转因子概念。α\alphaα:回归模型的截距项，表示当资金流强度为零时，预期反转收益的大小。β\betaβ:回归模型的斜率，衡量资金流强度变化对反转收益的影响程度。ϵt\epsilon_tϵt​:回归模型的残差项，表示在控制了资金流强度影响后，剩余的、无法被资金流强度解释的反转收益。该项即为最终的残差反转因子值。因子解释成交量加权残差反转因子通过对传统反转收益进行成交量加权资金流强度的回归，有效地剔除了成交量因素对反转效应的干扰，使得该因子能够更精准地反映由非成交量因素（如市场情绪、消息面等）驱动的反转机会。残差部分蕴含了更纯粹的反转信号，可能具有更强的选股能力。特别地，通过使用成交量加权而非简单的买卖额差值，可以更好地标准化成交量对资金流的影响，使得因子在不同成交量水平的股票中具有更好的适应性。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。魏建榕,高鹏. (2021). 大单与小单资金流的alpha 能力. 开源证券Related Factors 残差资金流强度 Fama-French三因子模型残差动量 成交额分位数反转强度因子 残差市值偏离度 月度加权特质波动率 残差偏度因子 特异性收益波动因子 CAPM残差动量因子 负收益成交额加权非流动性因子 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 Related Factors 残差资金流强度 Fama-French三因子模型残差动量 成交额分位数反转强度因子 残差市值偏离度 月度加权特质波动率 残差偏度因子 特异性收益波动因子 CAPM残差动量因子 负收益成交额加权非流动性因子 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors成交量加权残差反转因子技术因子因子公式成交量加权资金流强度:St=∑τ=1t(Vbuy,τ−Vsell,τ)∑τ=1t∣Vbuy,τ+Vsell,τ∣ S_t = \frac{\sum_{\tau=1}^{t} (V_{buy,\tau} - V_{sell,\tau})}{\sum_{\tau=1}^{t} |V_{buy,\tau} + V_{sell,\tau}|} St​=∑τ=1t​∣Vbuy,τ​+Vsell,τ​∣∑τ=1t​(Vbuy,τ​−Vsell,τ​)​残差反转因子:Rett,20=α+β∗St+ϵt Ret_{t,20} = \alpha + \beta * S_t + \epsilon_t Rett,20​=α+β∗St​+ϵt​其中...  
DSL公式: S_t = /SUM_tau=1**t (V_buy,tau - V_sell,tau)SUM_tau=1**t |V_buy,tau + V_sell,tau|
Ret_t,20 = alpha + beta * S_t + epsilon_t
V_buy,tau
V_sell,tau
S_t
Ret_t,20
alpha
beta
epsilon_t  
描述: 在 (t) 时刻累计的成交量加权资金流强度。该指标衡量了从初始时刻到 (t) 时刻的净主动买入或卖出力量的累积情况，并进行了成交量标准化。 回归模型的残差项，表示在控制了资金流强度影响后，剩余的、无法被资金流强度解释的反转收益。该项即为最终的残差反转因子值。 Factors DirectoryQuantitative Trading Factors成交量加权残差反转因子技术因子因子公式成交量加权资...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/residual-reversal-factor
