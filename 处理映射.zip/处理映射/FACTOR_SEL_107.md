# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_107  
因子名称: 开盘时段大单净额占比  
分类: : 情绪指标  
标签: : 开盘时段大单净额占比, 流动性, 情绪指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{1}{T}\sum_{n=t}^{t-T+1} \frac{\sum_{j=1}^{N}(LargeBuyVolume_{i,j,n} - LargeSellVolume_{i,j,n})}{\sum_{j=1}^{N}TotalVolume_{i,j,n}}

LargeBuyVolume_{i,j,n}

LargeSellVolume_{i,j,n}

TotalVolume_{i,j,n}  
DSL公式: /1TSUM_n=t**t-T+1 /SUM_j=1**N(LargeBuyVolume_i,j,n - LargeSellVolume_i,j,n)SUM_j=1**NTotalVolume_i,j,n
LargeBuyVolume_i,j,n
LargeSellVolume_i,j,n
TotalVolume_i,j,n  
描述: 该因子捕捉的是开盘时段大单资金的净买入强度。正值代表开盘时段大单净买入，负值代表大单净卖出。 数值越大，表示大资金在开盘时段买入意愿越强烈。该因子隐含假设是：大资金在开盘阶段的交易行为，可能预示着当日或短期内的价格趋势，反映了市场情绪和短期资金流向。 使用该因子时，需要结合其他因子进行综合分析，并注意不同市场环境和股票本身的特性。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。冯...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/large-order-net-buy-ratio
