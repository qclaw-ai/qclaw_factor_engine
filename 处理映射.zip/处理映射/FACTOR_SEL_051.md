# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_051  
因子名称: 普通股股东权益回报率(TTM)  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, ttm, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{\text{Net Income}_{TTM} - \text{Preferred Dividends}_{TTM}}{\text{Average Common Equity}}

\frac{\text{Common Equity}_{Current} + \text{Common Equity}_{PriorYear}}{\text{2}}

\text{Net Income}_{TTM}

\text{Preferred Dividends}_{TTM}

\text{Average Common Equity}

\text{Common Equity}_{Current}

\text{Common Equity}_{PriorYear}

参数说明：Net：IncomeTTM\text{Net Income}_{TTM}Net IncomeTTM​:最近12个月的归属于普通股股东的净利润总额 (Trailing Twelve Months Net Income attributable to common shareholders)。Preferred DividendsTTM\text{Preferred Dividends}_{TTM}Preferred DividendsTTM​:最近12个月的优先股股利总额 (Trailing Twelve Months Preferred Dividends)。如果公司没有发行优先股，则该项为0。Average Common Equity\text{Average Common Equity}Average Common Equity:最近12个月内平均普通股股东权益 (Average Common Equity), 通过期初和期末的普通股股东权益的平均值计算得出。Common EquityCurrent\text{Common Equity}_{Current}Common EquityCurrent​:本期（通常指报告期末）的普通股股东权益。Common EquityPriorYear\text{Common Equity}_{PriorYear}Common EquityPriorYear​:上年同期（与本期对应的上一年同一时点）的普通股股东权益。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors普通股股东权益回报率(TTM)基础面因子因子公式Net IncomeTTM−Preferred DividendsTTMAverage Common Equity \frac{\text{Net Income}_{TTM} - \text{Preferred Dividends}_{TTM}}{\text{Average Common Equity}} Average Common EquityNet IncomeTTM​−Preferred DividendsTTM​​平均普通股股东权益 =Co...  
DSL公式: /\textNet Income_TTM - \textPreferred Dividends_TTM\textAverage Common Equity
/\textCommon Equity_Current + \textCommon Equity_PriorYear\text2
\textNet Income_TTM
\textPreferred Dividends_TTM
\textAverage Common Equity
\textCommon Equity_Current
\textCommon Equity_PriorYear  
描述: 普通股股东权益回报率(TTM)衡量的是公司在过去12个月内，利用普通股股东投入的资本所实现的盈利能力。它体现了公司经营效率和为普通股股东创造价值的能力。该指标越高，表明公司利用普通股股东权益创造利润的能力越强，对普通股股东的回报越高。该指标通常在同行业内进行比较，以评估公司的相对盈利能力。 因子解释普通股股东权益回报率(TTM)衡量的是公司在过去12个月内，利用普通股股东投入的资本所实现的盈利能力...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/common-stock-return
