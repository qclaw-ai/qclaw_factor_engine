# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_106  
因子名称: 一致性下跌成交量比率因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 一致性下跌成交量比率因子, 动量, 成长, 价值, 量化交易  
原始公式: |close - open| \le \alpha |high - low|

NCVR_t = -\frac{1}{d}\sum_{i=1}^{d} \frac{ConsistentVolume_{(fall)_{t-i}}}{Volume_t}

\alpha

ConsistentVolume_{(fall)}

Volume

参数说明：α\alphaα:一致性阈值参数，用于定义K线实体程度。$\alpha$ 值越大，则K线实体部分相对于整体波动的占比越大，即上下影线越短，K线实体越显著，一致性程度越高。通常建议取值范围为[0.1, 0.5]，具体数值需要根据回测结果进行调整。ConsistentVolume(fall)ConsistentVolume_{(fall)}ConsistentVolume(fall)​:指定时段内（例如：5分钟K线）满足一致性判断条件，且为下跌（收盘价低于开盘价）的K线对应的成交量总和，反映了市场一致性抛售力量。VolumeVolumeVolume:当日总成交量，作为基准，用于计算一致性下跌成交量在当日成交量中的占比。ddd:移动平均周期参数，用于平滑处理历史一致性下跌成交量比率，减少单日波动对因子值的影响。通常建议取值范围为[5, 20]，具体数值需要根据回测结果进行调整。 实体K线一致性买入强度因子 实体K线一致性交易强度因子 大单成交量价动量 开盘时段大单净额占比 主力成交额-价格相关性因子 成交额波动率 负收益成交额加权非流动性因子 开盘时段主动净买额占比 收益动量一致性因子 Related Factors 实体K线一致性买入强度因子 实体K线一致性交易强度因子 大单成交量价动量 开盘时段大单净额占比 主力成交额-价格相关性因子 成交额波动率 负收益成交额加权非流动性因子 开盘时段主动净买额占比 收益动量一致性因子 ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子仅供教育和研究目的，不构成投资建议。•在做出任何投资决策之前，请咨询合格的财务顾问。 移动平均周期参数，用于平滑处理历史一致性下跌成交量比率，减少单日波动对因子值的影响。通常建议取值范围为[5, 20]，具体数值需要根据回测结果进行调整。 金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors一致性下跌成交量比率技术因子因子公式一致性K线判断条件:∣close−open∣≤α∣high−low∣ |close - open| \le \alpha |high - low| ∣close−open∣≤α∣high−low∣一致性下跌成交量比率因子:NCVRt=−1d∑i=1dConsistentVolume(fall)t−iVolumet NCVR_t = -\frac{1}{d}\sum_{i=1}^{d} \frac{ConsistentVolume_{(fall)_{t-i}}}{Volume_t} NCVRt​=−d1​i=1∑d​Volumet​ConsistentVolume(fall)t−i​​​其中：α\...  
DSL公式: |close - open| \le alpha |high - low|
NCVR_t = -/1dSUM_i=1**d /ConsistentVolume_(fall)_t-iVolume_t
alpha
ConsistentVolume_(fall)
Volume  
描述: 因子解释该因子旨在捕捉市场中可能存在的集体性抛售行为。当一段时间内，股票交易中出现大量一致性下跌的K线，且这些K线的成交量占比较高时，表明市场可能存在一致性的抛售压力。这种现象往往意味着市场对该股票的未来走势存在负面预期，或者受到了某些负面事件的影响，从而导致投资者集中抛售。该因子值越高（负值越大），表示市场抛售压力越大，投资者应谨慎对待。反之，如果因子值接近于0，则表明市场一致性下跌抛售行为不明...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/consistent-sell-trade
