# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_125  
因子名称: 累计振荡指标  
分类: : 技术指标  
标签: : 流动性, 技术指标, 技术分析, 质量, 动量, 成长, 价值, 量化交易  
原始公式: A = |HIGH - CLOSE_{t-1}|

B = |LOW - CLOSE_{t-1}|

C = |HIGH - LOW_{t-1}|

D = |CLOSE_{t-1} - OPEN_{t-1}|

E = CLOSE_t - CLOSE_{t-1}

F = CLOSE_t - OPEN_t

G = CLOSE_{t-1} - OPEN_{t-1}

X = E + 0.5F + G

K = MAX(A, B)

R = \begin{cases} A + 0.5B + 0.25D, & \text{if } A > B \text{ and } A > C \\ B + 0.5A + 0.25D, & \text{if } B > A \text{ and } B > C \\ C + 0.25D, & \text{otherwise} \end{cases}

参数说明：HIGHHIGHHIGH：当日的最高价，表示该交易日内达到的最高价格。LOWLOWLOW:当日的最低价，表示该交易日内达到的最低价格。CLOSECLOSECLOSE:当日的收盘价，表示该交易日结束时的最后成交价格。OPENOPENOPEN:当日的开盘价，表示该交易日开始时的第一笔成交价格。[t−1][t-1][t−1]:表示前一个交易日的数据，例如 CLOSE[t-1] 表示前一个交易日的收盘价。ABS()ABS()ABS():表示绝对值函数，返回一个数值的非负值。MAX(A,B)MAX(A,B)MAX(A,B):表示取 A 和 B 两个数值中的最大值。∑i=t−N+1tSIi\sum_{i=t-N+1}^{t} SI_i∑i=t−N+1t​SIi​:表示从 t-N+1 到 t 这 N 个交易日的 SI 值之和，即过去 N 天的振荡指数的累加和。NNN:计算 ASI 的周期参数，表示累加 SI 的天数。默认情况下，N 的常用值为 14 或 20，具体数值可根据交易策略和市场情况调整。 A =A=∣HIGH−CLOSEt−1∣ A = |HIGH - CLOSE_{t-1}| A=∣HIGH−CLOSEt−1​∣A 表示当日最高价与前一日收盘价之差的绝对值，衡量了当日最高价相对于前一日收盘价的波动幅度。 R =R={A+0.5B+0.25D,if A>B and A>CB+0.5A+0.25D,if B>A and B>CC+0.25D,otherwise R = \begin{cases} A + 0.5B + 0.25D, & \text{if } A > B \text{ and } A > C \\ B + 0.5A + 0.25D, & \text{if } B > A \text{ and } B > C \\ C + 0.25D, & \text{otherwise} \end{cases} R=⎩⎨⎧​A+0.5B+0.25D,B+0.5A+0.25D,C+0.25D,​if A>B and A>Cif B>A and B>Cotherwise​R 是一个加权价格波动范围，根据 A、B 和 C 的大小关系来决定计算方式。当 A > B 且 A > C 时，使用 A 权重最高；当 B > A 且 B > C 时，使用 B 权重最高；否则，使用 C 和前一日的波动范围 D。R 用于衡量价格的整体波动幅度，并且能够捕捉不同情况下价格波动的特性，是计算SI的一个标准化参数。 X =X=E+0.5F+G X = E + 0.5F + G X=E+0.5F+GX 是一个综合价格变化指标，它结合了当日收盘价相对于前一日收盘价的变化 (E)，当日收盘价相对于当日开盘价的变化 (F) 的一半权重，以及前一日收盘价相对于前一日开盘价的变化 (G)，用于衡量综合的价格动量。 ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子仅供教育和研究目的，不构成投资建...  
DSL公式: A = |high - CLOSE_t-1|
B = |low - CLOSE_t-1|
C = |high - LOW_t-1|
D = |CLOSE_t-1 - OPEN_t-1|
E = CLOSE_t - CLOSE_t-1
F = CLOSE_t - OPEN_t
G = CLOSE_t-1 - OPEN_t-1
X = E + 0.5F + G
K = MAX(A, B)
R = \begincases A + 0.5B + 0.25D, & \textif A > B \text and A > C \\ B + 0.5A + 0.25D, & \textif B > A \text and B > C \\ C + 0.25D, & \textotherwise \endcases  
描述: X 是一个综合价格变化指标，它结合了当日收盘价相对于前一日收盘价的变化 (E)，当日收盘价相对于当日开盘价的变化 (F) 的一半权重，以及前一日收盘价相对于前一日开盘价的变化 (G)，用于衡量综合的价格动量。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。John J. Murphy. (1999). 技术分析指标大全. Technical Analysis of the Fin...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/accumulated-oscillation-index
