# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_060  
因子名称: 下行/上行波动率比率  
分类: : 波动率指标  
标签: : 流动性, 上行波动率比率, 下行, 质量, 动量, 成长, 价值, 量化交易  
原始公式: DUVR = \log\left( \frac{(n_d - 1) \sum_{r_{it} < \bar{r_i}} (r_{it} - \bar{r_i})^2}{(n_u - 1) \sum_{r_{it} \ge \bar{r_i}} (r_{it} - \bar{r_i})^2} \right)

r_{it}

\bar{r_i}

n_u

n_d

\sum_{r_{it} < \bar{r_i}} (r_{it} - \bar{r_i})^2

\sum_{r_{it} \ge \bar{r_i}} (r_{it} - \bar{r_i})^2

参数说明：ritr_：{it}rit​:股票i在t时刻的收益率，通常使用对数收益率计算，即 $r_{it} = \ln(P_{it}/P_{it-1})$，其中$P_{it}$是股票i在t时刻的价格。riˉ\bar{r_i}ri​ˉ​:股票i在考察期间的平均收益率，计算方式为 $\bar{r_i} = \frac{1}{T} \sum_{t=1}^{T} r_{it}$，其中T为考察期内的总时间周期数。nun_unu​:股票i在考察期间收益率大于或等于平均收益率 $\bar{r_i}$ 的天数，即上行收益的天数。ndn_dnd​:股票i在考察期间收益率小于平均收益率 $\bar{r_i}$ 的天数，即下行收益的天数。∑rit<riˉ(rit−riˉ)2\sum_{r_{it} < \bar{r_i}} (r_{it} - \bar{r_i})^2rit​<ri​ˉ​∑​(rit​−ri​ˉ​)2:股票i在考察期间所有下行收益（收益率小于平均收益率）的收益率与平均收益率差的平方和，衡量了下行收益的波动程度，也称为下行方差。∑rit≥riˉ(rit−riˉ)2\sum_{r_{it} \ge \bar{r_i}} (r_{it} - \bar{r_i})^2rit​≥ri​ˉ​∑​(rit​−ri​ˉ​)2:股票i在考察期间所有上行收益（收益率大于或等于平均收益率）的收益率与平均收益率差的平方和，衡量了上行收益的波动程度，也称为上行方差。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子仅供教育和研究目的，不构成投资建议。•在做出任何投资决策之前，请咨询合格的财务顾问。 Factors DirectoryQuantitative Trading Factors下行/上行波动率比率波动率因子因子公式下行/上行波动率比率 (DUVR):DUVR=log⁡((nd−1)∑rit<riˉ(rit−riˉ)2(nu−1)∑rit≥riˉ(rit−riˉ)2) DUVR = \log\left( \frac{(n_d - 1) \sum_{r_{it} < \bar{r_i}} (r_{it} - \bar{r_i})^2}{(n_u - 1) \sum_{r_{it} \ge \bar{r_i}} (r_{it} - \bar{r_i})^2} \right) DUVR=log((nu​−1)∑rit​≥ri​ˉ​​(rit​−ri​ˉ​)2(nd​−1)∑rit​<ri​ˉ​​(rit​−ri​ˉ​)2​)其中：ritr_{it}rit​:股票i在t时刻的收益率，通常使用对数收益率计算，即 $r_{it} = \ln(P_{it}/P_{it-1})$，其中$P_{it}$是股票i在t时刻的价格。riˉ\bar{r_i}ri​ˉ​:股票i在考察期间的平均收益率，计算方式为 $\bar{r_i} = \frac{1}{T} \sum_{t=1}^{T} r_{it}$，其中T为考察期内的总时间周期数。nun_unu​:股票i在考察期间收益率大于或等于平均收益率 $\bar{r_i}$ 的天数，即上行收益的天数。ndn_dnd​:股票i在考察期间收益率小于平均收益率 $\bar{r_i}$ 的天数，即下行收益的天数。∑rit<riˉ(rit−riˉ)2\sum_{r_{it} < \bar{r_i}} (r_{it} - \bar{r_i})^2rit​<ri​ˉ​∑​(rit​−ri​ˉ​)2:股票i在考察期间所有下行收益（收益率小于平均收益率）的收益率与平均收益率差的平方和，衡量了下行收益的波动程度，也称为下行方...  
DSL公式: DUVR = LOG( /(n_d - 1) SUM_r_it < \barr_i (r_it - \barr_i)**2(n_u - 1) SUM_r_it \ge \barr_i (r_it - \barr_i)**2 )
r_it
\barr_i
n_u
n_d
SUM_r_it < \barr_i (r_it - \barr_i)**2
SUM_r_it \ge \barr_i (r_it - \barr_i)**2  
描述: Related Factors 高频上行已实现波动占比 下行风险贝塔 负收益成交额加权非流动性因子 成交额波动率 盈余波动率因子 (Earnings Volatility Factor) 特异性收益波动因子 历史波动率（Total Volatility） 换手率波动率 成交量相对强度指标 在实际应用中，可以采用不同的时间窗口计算该因子，例如每日、每周、每月等，不同的时间窗口可能会导致因子值和预测能...
因子类型: : 波动率指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/volatility/up-down-volatility-ratio
