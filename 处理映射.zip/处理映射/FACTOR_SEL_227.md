# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_227  
因子名称: 分析师目标价调整动量因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 动量, 成长, 分析师目标价调整动量因子, 价值, 量化交易  
原始公式: WeightedTargetPrice_{current} - WeightedTargetPrice_{lastyear}

WeightedTargetPrice_{current}

WeightedTargetPrice_{lastyear}

参数说明：WeightedTargetPricecurrentWeightedTargetPrice_：{current}WeightedTargetPricecurrent​:当前最新分析师目标价的加权平均值。具体而言，对于每只股票，我们将所有覆盖该股票的分析师给出的最新目标价，以一定的权重（如分析师的评级、历史预测准确率等）进行加权平均。此权重可以根据策略需求灵活调整，默认为等权重。WeightedTargetPricelastyearWeightedTargetPrice_{lastyear}WeightedTargetPricelastyear​:去年同期（对应当前日期）分析师目标价的加权平均值。计算方法与当前加权平均值一致，确保同比比较的基准一致性。因子解释该因子通过计算当前最新分析师目标价加权平均值与去年同期值的差值，衡量了分析师目标价在过去一年中的变化动量。正值表示分析师整体上调了对该股票的目标价格，负值则表示整体下调。 该因子的逻辑是，分析师的目标价调整通常反映了他们对公司未来前景的预期变化，而这些变化可能会在短期内对股票价格产生影响。尤其当分析师下调目标价时，可能会引发市场负面情绪，导致股价下跌，这被称为分析师目标价负向动量效应。因此，该因子可以用来捕捉市场对分析师预期调整的反应。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。魏建榕. (2021). 分析师目标价的Alpha信息. 开源证券Related Factors 分析师目标价隐含收益率 分析师预期收益率加权平均因子 一致预期收益率 (Consensus Target Price Return) 分析师一致预期EPS修正比率 分析师预期EPS调整幅度 20日区间收益率动量/反转因子 52周最高价逼近度 60日盈利市值比率变动 收益动量一致性因子 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors分析师目标价调整动量技术因子因子公式分析师目标价加权平均值的同比增量，计算公式如下：WeightedTargetPricecurrent−WeightedTargetPricelastyear WeightedTargetPrice_{current} - WeightedTargetPrice_{lastyear} WeightedTargetPricecurrent​−WeightedTargetPricelastyear​其中：WeightedTargetPricecurrentWeightedTargetPrice_{current}WeightedTargetPricecurrent​:当前最新分析师目标价的加权平均值。具体而言，对于每只股票，我们将所有覆盖该股票的分析师给出的最新目标价，以一定的权重（如分析师的评级、历史预测准确率等）进行加权平均。此权重可以根据策略需求灵活调整，默认为等权重。WeightedTargetPricelastyearWeightedTargetPrice_{lastyear}WeightedTargetPricelastyear​:去年同期（对应当前日期）分析师目标价的加权平均值。计算方法与当前加权平均值一致，确保同比比较的基准一致性。因子解释该因子通过计算当前最新分析师目标价加权平均值与去年同期值的差值，衡量了分析师目标价在过去一年中的变化动量。正值表示分析师整体上调了对该股票的目标价格，负值则表示整体下调。 该因子的逻辑是，分析师的目标价调整通常反映了他们对公司未来前景的预期变化，而这些变化可能会在短期内对股票价格产生影响。尤其当分析师下调目标价时，可能会引发市场负面情绪，导致股价下跌，这被称为分析师目标价负向动量效应。因此，该因子可以用来捕捉市场对分析师预期调整的反应。⚠️ 因子...  
DSL公式: WeightedTargetPrice_current - WeightedTargetPrice_lastyear
WeightedTargetPrice_current
WeightedTargetPrice_lastyear  
描述: Factors DirectoryQuantitative Trading Factors分析师目标价调整动量技术因子因子公式分析师目标价加权平均值的同比增量，计算公式如下：WeightedTargetPricecurrent−WeightedTargetPricelastyear WeightedTargetPrice_{current} - WeightedTargetPrice_{lasty...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/adjust-expected-yield
