# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_023  
因子名称: 克林格成交量震荡指标  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 动量, 成长, 克林格成交量震荡指标, 价值, 量化交易  
原始公式: TR = IF(HIGH_t + LOW_t + CLOSE_t > HIGH_{t-1} + LOW_{t-1} + CLOSE_{t-1}, 1, -1)

DM = HIGH_t - LOW_t

CM_t = IF(TR_t = TR_{t-1}, CM_{t-1} + DM_t, DM_t + DM_{t-1})

VF_t = VOL_t * ABS(2 * (\frac{DM_t}{CM_t} - 1)) * TR_t * 100

KVO(N_1, N_2)_t = EMA(VF_t, N_1) - EMA(VF_t, N_2)

TR_t

DM_t

CM_t

VF_t

VOL_t  
DSL公式: TR = IF(HIGH_t + LOW_t + CLOSE_t > HIGH_t-1 + LOW_t-1 + CLOSE_t-1, 1, -1)
DM = HIGH_t - LOW_t
CM_t = IF(TR_t = TR_t-1, CM_t-1 + DM_t, DM_t + DM_t-1)
VF_t = VOL_t * ABS(2 * (/DM_tCM_t - 1)) * TR_t * 100
KVO(N_1, N_2)_t = EMA(VF_t, N_1) - EMA(VF_t, N_2)
TR_t
DM_t
CM_t
VF_t
VOL_t  
描述: Related Factors 成交量动量摆动指标 蔡金资金流量震荡指标 成交量异同移动平均线 (VMACD) 成交量能量潮指标 (On-Balance Volume) 简易波动指标 (Easy of Movement Value, EMV) 成交量价背离度 成交量相对强度指标 随机摆动指标 实体K线一致性买入强度因子 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/klinger-volume-oscillator
