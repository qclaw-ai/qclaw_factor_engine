# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_153  
因子名称: 单季度净利润同比增速  
分类: : 成长性指标  
标签: : 流动性, 成长性指标, 单季度净利润同比增速, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{NetProfit_{Q_t} - NetProfit_{Q_{t-4}}}{|NetProfit_{Q_{t-4}}|}

NetProfit_{Q_t}

NetProfit_{Q_{t-4}}

|x|  
DSL公式: /NetProfit_Q_t - NetProfit_Q_t-4|NetProfit_Q_t-4|
NetProfit_Q_t
NetProfit_Q_t-4
|x|  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。乔治·福斯特. (2013). 财务报表分析. 机械工业出版社阿斯沃斯·达莫达兰. (2012). 投资估值. 中国人民大学出版社 单季度净利润同比增速成长因子因子公式单季度净利润同比增速:NetProfitQt−NetProfitQt−4∣NetProfitQt−4∣ \frac{NetProfit_{Q_t} - NetProfi...
因子类型: : 成长性指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/growth/single-quarter-net-profit-yoy
