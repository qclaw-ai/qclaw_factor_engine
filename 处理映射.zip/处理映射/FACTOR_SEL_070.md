# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_070  
因子名称: 分析师覆盖度残差因子  
分类: : 情绪指标  
标签: : 流动性, 分析师覆盖度残差因子, 情绪指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \ln(1 + COV_{i,m}) = \beta_0 + \beta_1 \ln(SIZE_{i,m}) + \beta_2 \ln(LNTO_{i,m}) + \beta_3 MOM_{i,m} + \varepsilon_{i,m}

COV_{i,m}

SIZE_{i,m}

LNTO_{i,m}

MOM_{i,m}

\varepsilon_{i,m}

\beta_0

\beta_1

\beta_2

\beta_3

参数说明：COVi：,mCOV_{i,m}COVi,m​:为第i只股票在第m个月底的分析师覆盖度，通常使用分析师总覆盖家数。SIZEi,mSIZE_{i,m}SIZEi,m​:为第i只股票在第m个月底的总市值。此处公式中使用的是其对数形式，即$\ln(SIZE_{i,m})$。总市值通常指流通市值，以避免因股权结构变化导致市值波动。LNTOi,mLNTO_{i,m}LNTOi,m​:为第i只股票截止到第m个月底过去三个月的日均换手率。 此处公式中使用的是其对数形式，即$\ln(LNTO_{i,m})$。 换手率可以反映股票的活跃程度，为提高数据的稳定性，通常计算日均换手率， 并求对数。MOMi,mMOM_{i,m}MOMi,m​:为第i只股票截止到第m个月底过去三个月的累计收益率，反映了股票的短期动量效应。εi,m\varepsilon_{i,m}εi,m​:为回归残差，即为本因子所定义的分析师覆盖度残差，反映了无法被市值、换手率、动量解释的分析师覆盖度。β0\beta_0β0​:回归模型的截距项β1\beta_1β1​:为总市值对数对分析师覆盖度对数的回归系数，反映了市值对分析师覆盖度的影响程度。β2\beta_2β2​:为过去三个月日均换手率对数对分析师覆盖度对数的回归系数，反映了换手率对分析师覆盖度的影响程度。β3\beta_3β3​:为过去三个月收益率对分析师覆盖度对数的回归系数，反映了动量效应在分析师覆盖上的影响程度。因子解释分析师覆盖度通常被认为是市场关注度的指标，但它并非完全由基本面驱动。该因子将分析师覆盖度分解为两部分：一部分是可以通过市值、换手率和动量等基本面因素解释的“预期”覆盖度；另一部分则是无法被这些因素解释的“残差”覆盖度。该残差项更能够反映分析师的主观选择性，以及可能存在的羊群效应等行为偏差。研究表明，残差覆盖度与股票的超额收益存在显著的正相关关系。因此，该因子可以被视为一个有价值的选股信号。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Charles M.C. Lee, Eric C. So. (2016). Uncovering expected returns: Information in analyst coverage proxies. Journal of Financial Economics朱剑涛. (2017). 分析师研报的数据特征与alpha. 东方证券Related Factors 市值中性化换手率残差 分析师覆盖率 残差市值偏离度 分析师覆盖度 Fama-French三因子模型残差动量 分析师共识覆盖加权动量 基本面趋势预期收益率 CAPM残差动量因子 新闻共现注意力溢出因子 为第i只股票截止到第m个月底过去三个月的日均换手率。 此处公式中使用的是其对数形式，即$\ln(LNTO_{i,m})$。 换手率可以反映股票的活跃程度，为提高数据的稳定性，通常计算日均换手率， 并求对数。 分析师覆盖度残差计算公式:ln⁡(1+COVi,m)=β0+β1ln⁡(SIZEi,m)+β2ln⁡(LNTOi,m)+β3MOMi,m+εi,m \ln(1 + COV_{i,m}) = \beta_0 + \beta_1 \ln(SIZE_{i,m}) + \beta_2 \ln(LNTO_{i,m}) + \beta_3 MOM_{i,m} + \varepsilon_{i,m} ln(1+COVi,m​)=β0​+β1​ln(SIZEi,m​...  
DSL公式: LN(1 + COV_i,m) = beta_0 + beta_1 LN(SIZE_i,m) + beta_2 LN(LNTO_i,m) + beta_3 MOM_i,m + \varepsilon_i,m
COV_i,m
SIZE_i,m
LNTO_i,m
MOM_i,m
\varepsilon_i,m
beta_0
beta_1
beta_2
beta_3  
描述: 分析师覆盖度通常被认为是市场关注度的指标，但它并非完全由基本面驱动。该因子将分析师覆盖度分解为两部分：一部分是可以通过市值、换手率和动量等基本面因素解释的“预期”覆盖度；另一部分则是无法被这些因素解释的“残差”覆盖度。该残差项更能够反映分析师的主观选择性，以及可能存在的羊群效应等行为偏差。研究表明，残差覆盖度与股票的超额收益存在显著的正相关关系。因此，该因子可以被视为一个有价值的选股信号。 分析师...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/analyst-coverage-anomaly
