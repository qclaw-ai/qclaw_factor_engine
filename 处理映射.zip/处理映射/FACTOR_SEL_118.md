# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_118  
因子名称: 方向性动量离散指标 (Directional Momentum Dispersion Index)  
分类: : 技术指标  
标签: : directional, 流动性, 方向性动量离散指标, 技术指标, index, 技术分析, 质量, 动量  
原始公式: DMZ = \begin{cases}  0, & \text{if } HIGH_t + LOW_t \le HIGH_{t-1} + LOW_{t-1}  \\  \max(|HIGH_t - HIGH_{t-1}|, |LOW_t - LOW_{t-1}|) , & \text{otherwise} \end{cases}

DMF = \begin{cases}  0, & \text{if } HIGH_t + LOW_t > HIGH_{t-1} + LOW_{t-1}  \\  \max(|HIGH_t - HIGH_{t-1}|, |LOW_t - LOW_{t-1}|) , & \text{otherwise} \end{cases}

DIZ_t = \frac{\sum_{i=t-N+1}^{t} DMZ_i}{\sum_{i=t-N+1}^{t} DMZ_i + \sum_{i=t-N+1}^{t} DMF_i} \times 100

DIF_t = \frac{\sum_{i=t-N+1}^{t} DMF_i}{\sum_{i=t-N+1}^{t} DMZ_i + \sum_{i=t-N+1}^{t} DMF_i} \times 100

DDI_t = DIZ_t - DIF_t

\text{若分母为0,则令 DDI = 0}

HIGH_t

LOW_t

HIGH_{t-1}

LOW_{t-1}

参数说明：HIGHtHIGH_tHIGHt：​:第 t 日的最高价LOWtLOW_tLOWt​:第 t 日的最低价HIGHt−1HIGH_{t-1}HIGHt−1​:第 t-1 日的最高价LOWt−1LOW_{t-1}LOWt−1​:第 t-1 日的最低价DMZtDMZ_tDMZt​:第 t 日的向上动量值。当今日最高价和最低价之和不大于前一日时，DMZ为0；否则，DMZ取今日最高价与前一日最高价之差的绝对值和今日最低价与前一日最低价之差的绝对值中的较大者。DMFtDMF_tDMFt​:第 t 日的向下动量值。当今日最高价和最低价之和大于前一日时，DMF为0；否则，DMF取今日最高价与前一日最高价之差的绝对值和今日最低价与前一日最低价之差的绝对值中的较大者。∑i=t−N+1tDMZi\sum_{i=t-N+1}^{t} DMZ_ii=t−N+1∑t​DMZi​:从第 t-N+1 日到第 t 日的 DMZ 之和，即 N 日内向上动量之和。∑i=t−N+1tDMFi\sum_{i=t-N+1}^{t} DMF_ii=t−N+1∑t​DMFi​:从第 t-N+1 日到第 t 日的 DMF 之和，即 N 日内向下动量之和。NNN:时间窗口大小，代表计算动量的回溯期长度，默认值为 20 个交易日。N 的选择会影响 DDI 的灵敏度，较小的 N 值会使 DDI 更为敏感，而较大的 N 值会使其更平滑。DIZtDIZ_tDIZt​:第 t 日的正向动量指数，表示 N 日内向上动量占总动量的百分比。DIFtDIF_tDIFt​:第 t 日的负向动量指数，表示 N 日内向下动量占总动量的百分比。DDItDDI_tDDIt​:第 t 日的方向性动量离散指标，通过 DIZ 减去 DIF 计算得出，可以反映市场动量的相对强弱。 时间窗口大小，代表计算动量的回溯期长度，默认值为 20 个交易日。N 的选择会影响 DDI 的灵敏度，较小的 N 值会使 DDI 更为敏感，而较大的 N 值会使其更平滑。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 Related Factors 动态趋向指标 资金流量累积指标 (Accumulation/Distribution Line, A/D) 日内强度指标 (Intraday Momentum Index, IMI) 相对波动性指标 商品通道指数 随机动量指标 (SMI) 移动平均汇聚背离指标 佳庆波动率离散指标 累计振荡指标 ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子仅供教育和研究目的，不构成投资建议。•在做出任何投资决策之前，请咨询合格的财务顾问。 金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。 动态趋向指标 资金流量累积指标 (Accumulation/Distribution Line, A/D) 日内强度指标 (Intraday Momentum Index, IMI) 相对波动性指标 商品通道指数 随机动量指标 (SMI) 移动平均汇聚背离指标 佳庆波动率离散指标 累计振荡指标 方向性动量离散指标 (DDI) 通过比较向上和向下动量的大小，并进行平滑处理，以识别潜在的趋势反转和超买超卖区域。DDI的核心逻辑在于衡量一段时间内，价格向上和向下波动的相对强度。当DDI值偏高时，可能暗示市场处于超买状态，或者向上动量占优；反之，当DDI值偏低时，可能暗示市场处于超卖状态，或者向下动量占优。投资者可以通过DDI的趋势变化和极值区域，来辅助判断市场趋势的强弱以及潜在的反转机会。此外，该指标也可与其他技术指标结合使用，以提高交易决策的准确性。DDI指标适合于短线和中线交易，能够帮助投资者快速捕捉市场动能的转折点。 方向性动量离散指标 (DDI) =DDIt=DIZt−DIFt DDI_t = DIZ_t - DIF_t DDIt​=DIZt​...  
DSL公式: DMZ = \begincases 0, & \textif HIGH_t + LOW_t \le HIGH_t-1 + LOW_t-1 \\ MAX(|HIGH_t - HIGH_t-1|, |LOW_t - LOW_t-1|) , & \textotherwise \endcases
DMF = \begincases 0, & \textif HIGH_t + LOW_t > HIGH_t-1 + LOW_t-1 \\ MAX(|HIGH_t - HIGH_t-1|, |LOW_t - LOW_t-1|) , & \textotherwise \endcases
DIZ_t = /SUM_i=t-N+1**t DMZ_iSUM_i=t-N+1**t DMZ_i + SUM_i=t-N+1**t DMF_i * 100
DIF_t = /SUM_i=t-N+1**t DMF_iSUM_i=t-N+1**t DMZ_i + SUM_i=t-N+1**t DMF_i * 100
DDI_t = DIZ_t - DIF_t
\text若分母为0,则令 DDI = 0
HIGH_t
LOW_t
HIGH_t-1
LOW_t-1  
描述: 因子解释方向性动量离散指标 (DDI) 通过比较向上和向下动量的大小，并进行平滑处理，以识别潜在的趋势反转和超买超卖区域。DDI的核心逻辑在于衡量一段时间内，价格向上和向下波动的相对强度。当DDI值偏高时，可能暗示市场处于超买状态，或者向上动量占优；反之，当DDI值偏低时，可能暗示市场处于超卖状态，或者向下动量占优。投资者可以通过DDI的趋势变化和极值区域，来辅助判断市场趋势的强弱以及潜在的反转机...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/directional-standard-deviation
