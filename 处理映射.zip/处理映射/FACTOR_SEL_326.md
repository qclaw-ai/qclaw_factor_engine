# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_326  
因子名称: 应计质量  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 应计质量, 质量, 动量, 成长, 价值, 量化交易  
原始公式: Accruals = \frac{(\Delta CA - \Delta Cash) - (\Delta CL - \Delta STD - \Delta TP) - Dep}{AverageTotalAssets}

\Delta CA

\Delta Cash

\Delta CL

\Delta STD

\Delta TP

Dep

AverageTotalAssets

参数说明：ΔCA\Delta CAΔCA:流动资产变动额 (Change in Current Assets)：指报告期内公司流动资产的净增加额。流动资产包括现金、应收账款、存货等。ΔCash\Delta CashΔCash:现金及现金等价物变动额 (Change in Cash and Cash Equivalents)：指报告期内公司现金和现金等价物的净增加额，包括银行存款、库存现金以及短期内可快速转换为现金的投资。ΔCL\Delta CLΔCL:流动负债变动额 (Change in Current Liabilities)：指报告期内公司流动负债的净增加额。流动负债包括应付账款、应付票据、短期借款等。ΔSTD\Delta STDΔSTD:短期借款变动额 (Change in Short-Term Debt)：指报告期内公司短期借款的净增加额。该项为流动负债的一部分，需要单独提取。ΔTP\Delta TPΔTP:应付税款变动额 (Change in Taxes Payable)：指报告期内公司应付税款的净增加额。该项为流动负债的一部分，需要单独提取。DepDepDep:折旧与摊销 (Depreciation and Amortization)：指报告期内的折旧和摊销费用总额。折旧是对固定资产的价值损耗进行分摊；摊销是对无形资产的价值损耗进行分摊。AverageTotalAssetsAverageTotalAssetsAverageTotalAssets:平均总资产 (Average Total Assets)：指报告期期初总资产和期末总资产的平均值，用于标准化应计项目，消除公司规模差异的影响。计算公式为 (期初总资产 + 期末总资产) / 2。 其中：ΔCA\Delta CAΔCA:流动资产变动额 (Change in Current Assets)：指报告期内公司流动资产的净增加额。流动资产包括现金、应收账款、存货等。ΔCash\Delta CashΔCash:现金及现金等价物变动额 (Change in Cash and Cash Equivalents)：指报告期内公司现金和现金等价物的净增加额，包括银行存款、库存现金以及短期内可快速转换为现金的投资。ΔCL\Delta CLΔCL:流动负债变动额 (Change in Current Liabilities)：指报告期内公司流动负债的净增加额。流动负债包括应付账款、应付票据...  
DSL公式: Accruals = /(\Delta CA - \Delta Cash) - (\Delta CL - \Delta STD - \Delta TP) - DepAverageTotalAssets
\Delta CA
\Delta Cash
\Delta CL
\Delta STD
\Delta TP
Dep
AverageTotalAssets  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Dechow P., Sloan R., Sweeney A. (1995). Detecting Earnings Management. The Accounting Review 70(2)Sloan R.. (1996). Do Stock Prices Fully Reflect Information in Accrual...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/surplus-quality
