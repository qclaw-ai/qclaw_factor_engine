# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_145  
因子名称: 每股经营性现金流 (Operating Cash Flow per Share, OCFPS)  
分类: : 基本面指标  
标签: : 流动性, ocfps, 基本面指标, flow, share, 动量, 成长, 质量  
原始公式: \frac{\text{最近12个月经营活动产生的现金流量净额(TTM)}}{\text{平均总股本}}

\text{平均总股本} = \frac{\text{期初总股本} + \text{期末总股本}}{2}

最近12个月经营活动产生的现金流量净额(TTM)

平均总股本  
DSL公式: /\text最近12个月经营活动产生的现金流量净额(TTM)\text平均总股本
\text平均总股本 = /\text期初总股本 + \text期末总股本2
最近12个月经营活动产生的现金流量净额(TTM)
平均总股本  
描述: 因子解释每股经营性现金流 (OCFPS) 是一个重要的每股指标，它衡量了公司每股股票所对应的经营活动产生的净现金流量。与每股收益（EPS）相比，OCFPS 可以更好地反映公司真实的盈利质量，因为它关注的是实际流入的现金而非账面利润。一个健康的 OCFPS 值表明公司有足够的现金流入来支持其运营，投资和分红。较高的 OCFPS 通常意味着公司有更强的盈利能力和财务稳定性。在量化投资中，该因子常被用来...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/operating-cash-flow-per-share
