# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_083  
因子名称: 每股资本公积金  
分类: : 基本面指标  
标签: : 流动性, 每股资本公积金, 基本面指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{Capital\ Reserve_{latest}}{Shares\ Outstanding_{latest}}

Capital Reserve_{latest}

Shares Outstanding_{latest}

参数说明：CapitalReservelatestCapital：Reserve_{latest}CapitalReservelatest​:表示最近报告期末的资本公积金总额，它来源于公司经营活动以外的各种资本投入，如溢价发行股票、接受捐赠等。资本公积金是股东权益的一部分，代表了公司未来的潜在资本。SharesOutstandinglatestShares Outstanding_{latest}SharesOutstandinglatest​:表示最近报告期末的普通股总股本数量。需要注意的是，这里使用的是普通股股本，不包括优先股等其他类型股本。因子解释每股资本公积金反映了公司每股普通股所拥有的资本公积金份额。较高的每股资本公积金可能表明公司拥有更强的潜在股本扩张能力和抗风险能力，因为资本公积金可以用来转增股本，从而增加公司的股本规模。反之，较低的每股资本公积金可能意味着公司在未来进行股本扩张的潜力较小。此指标应结合公司所属行业、历史数据以及其他财务指标进行综合分析，不可单独作为投资决策的唯一依据。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。常规通用财务指标Related Factors 每股盈余公积金 每股货币资金 每股未分配利润 (Retained Earnings Per Share) 每股净资产 每股留存收益 每股留存收益 每股留存收益(Retained Earnings per Share, REPS) 普通股股东权益回报率(TTM) 每股自由现金流（FCF Per Share） 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors每股资本公积金基础面因子因子公式每股资本公积金计算公式：Capital ReservelatestShares Outstandinglatest \frac{Capital\ Reserve_{latest}}{Shares\ Outstanding_{latest}} Shares Outstandinglatest​Capital Reservelatest​​其中：CapitalReservelatestCapital Reserve_{latest}CapitalReservelatest​:表示最近报告期末的资本公积金总额，它来源于公司经营活动以外的各种资本投入，如溢价发行股票、接受捐赠等。资本公积金是股东权益的一部分，代表了公司未来的潜在资本。SharesOutstandinglatestShares Outstanding_{latest}SharesOutstandinglatest​:表示最近报告期末的普通股总股本数量。需要注意的是，这里使用的是普通股股本，不包括优先股等其他类型股本。因子解释每股资本公积金反映了公司每股普通股所拥有的资本公积金份额。较高的每股资本公积金可能表明公司拥有...  
DSL公式: /Capital\ Reserve_latestShares\ Outstanding_latest
Capital Reserve_latest
Shares Outstanding_latest  
描述: 每股资本公积金反映了公司每股普通股所拥有的资本公积金份额。较高的每股资本公积金可能表明公司拥有更强的潜在股本扩张能力和抗风险能力，因为资本公积金可以用来转增股本，从而增加公司的股本规模。反之，较低的每股资本公积金可能意味着公司在未来进行股本扩张的潜力较小。此指标应结合公司所属行业、历史数据以及其他财务指标进行综合分析，不可单独作为投资决策的唯一依据。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/per-share-capital-reserve
