# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_258  
因子名称: 最大日收益率（Max Daily Return）  
分类: : 技术指标  
标签: : 流动性, 技术指标, daily, return, 质量, 动量, 成长, 价值  
原始公式: \max_{t \in [T-K, T]} {R_t}

R_t  
DSL公式: MAX_t \in [T-K, T] R_t
R_t  
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors最大日收益率（Max Daily Return）技术因子因子公式最大日收益率 (Max Daily Return):max⁡t∈[T−K,...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/max-yield
