# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_036  
因子名称: 20日区间收益率动量/反转因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 反转因子, 日区间收益率动量, 动量, 成长, 质量, 价值  
原始公式: \frac{close_t}{close_{t-20}}

close_t

close_{t-20}  
DSL公式: /close_tclose_t-20
close_t
close_t-20  
描述: Related Factors 52周最高价逼近度 收益动量一致性因子 60日盈利市值比率变动 行业日内隔夜动量因子 散户同步性因子 中期反转因子 (Medium-Term Reversal Factor) 过去K个月累计收益率动量因子 排序动量因子 多周期标准化移动平均动量因子 因子公式因子计算公式为:closetcloset−20 \frac{close_t}{close_{t-20}} cl...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/momentum-or-reversal
