# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_135  
因子名称: 行业领头羊动量溢价因子  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 行业领头羊动量溢价因子, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \text{对于行业 }i \text{，按照成交金额降序排列股票，取累计成交金额占比达到 } \lambda \% \text{ 的股票，定义为领头羊股票 } (Leader_{i}) \text{，其余股票定义为跟随者股票 } (Follower_{i}) 。

R_{Leader_{i}, t-n:t} = \frac{1}{N_{Leader_{i}}} \sum_{j=1}^{N_{Leader_{i}}} r_{j,t-n:t} \qquad  R_{Follower_{i}, t-n:t} = \frac{1}{N_{Follower_{i}}} \sum_{k=1}^{N_{Follower_{i}}} r_{k,t-n:t}

G_i = R_{Leader_{i}, t-n:t} - R_{Follower_{i}, t-n:t}

\lambda

Leader_{i}

Follower_{i}

N_{Leader_{i}}

N_{Follower_{i}}

r_{j,t-n:t}

r_{k,t-n:t}

参数说明：iii：代表特定的行业。λ\lambdaλ:累计成交金额占比阈值，用于区分行业内的领头羊股票和跟随者股票。例如，$\lambda=60%$ 表示选取累计成交金额最高的 60%的股票作为领头羊。LeaderiLeader_{i}Leaderi​:行业 $i$ 中的领头羊股票集合。FolloweriFollower_{i}Followeri​:行业 $i$ 中的跟随者股票集合。NLeaderiN_{Leader_{i}}NLeaderi​​:行业 $i$ 中领头羊股票的数量。NFolloweriN_{Follower_{i}}NFolloweri​​:行业 $i$ 中跟随者股票的数量。rj,t−n:tr_{j,t-n:t}rj,t−n:t​:领头羊股票 $j$ 在时间段 $t-n$ 到 $t$ 的收益率。rk,t−n:tr_{k,t-n:t}rk,t−n:t​:跟随者股票 $k$ 在时间段 $t-n$ 到 $t$ 的收益率。RLeaderi,t−n:tR_{Leader_{i}, t-n:t}RLeaderi​,t−n:t​:行业 $i$ 的领头羊股票在过去 $n$ 个交易日（从 $t-n$ 到 $t$）的平均收益率。例如，$n=20$ 表示使用过去20个交易日的数据。RFolloweri,t−n:tR_{Follower_{i}, t-n:t}RFolloweri​,t−n:t​:行业 $i$ 的跟随者股票在过去 $n$ 个交易日（从 $t-n$ 到 $t$）的平均收益率。例如，$n=20$ 表示使用过去20个交易日的数据。GiG_iGi​:行业 $i$ 的领头羊动量溢价因子，反映了该行业领头羊股票相对于跟随者股票的收益率差异。 该因子基于行业内股票的成交金额和收益率进行计算，旨在量化行业内部的动量效应差异。具体来说，我们首先将行业内股票按照成交金额排序，并选取累计成交金额达到一定比例（由 $\lambda$ 决定）的股票定义为领头羊股票。然后，计算领头羊股票和其余跟随者股票在过去一段时间（例如，20个交易日）的平均收益率。最后，通过计算领头羊股票平均收益率减去跟随者股票平均收益率，得到行业领头羊动量溢价因子。该因子旨在捕捉行业内领头羊股票相对于跟随者股票的超额收益动量。该因子背后的逻辑是，在行业内部，领头羊股票往往具有更强的市场关注度和资金流入，因此可能呈现出更强的动量效应。测试结果表明，行业领头羊股票可能呈现出持续的动量效应，而跟随者股票可能呈现出一定程度的反转效应。 计算行业领头羊动量溢价因子：Gi=RLeaderi,t−n:t−RFolloweri,t−n:t G_i = R_{Leader_{i}, t-n:t} - R_{Follower_{i}, t-n:t} Gi​=RLeaderi​,t−n:t​−RFolloweri​,t−n:t​ ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 Related Factors 排序动量因子 大单成交量价动量 CAPM残差动量因子 多时域移动平均动量因子 过去K个月累计收益率动量因子 多周期标准化移动平均动量因子 月度收益季节性动量因子 Fama-French三因子模型残差动量 收益动量一致性因子 ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子仅供教育和研究目的，不构成投资建议。•在做出任何投资决策之前，请咨询合格的财务顾问。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。魏建榕. (2020). A股行业动量的精细结构. 开源证券Tobias J. Moskowi...  
DSL公式: \text对于行业 i \text，按照成交金额降序排列股票，取累计成交金额占比达到 \lambda \% \text 的股票，定义为领头羊股票 (Leader_i) \text，其余股票定义为跟随者股票 (Follower_i) 。
R_Leader_i, t-n:t = /1N_Leader_i SUM_j=1**N_Leader_i r_j,t-n:t \qquad R_Follower_i, t-n:t = /1N_Follower_i SUM_k=1**N_Follower_i r_k,t-n:t
G_i = R_Leader_i, t-n:t - R_Follower_i, t-n:t
\lambda
Leader_i
Follower_i
N_Leader_i
N_Follower_i
r_j,t-n:t
r_k,t-n:t  
描述: 计算领头羊和跟随者的平均收益率：RLeaderi,t−n:t=1NLeaderi∑j=1NLeaderirj,t−n:tRFolloweri,t−n:t=1NFolloweri∑k=1NFollowerirk,t−n:t R_{Leader_{i}, t-n:t} = \frac{1}{N_{Leader_{i}}} \sum_{j=1}^{N_{Leader_{i}}} r_{j,t-n:t} ...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/industry-momentum-factor
