# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_225  
因子名称: 应计盈余比率（总额）  
分类: : 质量指标  
标签: : 流动性, 质量指标, 总额, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{Accruals_{TTM}}{AverageAssets}

Accruals_{TTM} = NetIncome_{TTM} - CFO_{TTM}

AverageAssets = \frac{TotalAssets_{Beginning} + TotalAssets_{Ending}}{2}

Accruals_{TTM}

NetIncome_{TTM}

CFO_{TTM}

AverageAssets

TotalAssets_{Beginning}

TotalAssets_{Ending}

参数说明：净利润(NetIncome)减去经营活动产生的现金流量净额(CFO)，可以理解为不涉及现金流量的净利润部分。此部分更容易受到会计准则选择和管理层会计判断的影响，具有更大的灵活性和主观性。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Richardson, Scott A., Richard G. Sloan, Mark T. Soliman, and Irem Tuna. (2005). Accrual reliability, earnings persistence and stock prices. Journal of Accounting and Economics 应计盈余比率（总额）是衡量公司盈余质量的重要指标，它反映了公司盈利中非现金部分的占比。较高的应计盈余比率意味着公司的盈利更多地依赖于会计估计和判断，而非实际的现金流入，这可能预示着较低的盈余持续性，以及更高的盈余操纵风险。投资者通常会关注该指标，并将其作为评估公司财务稳健性和盈利质量的重要参考。该指标的异常波动可能预示公司盈余管理行为，从而影响投资决策。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors总应计盈余比率质量因子因子公式应计盈余比率（总额）AccrualsTTMAverageAssets \frac{Accruals_{TTM}}{AverageAssets} AverageAssetsAccrualsTTM​​该公式计算了公司过去12个月的应计盈余总额与平均总资产的比率，用于衡量公司盈余中非现金部分所占比重。总应计盈余（TTM）计算公式AccrualsTTM=NetIncomeTTM−CFOTTM Accruals_{TTM} = NetIncome_{TTM} - CFO_{TTM} AccrualsTTM​=NetIncomeTTM​−CFOTTM​该公式计算了过去12个月的总应计盈余。其中净利润(NetIncome)减去经营活动产生的现金流量净额(CFO)，可以理解为不涉及现金流量的净利润部分。此部分更容易受到会计准则选择和管理层会计判断的影响，具有更大的灵活性和主观性。平均总资产计算公式AverageAssets=TotalAssetsBeginning+TotalAssetsEnding2 AverageAssets = \frac{TotalAssets_{Beginning} + TotalAssets_{Ending}}{2} AverageAssets=2TotalAssetsBeginning​+TotalAssetsEnding​​该公式计算了报告期初和期末总资产的平均值，用于衡量公司在该期间的平均资产规模，可以平滑总资产的波动性。 其中，TotalAssets_{Beginning} 表示报告期初的总资产， TotalAssets_{Ending} 表示报告期末的总资产。其中：AccrualsTTMAccruals_{TTM}AccrualsTTM​:过去12个月的总应计盈余。NetIncomeTTMNetIncome_{TTM}NetIncomeTTM​:过去12个月的净利润。CFOTTMCFO_{TTM}CFOTTM​:过去12个月的经营活动产生的现金流量净额。AverageAssetsAverageAssetsAverageAssets:平均总资产。TotalAssetsBeginningTotalAssets_{Beginning}TotalAssetsBeginning​:报告期初的总资产。TotalAssetsEndingTotalAssets_{Ending}TotalAssetsEnding​:报告期末的总资产。因子解释应计盈余比率（总额）是衡量公司盈余质量的重要指标，它反映了公司盈利中非现金部分的占比。较高的应计盈余比率意味着公司的盈利更多地依赖于会计估计和判断，而非实际的现金流入，这可能预示着较低的盈余持续性，以及更高的盈余操纵风险。投资者通常会关注该指标，并将其作为评估公司...  
DSL公式: /Accruals_TTMAverageAssets
Accruals_TTM = NetIncome_TTM - CFO_TTM
AverageAssets = /TotalAssets_Beginning + TotalAssets_Ending2
Accruals_TTM
NetIncome_TTM
CFO_TTM
AverageAssets
TotalAssets_Beginning
TotalAssets_Ending  
描述: 总应计盈余（TTM）计算公式AccrualsTTM=NetIncomeTTM−CFOTTM Accruals_{TTM} = NetIncome_{TTM} - CFO_{TTM} AccrualsTTM​=NetIncomeTTM​−CFOTTM​该公式计算了过去12个月的总应计盈余。其中净利润(NetIncome)减去经营活动产生的现金流量净额(CFO)，可以理解为不涉及现金流量的净利润部分。...
因子类型: : 质量指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/quality/quality-total-accrued-surplus
