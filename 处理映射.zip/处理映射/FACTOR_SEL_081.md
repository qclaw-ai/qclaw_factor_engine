# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_081  
因子名称: 季度总资产环比增长率  
分类: : 基本面指标  
标签: : 流动性, 季度总资产环比增长率, 基本面指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{Total Assets_{t} - Total Assets_{t-1}}{Total Assets_{t-1}}

Total Assets_{t}

Total Assets_{t-1}  
DSL公式: /Total Assets_t - Total Assets_t-1Total Assets_t-1
Total Assets_t
Total Assets_t-1  
描述: Related Factors 单季度账面价值增长率 单季度总资产报酬率同比变动 单季度总资产净利率同比变动 每股净资产同比增速 资产现金回报率 母公司股东权益环比增长率 固定资产占用权益比率 现金资产占比因子 资本支出增长率-N年（CAGR-N） 因子公式季度总资产环比增长率 = (本季度总资产 - 上一季度总资产) / 上一季度总资产TotalAssetst−TotalAssetst−1Tot...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/asset-growth-single-quarter
