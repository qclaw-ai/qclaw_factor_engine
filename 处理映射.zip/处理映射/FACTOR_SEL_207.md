# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_207  
因子名称: 基本面趋势预期收益率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 基本面趋势预期收益率, 质量, 动量, 成长, 价值, 量化交易  
原始公式: MA_{i,t,L}^{k} = \frac{F_{i,t} + F_{i,t-1} + ... + F_{i,t-L+1}}{L}

R_{i,t} = \alpha_t + \sum_{k=1}^{K} \sum_{L \in \{1,2,4,8\}} \beta_{t,L}^{k} MA_{i,t-1,L}^{k} + \varepsilon_{i,t}

FIR_{i,t} = \sum_{k=1}^{K} \sum_{L \in \{1,2,4,8\}} E_t[\beta_{t+1,L}^{k}] MA_{i,t,L}^{k}

F_{i,t-j}

MA_{i,t,L}^{k}

R_{i,t}

\alpha_t

\beta_{t,L}^{k}

\varepsilon_{i,t}

参数说明：Fi：,t...  
DSL公式: MA_i,t,L**k = /F_i,t + F_i,t-1 + ... + F_i,t-L+1L
R_i,t = alpha_t + SUM_k=1**K SUM_L \in \1,2,4,8\ beta_t,L**k MA_i,t-1,L**k + \varepsilon_i,t
FIR_i,t = SUM_k=1**K SUM_L \in \1,2,4,8\ E_t[beta_t+1,L**k] MA_i,t,L**k
F_i,t-j
MA_i,t,L**k
R_i,t
alpha_t
beta_t,L**k
\varepsilon_i,t  
描述: 因子解释该因子 (FIR) 通过截面回归方法，结合了多个基本面因子的多季度移动平均值，并将其与未来的股票收益率进行关联分析。其核心思想在于：基本面趋势具有一定的持续性，并能对未来收益率产生预测作用。该因子综合考虑了基本面信息的绝对水平以及其随时间变化的趋势，旨在挖掘那些具有基本面持续改善的股票，并基于其风险溢价估计其预期收益率。预期收益率越高，意味着股票的投资价值越高。该因子融合了价值投资和趋势跟...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/fundamentals-implied-benefits
