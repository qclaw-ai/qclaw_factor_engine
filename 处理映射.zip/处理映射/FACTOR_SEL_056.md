# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_056  
因子名称: 下尾风险贝塔  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 动量, 成长, 价值, 量化交易, 下尾风险贝塔  
原始公式: R_j^t = \beta_j^{tail} R_m^t + \epsilon_j, \quad R_m^t < -VaR_m(\alpha)

\hat{\beta}_j^{tail} =  \frac{\tau_j(k/n)}{k} \frac{VaR_j(k/n)}{VaR_m(k/n)}

\tau_j(k/n) =  \sum_{t=1}^{n} \frac{I \{ R_t^{(j)} < -VaR_j(k/n) \; and \; R_t^{(m)} < -VaR_m(k/n) \}}{k}

R_j^t

R_m^t

\beta_j^{tail}

\epsilon_j

\alpha

VaR_j(k/n)

VaR_m(k/n)

参数说明：n：为计算期间的交易日天数。I{⋅}I\{\cdot\}I{⋅}:示性函数，当条件满足时为1，否则为0。τj(k/n)\tau_j(k/n)τj​(k/n):股票 j 和市场收益率同时小于其对应 VaR 值的联合超越概率，即在过去的 n 个交易日中，股票 j 和市场收益率同时跌破各自VaR值的交易日占比。因子解释下尾风险贝塔（Tail Beta）衡量了当市场发生极端下跌时，个股收益率对市场收益率的敏感程度，即在市场发生极端负收益时，该股票的收益率会如何变化。高下尾风险贝塔的股票意味着在市场发生极端下行风险时，其收益率的下跌幅度可能更大。该因子可以帮助投资者识别在市场极端波动时风险敞口较大的股票，从而进行风险管理和资产配置。与传统贝塔相比，下尾风险贝塔更关注市场极端情况下的风险暴露，可以作为传统风险指标的有效补充。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。朱剑涛. (2021). 收益率的非对称分布与尾部蕴含的Alpha. 东方证券Oordt, M. V., & Zhou, C.. (2016). Systematic tail risk. Ssrn Electronic JournalRelated Factors 系统性尾部风险暴露 系统性风险暴露 (Market Beta) 下行...  
DSL公式: R_j**t = beta_j**tail R_m**t + epsilon_j, \quad R_m**t < -VaR_m(alpha)
\hatbeta_j**tail = /tau_j(k/n)k /VaR_j(k/n)VaR_m(k/n)
tau_j(k/n) = SUM_t=1**n /I \ R_t**(j) < -VaR_j(k/n) \; and \; R_t**(m) < -VaR_m(k/n) \k
R_j**t
R_m**t
beta_j**tail
epsilon_j
alpha
VaR_j(k/n)
VaR_m(k/n)  
描述: 系统性尾部风险暴露 系统性风险暴露 (Market Beta) 下行风险贝塔 尾部非对称概率差 尾部风险厚度因子 尾盘成交量比率因子 Dimson调整贝塔 Frazzini-Pedersen 调整贝塔 异常尾部不对称度 Factors DirectoryQuantitative Trading Factors下尾风险贝塔技术因子因子公式基于下尾事件的条件CAPM模型：Rjt=βjtailRmt+ϵ...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/tail-beta
