# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_341  
因子名称: 季度税费意外变动率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 动量, 成长, 季度税费意外变动率, 价值, 量化交易  
原始公式: CurrentQuarterTaxExpense

PreviousYearSameQuarterTaxExpense

参数说明：分子为本季度所得税费用与上年同期所得税费用的差额，分母为上年同期所得税费用的绝对值。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors季度税费意外变动率基础面因子因子公式计算本季度税费意外变动率，其中分子为本季度所得税费用与上年同期所得税费用的差额，分母为上年同期所得税费用的绝对值。该公式通过计算本季度所得税费用与上年同期所得税费用的差额，并除以上年同期所得税费用的绝对值，来衡量税费支出相对于历史水平的意外变动程度。CurrentQuarterTaxExpenseCurrentQuarterTaxExpenseCurrentQuarterTaxExpense:本季度所得税费用PreviousYearSameQuarterTaxExpensePreviousYearSameQuarterTaxExpensePreviousYearSameQuarterTaxExpense:上年同期所得税费用因子解释该因子基于税收支出中可能蕴含的非预期信息。税收支出变动可能反映公司盈利能力的真实变化，而这些变化可能尚未完全反映在股价上。当本季度税费支出高于预期（与上年同期相比），可能预示公司盈利能力强劲；反之，则可能预示盈利能力疲软。理论上，税收支出变化与未来收益呈正相关关系，因为税费支出通常会滞后于盈利能力的实际变化。该因子可被视为对公司盈利质量的一种衡量，并可用于捕捉市场对公司盈利能力的预期偏差。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Thomas, Jacob, and Frank X. Zhang. (2011). Tax expense momentum. Journal of Accounting ResearchRelated Factors 单季度成本费用利润率同比增速 分析师预期EPS调整幅度 分析师一致预期EPS修正比率 60日盈利市值比率变动 标准化季度营收意外 有效所得税率 (Effective Tax Rate) 应计盈余比率（经标准化） 应计质量 标准化盈利超预期因子 因子解释该因子基于税收支出中可能蕴含的非预期信息。税收支出变动可能反映公司盈利能力的真实变化，而这些变化可能尚未完全反映在股价上。当本季度税费支出高于预期（与上年同期相比），可能预示公司盈利能力强劲；反之，则可能预示盈利能力疲软。理论上，税收支出变化与未来收益呈正相关关系，因为税费支出通常会滞后于盈利能力的实际变化。该因子可被视为对公司盈利质量的一种衡量，并可用于捕捉市场对公司盈利能力的预期偏差。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Thomas, Jacob, and Frank X. Zhang. (2011). Tax expense momentum. Journal of Accounting Research 季度税费意外变动率基础面因子因子公式计算本季度税费意外变动率，其中分子为本季度所得税费用与上年同期所得税费用的差额，分母为上年同期所得税费用的绝对值。该公式通过计算本季度所得税费用与上年同期所得税费用的差额，并除以上年同期所得税费用的绝对值，来衡量税费支出相对于历史水平的意外变动程度。CurrentQuarterTaxExpenseCurrentQuarterTaxExpenseCurrentQuarterTaxExpense:本季度所得税费用PreviousYearSameQuarterTaxExpensePreviousYearSameQuarterTaxExpensePreviousYearSameQuarterTaxExpense:上年同期所得税费用因子解释该因子基于税收支出中可能蕴含的非预期信息。税收支出变动可能反映公司盈利能力的真实变化，而这些变化可能尚未完全反映在股价上。当本季度税费支出高于预期（与上年同期相比），可能预示公司盈利能力强劲；反之，则可能预示盈利能力疲软。理论上，税收支出变化与未来收益呈正相关关系，因为税费支出通常会滞后于盈利能力的实际变化。该因子可被视为对公司盈利质量的一种衡量，并可用于捕捉市场对公司盈利能力的预期偏差。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验...  
DSL公式: CurrentQuarterTaxExpense
PreviousYearSameQuarterTaxExpense  
描述: 计算本季度税费意外变动率，其中分子为本季度所得税费用与上年同期所得税费用的差额，分母为上年同期所得税费用的绝对值。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors季度税费意外变动率基础...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/unexpected-tax-expense
