# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_133  
因子名称: 新闻共现注意力溢出因子  
分类: : 技术指标  
标签: : 流动性, 新闻共现注意力溢出因子, 技术指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: w_{ij,t} = \frac{N_{ij,t}}{N_{ii,t}}

Δw_{ij,t} = w_{ij,t} - w_{ij,t-1}

nco_{i,t} = \sum_{j=1, j\neq i}^{N} Δw_{ij,t}

N_{ij,t}

N_{ii,t}

w_{ij,t}

Δw_{ij,t}

nco_{i,t}

参数说明：Nij：,tN_{ij,t}Nij,t​:为t交易日内，股票i和股票j在同一新闻中共同出现的次数（共现新闻数量）Nii,tN_{ii,t}Nii,t​:为t交易日内，股票i在新闻中单独出现的次数wij,tw_{ij,t}wij,t​:为t交易日，股票i和股票j的相对共现新闻频率，表示股票j对于股票i的注意力溢出程度。使用股票i单独出现次数进行标准化，以消除股票i自身新闻报道量对共现次数的影响。Δwij,tΔw_{ij,t}Δwij,t​:为t交易日，股票i和股票j的相对共现新闻频率环比变动，表示股票j对股票i的注意力溢出程度的环比变化。ncoi,tnco_{i,t}ncoi,t​:为股票i在t交易日的净共现注意力溢出因子，表示所有其他股票j对股票i的注意力溢出程度变化的总和。该值越高，意味着投资者通过新闻报道对股票i的注意力溢出效应越强，潜在的过度关注风险越高。注意，此处对j求和时，j不等于i，避免计算股票i对自身的注意力溢出。因子解释该因子通过计算新闻中股票的共现频率及环比变化，捕捉投资者注意力在不同股票之间的转移。正值表示其他股票对目标股票的注意力溢出增加，可能预示着目标股票的关注度上升，但也可能伴随价格的过度反应风险。负值则表示注意力溢出减少，投资者对目标股票的关注度可能下降。该因子在行为金融学框架下，可用于研究市场情绪、投资者注意力以及股票收益的预测。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Li Guo, Lin Peng, Yubo Tao, Jun Tu. (2019). News Co-Occurrence, Attention Spillover and Return Predictability. Journal of Risk and Financial ManagementRelated Factors 行业共现变动因子 分析师共识覆盖加权动量 历史新闻提及量因子 隔夜新闻情感偏向因子 投资者关注度占比因子 新闻事件驱动动量因子 月度相对换手率溢出 市场收益率协偏度因子 相对新闻点击量因子 Factors DirectoryQuantitative Trading Factors新闻共现注意力溢出技术因子因子公式股票i和股票j在t交易日的相对共现新闻频率:wij,t=Nij,tNii,t w_{ij,t} = \frac{N_{ij,t}}{N_{ii,t}} wij,t​=Nii,t​Nij,t​​股票i和股票j在t交易日的相对共现新闻频率环比变动:Δwij,t=wij,t−wij,t−1 Δw_{ij,t} = w_{ij,t} - w_{ij,t-1} Δwij,t​=wij,t​−wij,t−1​股票i的净共现注意力溢出因子(NCO):ncoi,t=∑j=1,j≠iNΔwij,t nco_{i,t} = \sum_{j=1, j\neq i}^{N} Δw_{ij,t} ncoi,t​=j=1,j=i∑N​Δwij,t​其中：Nij,tN_{ij,t}Nij,t​:为t交易日内，股票i和股票j在同一新闻中共同出现的次数（共现新闻数量）Nii,tN_{ii,t}Nii,t​:为t交易日内，股票i在新闻中单独出现的次数wij,tw_{ij,t}wij,t​:为t交易日，股票i和股票j的相对共现新闻频率，表示股票j对于股票i的注意力溢出程度。使用股票i单独出现次数进行标准化，以消除股票i自身新闻报道量对共现次数的影响。Δwij,tΔw_{ij,t}Δwij,t​:为t交易日，股票i和股票j的相对共现新闻频率环比变动，表示股票j对股票i的注意力溢出程度的环比变化。ncoi,tnco_{i,t}ncoi,t​:为股票i在t交易日的净共现注意力溢出因子，表示所有其他股票j对股票i的注意力溢出程度变化的总和。该值越高，意味着投...  
DSL公式: w_ij,t = /N_ij,tN_ii,t
Δw_ij,t = w_ij,t - w_ij,t-1
nco_i,t = SUM_j=1, j!= i**N Δw_ij,t
N_ij,t
N_ii,t
w_ij,t
Δw_ij,t
nco_i,t  
描述: 新闻共现注意力溢出技术因子因子公式股票i和股票j在t交易日的相对共现新闻频率:wij,t=Nij,tNii,t w_{ij,t} = \frac{N_{ij,t}}{N_{ii,t}} wij,t​=Nii,t​Nij,t​​股票i和股票j在t交易日的相对共现新闻频率环比变动:Δwij,t=wij,t−wij,t−1 Δw_{ij,t} = w_{ij,t} - w_{ij,t-1} Δwij,t...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/news-co-occurrence
