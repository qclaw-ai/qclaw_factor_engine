# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_202  
因子名称: 存货周转率 (Inventory Turnover Ratio)  
分类: : 基本面指标  
标签: : inventory, 流动性, 存货周转率, ratio, 基本面指标, 质量, turnover, 动量  
原始公式: \frac{\text{Cost of Goods Sold (TTM)}}{\text{Average Inventory}}

\text{Average Inventory} = \frac{\text{Beginning Inventory} + \text{Ending Inventory}}{2}

Cost of Goods Sold (TTM)

Average Inventory

Beginning Inventory

Ending Inventory  
DSL公式: /\textCost of Goods Sold (TTM)\textAverage Inventory
\textAverage Inventory = /\textBeginning Inventory + \textEnding Inventory2
Cost of Goods Sold (TTM)
Average Inventory
Beginning Inventory
Ending Inventory  
描述: 报告期结束时（通常是期末）的存货金额。它反映了当前报告期末的库存水平，是计算平均存货的另一个重要组成部分。 因子公式存货周转率计算公式:Cost of Goods Sold (TTM)Average Inventory \frac{\text{Cost of Goods Sold (TTM)}}{\text{Average Inventory}} Average InventoryCost of ...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/inventory-turnover-ratio
