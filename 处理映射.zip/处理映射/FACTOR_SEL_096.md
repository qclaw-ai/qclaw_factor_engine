# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_096  
因子名称: 随机摆动指标  
分类: : 技术指标  
标签: : 流动性, 技术指标, 技术分析, 质量, 动量, 成长, 价值, 量化交易  
原始公式: RSV_t = 100 * \frac{CLOSE_t - MIN(LOW_{t-N+1:t})}{MAX(HIGH_{t-N+1:t}) - MIN(LOW_{t-N+1:t})}

K_t = SMA(RSV_t, M1, 1)

D_t = SMA(K_t, M2, 1)

J_t = 3 * K_t - 2 * D_t

SMA(X_t, N, M) = \frac{(X_t * M + SMA_{t-1} * (N-M))}{N}

CLOSE_t

LOW_{t-N+1:t}

HIGH_{t-N+1:t}

RSV_t

K_t  
DSL公式: RSV_t = 100 * /CLOSE_t - MIN(LOW_t-N+1:t)MAX(HIGH_t-N+1:t) - MIN(LOW_t-N+1:t)
K_t = SMA(RSV_t, M1, 1)
D_t = SMA(K_t, M2, 1)
J_t = 3 * K_t - 2 * D_t
SMA(X_t, N, M) = /(X_t * M + SMA_t-1 * (N-M))N
CLOSE_t
LOW_t-N+1:t
HIGH_t-N+1:t
RSV_t
K_t  
描述: 随机摆动指标 (Stochastic Oscillator)技术因子因子公式未成熟随机值 (RSV):RSVt=100∗CLOSEt−MIN(LOWt−N+1:t)MAX(HIGHt−N+1:t)−MIN(LOWt−N+1:t) RSV_t = 100 * \frac{CLOSE_t - MIN(LOW_{t-N+1:t})}{MAX(HIGH_{t-N+1:t}) - MIN(LOW_{t-N+...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/stochastic-indicator
