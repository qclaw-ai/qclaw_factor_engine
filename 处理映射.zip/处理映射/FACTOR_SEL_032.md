# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_032  
因子名称: 主力成交同步性因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 动量, 成长, 主力成交同步性因子, 价值, 量化交易  
原始公式: TS_{t} = RankCorr (A_{order,t}, A_{minute,t})

TS_{t}

A_{order,t}

A_{minute,t}

RankCorr()

参数说明：TStTS_：{t}TSt​:为t时刻的主力成交同步性，数值介于-1到1之间。Aorder,tA_{order,t}Aorder,t​:为某只股票在t时刻（如某一分钟）的单笔成交金额，该值为该分钟内所有成交单的平均成交金额。Aminute,tA_{minute,t}Aminute,t​:为某只股票在t时刻（如某一分钟）的总成交金额，即该分钟内所有成交单的金额总和。RankCorr()RankCorr()RankCorr():为计算秩相关系数的函数，这里使用Spearman秩相关系数。秩相关系数是衡量两个变量之间单调关系强度的非参数指标，它不依赖于数据的具体数值，而是关注数据的排序。这可以有效地消除异常值对相关性计算的影响。为了得到更稳定的信号，我们通常会对计算出的TS值进行平滑处理。这里使用20个交易日的移动平均值，计算出最终的主力成交同步性因子(MTS)，即： $MTS_t =  Mean(TS_{t-19}, TS_{t-18}, ..., TS_{t})$ 因子公式主力成交同步性 (TS) 的计算公式如下：TSt=RankCorr(Aorder,t,Aminute,t) TS_{t} = RankCorr (A_{order,t}, A_{minute,t}) TSt​=RankCorr(Aorder,t​,Aminute,t​)其中：TStTS_{t}TSt​:为t时刻的主力成交同步性，数值介于-1到1之间。Aorder,tA_{order,t}Aorder,t​:为某只股票在t时刻（如某一分钟）的单笔成交金额，该值为该分钟内所有成交单的平均成交金额。Aminute,tA_{minute,t}Aminute,t​:为某只股票在t时刻（如某一分钟）的总成交金额，即该分钟内所有成交单的金额总和。RankCorr()RankCorr()RankCorr():为计算秩相关系数的函数，这里使用Spearman秩相关系数。秩相关系数是衡量两个变量之间单调关系强度的非参数指标，它不依赖于数据的具体数值，而是关注数据的排序。这可以有效地消除异常值对相关性计算的影响。为了得到更稳定的信号，我们通常会对计算出的TS值进行平滑处理。这里使用20个交易日的移动平均值，计算出最终的主力成交同步性因子(MTS)，即： $MTS_t =  Mean(TS_{t-19}, TS_{t-18}, ..., TS_{t})$ ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors主力成交同步性技术因子因子公式主力成交同步性 (TS) 的计算公式如下：TSt=RankCorr(Aorder,t,Aminute,t) TS_{t} = RankCorr (A_{order,t}, A_{minute,t}) TSt​=RankCorr(Aorder,t​,Aminute,t​)其中：TStTS_{t}TSt​:为t时刻的主力成交同步性，数值介于-1到1之间。Aorder,tA_{order,t}Aorder,t​:为某只股票在t时刻（如某一分钟）的单笔成交金额，该值为该分钟内所有成交单的平均成交金额。Aminute,tA_{minute,t}Aminute,t​:为某只股票在t时刻（如某一分钟）的总成交金额，即该分钟内所有成交单的金额总和。RankCorr()RankCorr()RankCorr():为计算秩相关系数的函数，这里使用Spearman秩相关系数。秩相关系数是衡量两个变量之间单调关系强度的非参数指标，它不依赖于数据的具体数值，而是关注数据的排序。这可以有效地消除异常值对相关性计算的影响。为了得到更稳定的信号，我们通常会对计算出的TS值进行平滑处理。这里使用20个交易日的移动平均值，计算出最终的主力成交同步性因子(MTS)，即： $MTS_t =  Mean(TS_{t-19}, TS_{t-18}, ..., TS_{t})$因子解释该因子通过计算日内分钟级别单笔成交金额和总成交金额的秩相关系数，来衡量主力资金的交易行为对市场的影响力。高相关性表明主力资金可以通过大单交易显著影响市场，反之则意味着市场交易更多受到其他因素驱动。该因子可以帮助投资者识别主力资金的活跃程度和控盘能力，从而更好地把握市场节奏。通过观察MTS值的变化趋势，可以推断主力资金对某只股票的关注度或战略意图。该因子适用于短线交易和高频策略，并可作为其他量化策略的辅助...  
DSL公式: TS_t = RankCorr (A_order,t, A_minute,t)
TS_t
A_order,t
A_minute,t
RankCorr()  
描述: 其中：TStTS_{t}TSt​:为t时刻的主力成交同步性，数值介于-1到1之间。Aorder,tA_{order,t}Aorder,t​:为某只股票在t时刻（如某一分钟）的单笔成交金额，该值为该分钟内所有成交单的平均成交金额。Aminute,tA_{minute,t}Aminute,t​:为某只股票在t时刻（如某一分钟）的总成交金额，即该分钟内所有成交单的金额总和。RankCorr()RankC...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/main-force-trading-strength
