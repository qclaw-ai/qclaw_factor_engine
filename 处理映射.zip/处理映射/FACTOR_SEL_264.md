# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_264  
因子名称: 有效所得税率 (Effective Tax Rate)  
分类: : 基本面指标  
标签: : effective, 流动性, rate, 基本面指标, 有效所得税率, 质量, 动量, 成长  
原始公式: \frac{\text{所得税费用}_{\text{TTM}}}{\text{利润总额}_{\text{TTM}}}

\text{所得税费用}_{\text{TTM}}

\text{利润总额}_{\text{TTM}}  
DSL公式: /\text所得税费用_\textTTM\text利润总额_\textTTM
\text所得税费用_\textTTM
\text利润总额_\textTTM  
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors有效所得税率基础面因子因子公式有效所得税率计算公式:所得税费用TTM利润总额TTM \frac{\text{所得税费用}_{\text{T...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/income-tax-expense-rate
