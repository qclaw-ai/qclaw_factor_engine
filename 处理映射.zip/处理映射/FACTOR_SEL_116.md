# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_116  
因子名称: 蔡金资金流向指标  
分类: : 技术指标  
标签: : 流动性, 技术指标, 蔡金资金流向指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: MFM = \frac{(CLOSE-LOW)-(HIGH-CLOSE)}{(HIGH-LOW)}

MFVOL = MFM * VOL

CMF(N) = \frac{\sum_{i=1}^{N} MFVOL_i}{\sum_{i=1}^{N} VOL_i} * 100

CLOSE

LOW

HIGH

VOL

MFM

MFVOL  
DSL公式: MFM = /(close-low)-(high-close)(high-low)
MFVOL = MFM * VOL
CMF(N) = /SUM_i=1**N MFVOL_iSUM_i=1**N VOL_i * 100
close
low
high
VOL
MFM
MFVOL  
描述: 资金流量指标 蔡金资金流量震荡指标 资金流量累积指标 (Accumulation/Distribution Line, A/D) 钱德动量振荡器 成交量动量摆动指标 经营性现金流市值比 开盘时段大单净额占比 北向资金交易行为量化因子 陆股通净流入强度比率 因子公式计算每日的资金流量乘数（Money Flow Multiplier, MFM），又称每日资金流向强度系数，反映了当日收盘价在价格区间内的...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/caijin-currency-flow-indicator
