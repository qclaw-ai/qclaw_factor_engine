# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_356  
因子名称: 盈余公告日次日开盘跳空幅度  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 质量, 动量, 成长, 价值, 盈余公告日次日开盘跳空幅度, 量化交易  
原始公式: \frac{Open_{t+1}}{Close_t} - 1

Open_{t+1}

Close_t

参数说明：Opent：+1Open_{t+1}Opent+1​:表示盈余公告发布日（t日）的下一个交易日（t+1日）的开盘价格。ClosetClose_tCloset​:表示盈余公告发布日（t日）的收盘价格。因子解释盈余公告日次日开盘跳空幅度反映了市场对盈余公告的即时反应强度和方向。正向的跳空幅度（即因子值为正）通常表明盈余表现超出市场预期，导致投资者在次日开盘时积极买入，推高股价；负向的跳空幅度（即因子值为负）则表明盈余表现低于市场预期，投资者在次日开盘时抛售，导致股价下跌。该因子可用于衡量盈余公告对股票价格的冲击，并可作为事件驱动型量化策略的参考。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Zhou, H., & Zhu, J. Q.. (2012). Jump on the Post-Earnings Announcement Drift (corrected). Financial Analysts JournalRelated Factors 60日盈利市值比率变动 分析师目标价调整动量因子 分析师一致预期EPS修正比率 盈余公告超额收益率 标准化盈利超预期因子 标准化季度营收意外 开盘时段大单净额占比 20日区间收益率动量/反转因子 日内开盘净委买增额成交额比率 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 Related Factors 60日盈利市值比率变动 分析师目标价调整动量因子 分析师一致预期EPS修正比率 盈余公告超额收益率 标准化盈利超预期因子 标准化季度营收意外 开盘时段大单净额占比 20日区间收益率动量/反转因子 日内开盘净委买增额成交额比率 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors盈余公告日次日开盘跳空幅度情绪因子因子公式盈余公告日次日开盘跳空幅度:Opent+1Closet−1 \frac{Open_{t+1}}{Close_t} - 1 Closet​Opent+1​​−1其中：Opent+1Open_{t+1}Opent+1​:表示盈余公告发布日（t日）的下一个交易日（t+1日）的开盘价格。ClosetClose_tCloset​:表示盈余公告发布日（t日）的收盘价格。因子解释盈余公告日次日开盘跳空幅度反映了市场对盈余公告的即时反应强度和方向。正向的跳空幅度（即因子值为正）通常表明盈余表现超出市场预期，导致投资者在次日开盘时积极买入，推高股价；负向的跳空幅度（即因子值为负）则表明盈余表现低于市场预期，投资者在次日开盘时抛售，导致股价下跌。该因子可用于衡量盈余公告对股票价格的冲击，并可作为事件驱动型量化策略的参考。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Zhou, H., & Zhu, J. Q.. (2012). Jump on the Post-Earnings Announcement Drift (corrected). Financial Analysts JournalRelated Factors 60日盈利市值比率变动 分析师目标价调整动量因子 分析师一致预期EPS修正比率 盈余公告超额收益率 标准化盈利超预期因子 标准化季度营收意外 开盘时段大单净额占比 20日区间收益率动量/反转因子 日内开盘净委买增额成交额比率 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Zhou, H., & Zhu, J. Q.. (2012). Jump on the Post-Earnings Announcement Drift (corrected). Financial Analysts Journal ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子...  
DSL公式: /Open_t+1Close_t - 1
Open_t+1
Close_t  
描述: Factors DirectoryQuantitative Trading Factors盈余公告日次日开盘跳空幅度情绪因子因子公式盈余公告日次日开盘跳空幅度:Opent+1Closet−1 \frac{Open_{t+1}}{Close_t} - 1 Closet​Opent+1​​−1其中：Opent+1Open_{t+1}Opent+1​:表示盈余公告发布日（t日）的下一个交易日（t+1日）...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/earnings-announcement-stock-jump
