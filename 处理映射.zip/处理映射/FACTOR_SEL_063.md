# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_063  
因子名称: 负收益成交额加权非流动性因子  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 质量, 动量, 成长, 负收益成交额加权非流动性因子, 价值, 量化交易  
原始公式: ILLIQ_{i,t} = \frac{1}{N_{neg,t}} \sum_{k \in D_{neg,t}} \frac{|r_{i,t-k}|}{V_{i,t-k}}

r_{i,t-k}

V_{i,t-k}

D_{neg,t}

N_{neg,t}

参数说明：ri：,t−kr_{i,t-k}ri,t−k​:股票 i 在 t-k 日的收益率。当 $r_{i,t-k}$ 为负值时，该日被纳入计算；当 $r_{i,t-k}$ 为非负值时，该日不参与计算。Vi,t−kV_{i,t-k}Vi,t−k​:股票 i 在 t-k 日的成交额，以人民币或其他货币计价。 该值与收益率的绝对值相对应，仅当 $r_{i,t-k}$为负值时使用。Dneg,tD_{neg,t}Dneg,t​:在 t 月内，股票 i 的收益率为负的所有交易日集合。即所有 $r_{i,t-k} < 0$ 的交易日 k 的集合。Nneg,tN_{neg,t}Nneg,t​:在 t 月内，股票 i 的收益率为负的交易日总数，即集合 $D_{neg,t}$ 中元素的数量。因子解释该因子衡量股票在收益为负值时的非流动性。其核心逻辑是：在股票下跌时，成交额往往下降，流动性变差。该因子通过计算负收益日收益率的绝对值与成交额的比率，并按月取均值来衡量这种非流动性。一个较高的负收益成交额加权非流动性因子值，通常意味着该股票在下跌时流动性较差，投资者可能需要更高的风险溢价来补偿这种非流动性风险。此因子可以用于识别那些在市场下跌时更容易出现流动性危机的股票，有助于风险管理和投资组合构建。此外，该因子可以反映市场情绪，在恐慌性抛售期间，成交额往往下降，导致该因子的值增加。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Brennan, M., Huh, S. W., & Subrahmanyam, A.. (2013). An analysis of the Amihud illiquidity premium. Review of Asset Pricing Studies朱剑涛. (2017). 技术类新 Alpha 因子的批量测试. 东方证券Related Factors 流动性调整成交量零值天数比率 成交额波动率 日均负向成交额占比相对强度 尾盘成交量比率因子 平均月度成交额 Amihud非流动性冲击因子 Amihud 非流动性指标 条件流动性冲击因子 非流动性变异系数 Factors DirectoryQuantitative Trading Factors负收益成交额加权非流动性情绪因子因子公式负收益成交额加权非流动性因子 (ILLIQ_NegRet):ILLIQi,t=1Nneg,t∑k∈Dneg,t∣ri,t−k∣Vi,t−k ILLIQ_{i,t} = \frac{1}{N_{neg,t}} \sum_{k \in D_{neg,t}} \frac{|r_{i,t-k}|}{V_{i,t-k}} ILLIQi,t​=Nneg,t​1​k∈Dneg,t​∑​Vi,t−k​∣ri,t−k​∣​其中：ri,t−kr_{i,t-k}ri,t−k​:股票 i 在 t-k 日的收益率。当 $r_{i,t-k}$ 为负值时，该日被纳入计算；当 $r_{i,t-k}$ 为非负值时，该日不参与计算。Vi,t−kV_{i,t-k}Vi,t−k​:股票 i 在 t-k 日的成交额，以人民币或其他货币计价。 该值与收益率的绝对值相对应，仅当 $r_{i,t-k}$为负值时使用。Dneg,tD_{neg,t}Dneg,t​:在 t 月内，股票 i 的收益率为负的所有交易日集合。即所有 $r_{i,t-k} < 0$ 的交易日 k 的集合。Nneg,tN_{neg,t}Nneg,t​:在 t 月内，股票 i 的收益率为负的交易日总数，即集合 $D_{neg,t}$ 中元素的数量。因子解释该因子衡量股票在收益为负值时的非流动性。其核心逻辑是：在股票下跌时，成交额往往下降，流动性变差。该因子通过计算负收益日收益率的绝对值与成交额的比率，并按月取均值来衡量这种非流动性。一个较高的负收益成交额加权非流动性因子值，通常意味着该股票在下跌时流动性较差，投资者可能需要更高的风险溢价来补偿这种非流动性风险。此因子可以用于识别那些在市场下跌时更容易出现流动性危机的股票，有助于风险管理和投资组合构建。此外，该因子可以...  
DSL公式: ILLIQ_i,t = /1N_neg,t SUM_k \in D_neg,t /|r_i,t-k|V_i,t-k
r_i,t-k
V_i,t-k
D_neg,t
N_neg,t  
描述: 负收益成交额加权非流动性情绪因子因子公式负收益成交额加权非流动性因子 (ILLIQ_NegRet):ILLIQi,t=1Nneg,t∑k∈Dneg,t∣ri,t−k∣Vi,t−k ILLIQ_{i,t} = \frac{1}{N_{neg,t}} \sum_{k \in D_{neg,t}} \frac{|r_{i,t-k}|}{V_{i,t-k}} ILLIQi,t​=Nneg,t​1​k∈Dn...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/negative-return-illiquidity
