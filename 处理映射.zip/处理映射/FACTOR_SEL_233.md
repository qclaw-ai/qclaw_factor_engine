# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_233  
因子名称: 发行股本增长率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 波动率, 质量, 动量, 成长, 价值, 量化交易  
原始公式: issuance_t = \alpha + \beta t + \epsilon_t

IGRO = -\frac{\beta}{mean(issuance_{t\in T})}

issuance_t

\alpha

\beta

\epsilon_t

mean(issuance_{t\in T})

参数说明：issuancetissuance_tissuancet：​:为第 t 年的年度流通股本。ttt:时间变量，代表过去若干年。例如，当使用过去五年数据时，$t$ 的取值为 {1, 2, 3, 4, 5}。α\alphaα:线性回归模型的截距项，代表初始发行股本规模。β\betaβ:线性回归模型的时间趋势项系数，衡量发行股本随时间变化的斜率。正值代表发行股本规模增加的趋势，负值代表减少的趋势。ϵt\epsilon_tϵt​:线性回归模型的残差项，代表模型无法解释的发行股本的随机波动。TTT:表示用于计算回归和平均值的历史时间窗口。例如，当使用过去五年数据时，T = {1, 2, 3, 4, 5}mean(issuancet∈T)mean(issuance_{t\in T})mean(issuancet∈T​):为过去T时间窗口内年度流通股本的算术平均值。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors发行股本增长率基础面因子因子公式使用线性回归模型拟合过去一段时间的发行股本数据：issuancet=α+βt+ϵt issuance_t = \alpha + \beta t + \epsilon_t issuancet​=α+βt+ϵt​计算发行股本增长率：IGRO=−βmean(issuancet∈T) IGRO = -\frac{\beta}{mean(issuance_{t\in T})} IGRO=−mean(issuancet∈T​)β​其中：issuancetissuance_tissuancet​:为第 t 年的年度流通股本。ttt:时间变量，代表过去若干年。例如，当使用过去五年数据时，$t$ 的取值为 {1, 2, 3, 4, 5}。α\alphaα:线性回归模型的截距项，代表初始发行股本规模。β\betaβ:线性回归模型的时间趋势项系数，衡量发行股本随时间变化的斜率。正值代表发行股本规模增加的趋势，负值代表减少的趋势。ϵt\epsilon_tϵt​:线性回归模型的残差项，代表模型无法解释的发行股本的随机波动。TTT:表示用于计算回归和平均值的历史时间窗口。例如，当使用过去五年数据时，T = {1, 2, 3, 4, 5}mean(issuancet∈T)mean(issuance_{t\in T})mean(issuancet∈T​):为过去T时间窗口内年度流通股本的算术平均值。因子解释该因子通过线性回归模型捕捉发行股本的长期增长趋势。回归系数 β 衡量了股本随时间变化的斜率，代表了发行股本的增减速度。将其除以过去一段时间的平均发行股本规模，可以得到一个标准化后的增长率指标，便于不同公司之间的比较。取负号的目的是使增长率与公司扩张的程度正相关，即正增长率代表公司在积极进行发行融资，负增长率代表公司可能在减少流通股本。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。MSCI. (2018). Barra China A Total Market Equity Model for Long-Term In...  
DSL公式: issuance_t = alpha + beta t + epsilon_t
IGRO = -/betamean(issuance_t\in T)
issuance_t
alpha
beta
epsilon_t
mean(issuance_t\in T)  
描述: 计算发行股本增长率：IGRO=−βmean(issuancet∈T) IGRO = -\frac{\beta}{mean(issuance_{t\in T})} IGRO=−mean(issuancet∈T​)β​ 因子解释该因子通过线性回归模型捕捉发行股本的长期增长趋势。回归系数 β 衡量了股本随时间变化的斜率，代表了发行股本的增减速度。将其除以过去一段时间的平均发行股本规模，可以得到一个标准化...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/growth-rate-of-number-of-shares-issued
