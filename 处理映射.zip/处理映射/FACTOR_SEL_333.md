# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_333  
因子名称: 月度消费指数同比变动率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 月度消费指数同比变动率, 质量, 动量, 成长, 价值, 量化交易  
原始公式: SALESINDEX(i,t) = \frac{\sum_{\theta \in M_t} DailyTotalSales(i, \theta)}{\sum_{\theta \in M_t} DailyAdjustmentIndex(i, \theta)}

\Delta SALES(i, t) = \frac{SALESINDEX(i, t) - SALESINDEX(i,t - 12)}{SALESINDEX(i, t - 12)}

\text{DailyTotalSales}(i, \theta)

\text{DailyAdjustmentIndex}(i, \theta)

M_t

参数说明：DailyTotalSales：(i,θ)\text{DailyTotalSales}(i, \theta)DailyTotalSales(i,θ):为消费板块上市公司 i 在 t 月第 (\theta) 天的每日销售总额。DailyAdjustmentIndex(i,θ)\text{DailyAdjustmentIndex}(i, \theta)DailyAdjustmentIndex(i,θ):为消费板块上市公司 i 在 t 月第 (\theta) 天的消费者数量调整指数，用于消除因消费者数量变化导致的销售额波动，例如季节性变化，节假日效应等。该指数可以是每日的活跃消费者数量，或者其他能反映消费者数量变化的指标。MtM_tMt​:表示第t个月的所有交易日集合。iii:表示消费板块的上市公司。ttt:表示当前月份。 例如，若t=13，则表示第二年的1月份。因子解释该因子通过计算消费板块上市公司月度消费指数的年度同比变动率，反映了消费需求的增长或萎缩趋势。月度消费指数通过加总公司在月内每日的销售额，并使用消费者数量调整指数进行标准化。年度同比变动率则衡量了当月消费指数与去年同期的差异。此因子的理论基础是，消费支出是经济活动的重要组成部分，能够反映宏观经济和消费者信心的变化，同时，当期消费对未来企业的营收和盈利有直接的影响。实证研究表明，消费数据与公司未来三个季度的盈收具有显著的正相关关系。尤其在非必需消费品板块，该相关性在中小盘股票中更为明显。该因子与股票未来的收益呈正相关关系，表明消费的扩张通常预示着公司营收和盈利能力的提升，从而带动股票价格的上涨。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Gupta Tarun, Leung Edward, Roscovan Viorel. (2022). Consumer Spending and The Cross-Section of Stock Returns. Journal of Portfolio ManagementRelated Factors 单季度净利润同比增速 季度同比销售收入增长率 单季度经营活动净现金流同比增速 有形资本回报率环比增长率 (TTM) 散户同步性因子 发行股本增长率 TTM基本每股收益同比增长率 单季度成本费用利润率同比增速 行业共现变动因子 其中：DailyTotalSales(i,θ)\text{DailyTotalSales}(i, \theta)DailyTotalSales(i,θ):为消费板块上市公司 i 在 t 月第 (\theta) 天的每日销售总额。DailyAdjustmentIndex(i,θ)\text{DailyAdjustmentIndex}(i, \theta)DailyAdjustmentIndex(i,θ):为消费板块上市公司 i 在 t 月第 (\theta) 天的消费者数量调整指数，用于消除因消费者数量变化导致的销售额波动，例如季节性变化，节假日效应等。该指数可以是每日的活跃消费者数量，或者其他能反映消费者数量变化的指标。MtM_tMt​:表示第t个月的所有交易日集合。iii:表示消费板块的上市公司。ttt:表示当前月份。 例如，若t=13，则表示第二年的1月份。 单季度净利润同比增速 季度...  
DSL公式: SALESINDEX(i,t) = /SUM_\theta \in M_t DailyTotalSales(i, \theta)SUM_\theta \in M_t DailyAdjustmentIndex(i, \theta)
\Delta SALES(i, t) = /SALESINDEX(i, t) - SALESINDEX(i,t - 12)SALESINDEX(i, t - 12)
\textDailyTotalSales(i, \theta)
\textDailyAdjustmentIndex(i, \theta)
M_t  
描述: 月度消费指数同比变动基础面因子因子公式月度消费指数 (SALESINDEX)SALESINDEX(i,t)=∑θ∈MtDailyTotalSales(i,θ)∑θ∈MtDailyAdjustmentIndex(i,θ) SALESINDEX(i,t) = \frac{\sum_{\theta \in M_t} DailyTotalSales(i, \theta)}{\sum_{\theta \in...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/consumer-index-change
