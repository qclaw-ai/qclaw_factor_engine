# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_239  
因子名称: 非对称价格冲击偏度  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 动量, 成长, 规模, 价值, 量化交易  
原始公式: return_i = \gamma^{up} \cdot I_i \cdot MF_i + \gamma^{down} \cdot (1 - I_i) \cdot MF_i + \epsilon_i

MF_i = \frac{MoneyFlow_i}{Amount_i}

gammabias = \frac{\gamma^{up} - \gamma^{down}}{\sqrt{Var(\gamma^{up} - \gamma^{down})}}

return_i

MoneyFlow_i

Amount_i

MF_i

I_i

\gamma^{up}

\gamma^{down}

参数说明：returnireturn_ireturni：​:第i个5分钟K线时间段内的收益率，计算方式通常为 (收盘价 - 开盘价) / 开盘价，也可采用对数收益率MoneyFlowiMoneyFlow_iMoneyFlowi​:第i个5分钟K线时间段内的主动净买入金额，定义为主动买入成交额减去主动卖出成交额，需注意不同数据源对于主动买卖的划分可能有所差异AmountiAmount_iAmounti​:第i个5分钟K线时间段内的成交额，为该时间段内所有交易的成交金额总和MFiMF_iMFi​:第i个5分钟K线时间段内的主动净买入占比，衡量该时间段内主动买入的相对强度IiI_iIi​:示性函数（Indicator Function），当 $MoneyFlow_i$  > 0 时，取值为1；否则取值为0。它用于区分主动净买入和主动净卖出的时间段。γup\gamma^{up}γup:回归模型中，主动净买入时(即$I_i$为1)，主动净买入占比$MF_i$的回归系数，代表主动净买入对价格的冲击强度。γdown\gamma^{down}γdown:回归模型中，主动净卖出时(即$I_i$为0)，主动净买入占比$MF_i$的回归系数，代表主动净卖出对价格的冲击强度，由于此时Moneyflow < 0, 系数 $\gamma^{down}$ 可以理解为负向冲击强度ϵi\epsilon_iϵi​:回归模型的残差项，捕捉模型无法解释的价格波动部分。Var(γup−γdown)Var(\gamma^{up} - \gamma^{down})Var(γup−γdown):回归系数差 $(\gamma^{up} - \gamma^{down})$ 的方差，用来计算该差值的标准差，用于对 $(\gamma^{up} - \gamma^{down})$ 进行标准化因子解释非对称价格冲击偏度反映了股票在短期内对买卖盘冲击的敏感度差异。正向的偏度值意味着，在相同的交易量下，主动买入对价格的推动作用大于主动卖出，表明该股票更易于上涨，反之，负向偏度则暗示股票更易于下跌。该指标可以捕捉市场微观结构中的非对称性，可能反映了市场情绪、交易拥挤度或信息不对称等因素。偏度值绝对值越大，则冲击非对称性越强。需注意，该因子并非直接预测股价涨跌，而是揭示了股票价格对不同方向交易冲击的相对敏感程度。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。朱剑涛. (2016). 非对称价格冲击带来的超额收益. 东方证券Related Factors 日内收益偏度 滚动收益率偏度因子 残差偏度因子 系统偏度风险溢价因子 负收益偏度系数 异常尾部不对称度 市场收益率协偏度因子 尾部非对称概率差 条件流动性冲击因子 其中:returnireturn_ireturni​:第i个5分钟K线时间段内的收益率，计算方式通常为 (收盘价 - 开盘价) / 开盘价，也可采用对数收益率MoneyFlowiMoneyFlow_iMoneyFlowi​:第i个5分钟K线时间段内的主动净买入金额，定义为主动买入成交额减去主动卖出成交额，需注意不同数据源对于主动买卖的划分可能有所差异AmountiAmount_iAmounti​:第i个5分钟K线时间段内的成交额，为该时间段内所有交易的成交金额总和MFiMF_iMFi​:第i个5分钟K线时间段内的主动净买入占比，衡量该时间段内主动买入的相对强度IiI_iIi​:示性函数（Indicator Function），当 $MoneyFlo...  
DSL公式: return_i = gamma**up * I_i * MF_i + gamma**down * (1 - I_i) * MF_i + epsilon_i
MF_i = /MoneyFlow_iAmount_i
gammabias = /gamma**up - gamma**downSQRTVar(gamma**up - gamma**down)
return_i
MoneyFlow_i
Amount_i
MF_i
I_i
gamma**up
gamma**down  
描述: 非对称价格冲击偏度技术因子因子公式加权最小二乘回归模型：returni=γup⋅Ii⋅MFi+γdown⋅(1−Ii)⋅MFi+ϵi return_i = \gamma^{up} \cdot I_i \cdot MF_i + \gamma^{down} \cdot (1 - I_i) \cdot MF_i + \epsilon_i returni​=γup⋅Ii​⋅MFi​+γdown⋅(1−Ii...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/price-impact-bias
