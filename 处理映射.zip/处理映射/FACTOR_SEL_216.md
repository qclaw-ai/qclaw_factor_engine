# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_216  
因子名称: 固定资产占用权益比率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 动量, 成长, 价值, 固定资产占用权益比率, 量化交易  
原始公式: \frac{Total Assets - Total Current Assets}{Total Shareholders' Equity}

Total Assets

Total Current Assets

Total Shareholders' Equity  
DSL公式: /Total Assets - Total Current AssetsTotal Shareholders' Equity
Total Assets
Total Current Assets
Total Shareholders' Equity  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。（可添加作者名）. (（可添加年份）). 财务报表分析. （可添加出版社/期刊名） 因子公式固定资产占用权益比率 = (总资产 - 流动资产合计) / 股东权益合计TotalAssets−TotalCurrentAssetsTotalShareholders′Equity \frac{Total Assets - Total Curr...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/capital-fixation-ratio
