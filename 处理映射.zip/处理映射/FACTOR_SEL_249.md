# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_249  
因子名称: 北向资金交易行为量化因子  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 质量, 北向资金交易行为量化因子, 动量, 成长, 价值, 量化交易  
原始公式: AvgHoldValue = mean(持仓市值_{t-20:t})

FlowStability = \frac{mean(净流入_{t-20:t})}{std(净流入_{t-20:t})}

FlowToPricePeak = \frac{mean(净流入_{priceTop3})}{mean(持仓市值_{t-20:t})}

FlowToVolumePeak = \frac{mean(净流入_{volumeTop3})}{mean(|净流入|_{t-20:t})}

AvgHoldValue

FlowStability

FlowToPricePeak

FlowToVolumePeak

参数说明：AvgHoldValueAvgHoldValueAvgHoldValue：过去20个交易日北向资金日度持仓市值的平均值。该指标反映了北向资金对特定股票的整体配置规模。FlowStabilityFlowStabilityFlowStability:过去20个交易日北向资金日度净流入量的平均值，除以过去20个交易日北向资金日度净流入量的标准差。该指标衡量了北向资金流入的稳定性。正值越大，表明资金流入的持续性和稳定性越强。FlowToPricePeakFlowToPricePeakFlowToPricePeak:选取过去20个交易日中，股价最高的3个交易日，计算这3个交易日的北向资金日度净流入量的平均值，再除以过去20个交易日北向资金日度持仓市值的平均值。该指标衡量了北向资金在股价高位时是否加速流入，可以反映其对股票价值的判断和追涨意愿。FlowToVolumePeakFlowToVolumePeakFlowToVolumePeak:选取过去20个交易日中，交易量最高的3个交易日，计算这3个交易日的北向资金日度净流入量的平均值，再除以过去20个交易日北向资金日度净流入量绝对值的平均值。该指标衡量了北向资金在成交量放大时是否加速流入，可以反映其对股票流动性的偏好和对市场关注度的响应。因子解释本组因子旨在通过量化北向资金的交易行为来捕捉市场情绪和流动性特征。具体而言：  
DSL公式: AvgHoldValue = mean(持仓市值_t-20:t)
FlowStability = /mean(净流入_t-20:t)std(净流入_t-20:t)
FlowToPricePeak = /mean(净流入_priceTop3)mean(持仓市值_t-20:t)
FlowToVolumePeak = /mean(净流入_volumeTop3)mean(|净流入|_t-20:t)
AvgHoldValue
FlowStability
FlowToPricePeak
FlowToVolumePeak  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。朱剑涛,张惠澍. (2020). 从北上资金中提取的系列 alpha因子. 东方证券 FlowToVolumePeak (成交量放大时资金流入比率)：该指标衡量北向资金在成交量放大时的流入情况。如果成交量放大时北向资金依然加速流入，可能表明投资者对该股票的流动性偏好较高，并且对市场关注度的响应较强。这可能反映出市场对该股票的积极情绪。...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/northbound-trading-factors
