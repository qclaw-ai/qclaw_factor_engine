# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_095  
因子名称: 残差偏度因子  
分类: : 技术指标  
标签: : 残差偏度因子, 流动性, 技术指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: IdoSkew_i = \frac{\frac{1}{T}\sum_{t=1}^{T} \epsilon_{i,t}^{3}}{\left(\frac{1}{T}\sum_{t=1}^{T} \epsilon_{i,t}^{2}\right)^{\frac{3}{2}}}

r_{i,t} - r_{f,t} = \alpha_i + \beta_i (r_{m,t} - r_{f,t}) + \epsilon_{i,t}

r_{i,t} = \alpha_i + \beta_{1,i} MKT_t + \beta_{2,i} SMB_t + \beta_{3,i} HML_t + \epsilon_{i,t}

IdoSkew_i

r_{i,t}

r_{f,t}

\alpha_i

\beta_i

r_{m,t}

\epsilon_{i,t}

参数说明：IdoSkewiIdoSkew_iIdoSkewi：​:股票i在指定时间窗口内的残差偏度值。该值衡量了股票特质收益分布的偏斜程度。正值表示分布右偏，负值表示分布左偏。ri,tr_{i,t}ri,t​:股票i在t时刻的收益率，通常为简单收益率或对数收益率。计算收益率需要根据实际情况选择，并保持一致。rf,tr_{f,t}rf,t​:t时刻的无风险收益率，通常使用短期国债收益率作为代理变量。在实践中，也可能使用其他具有低风险特征的资产收益率。αi\alpha_iαi​:股票i的截距项（或称为阿尔法），表示在不考虑市场风险因素的情况下，股票i的预期收益率。在CAPM和三因子模型中，截距项代表了股票的超额收益，是衡量股票选股能力的重要指标。βi\beta_iβi​:在CAPM模型中，$\beta_i$ 表示股票i的市场风险暴露程度，衡量股票收益率对市场收益率变化的敏感度。 ( \beta ) 值大于1表示股票的波动性大于市场，小于1则表示波动性小于市场。在FF三因子模型中，$\beta_{1,i}$代表市场风险暴露程度， $\beta_{2,i}$代表规模风险暴露程度，$\beta_{3,i}$代表价值风险暴露程度。rm,tr_{m,t}rm,t​:t时刻的市场收益率，通常使用代表整个市场走势的指数收益率作为代理变量，如标普500指数或沪深300指数。ϵi,t\epsilon_{i,t}ϵi,t​:股票i在t时刻的残差项（或称为特质收益），代表模型无法解释的收益部分。残差项是计算残差偏度的基础。MKTtMKT_tMKTt​:t时刻的市场因子，代表市场整体的风险溢价，等于市场收益率减去无风险利率。SMBtSMB_tSMBt​:t时刻的规模因子，代表小市值公司股票相对于大市值公司股票的超额收益。HMLtHML_tHMLt​:t时刻的价值因子，代表高账面市值比公司股票相对于低账面市值比公司股票的超额收益。 残差偏度技术因子因子公式残差偏度计算公式:IdoSkewi=1T∑t=1Tϵi,t3(1T∑t=1Tϵi,t2)32 IdoSkew_i = \frac{\frac{1}{T}\sum_{t=1}^{T} \epsilon_{i,t}^{3}}{\left(\frac{1}{T}\sum_{t=1}^{T} \epsilon_{i,t}^{2}\right)^{\frac{3}{2}}} IdoSkewi​=(T1​∑t=1T​ϵi,t2​)23​T1​∑t=1T​ϵi,t3​​资本资产定价模型 (CAPM) 回归:ri,t−rf,t=αi+βi(rm,t−rf,t)+ϵi,t r_{i,t} - r_{f,t} = \alpha_i + \beta_i (r_{m,t} - r_{f,t}) + \epsilon_{i,t} ri,t​−rf,t​=αi​+βi​(rm,t​−rf,t​)+ϵi,t​Fama-French 三因子模型回归:ri,t=αi+β1,iMKTt+β2,iSMBt+β3,iHMLt+ϵi,t r_{i,t} = \alpha_i + \beta_{1,i} MKT_t + \beta_{2,i} SMB_t + \beta_{3,i} HML_t + \epsilon_{i,t} ri,t​=αi​+β1,i​MKTt​+β2,i​SMBt​+β3,i​HMLt​+ϵi,t​其中:IdoSkewiIdoSkew_iIdoSkewi​:股票i在指定时间窗口内的残差偏度值。该值衡量了股票特质收益分布的偏斜程度。正值表示分布右偏，负值表示分布左偏。ri,tr_{i,t}ri,t​:股票i在t时刻的收益率，通常为简单收益率或对数收益率。计算收益率需要根据实际情况选择，并保持一致。rf,tr_{f,t}rf,t​:t时刻的无风险收益率，通常使用短期国债收益率作为代理变量。在实践中，也可能使用其他具有低风险特征的资产收益率。αi\alpha_iαi​:股票i的截距项（或称为阿尔法），表示在不考虑市场风险因素的情况下，股票i的预期收益率。在CAPM和三因子模型中，截距项代表了股票的超额收益，是衡量股票选股能力的重要指标。βi\beta_iβi​:在CAPM模型中，$\beta_i$ 表示股票i的市场风险暴露程度，衡量股...  
DSL公式: IdoSkew_i = //1TSUM_t=1**T epsilon_i,t**3(/1TSUM_t=1**T epsilon_i,t**2)**/32
r_i,t - r_f,t = alpha_i + beta_i (r_m,t - r_f,t) + epsilon_i,t
r_i,t = alpha_i + beta_1,i MKT_t + beta_2,i SMB_t + beta_3,i HML_t + epsilon_i,t
IdoSkew_i
r_i,t
r_f,t
alpha_i
beta_i
r_m,t
epsilon_i,t  
描述: Fama-French 三因子模型回归:ri,t=αi+β1,iMKTt+β2,iSMBt+β3,iHMLt+ϵi,t r_{i,t} = \alpha_i + \beta_{1,i} MKT_t + \beta_{2,i} SMB_t + \beta_{3,i} HML_t + \epsilon_{i,t} ri,t​=αi​+β1,i​MKTt​+β2,i​SMBt​+β3,i​HMLt​+ϵ...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/idiosyncratic-skewness
