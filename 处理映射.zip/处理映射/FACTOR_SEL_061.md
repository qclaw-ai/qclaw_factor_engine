# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_061  
因子名称: 平均真实波幅 (Average True Range, ATR)  
分类: : 技术指标  
标签: : 流动性, range, 技术指标, atr, true, 质量, average, 动量  
原始公式: TR = \max(HIGH - LOW, |HIGH - CLOSE_{prev}|, |LOW - CLOSE_{prev}|)

ATR = EMA(TR, N)

N = 20

HIGH

LOW

CLOSE

CLOSE_{prev}

| |

max( )

EMA(TR, N)  
DSL公式: TR = MAX(high - low, |high - CLOSE_prev|, |low - CLOSE_prev|)
ATR = EMA(TR, N)
N = 20
high
low
close
CLOSE_prev
| |
max( )
EMA(TR, N)  
描述: 平均真实波幅 (Average True Range, ATR)技术因子因子公式真实波幅 (TR) =TR=max⁡(HIGH−LOW,∣HIGH−CLOSEprev∣,∣LOW−CLOSEprev∣) TR = \max(HIGH - LOW, |HIGH - CLOSE_{prev}|, |LOW - CLOSE_{prev}|) TR=max(HIGH−LOW,∣HIGH−CLOSEprev...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/average-true-volatility
