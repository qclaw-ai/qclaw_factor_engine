# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_272  
因子名称: 单季度销售成本率同比变动率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 动量, 成长, 价值, 量化交易, 单季度销售成本率同比变动率  
原始公式: \frac{CostRatio_{Q_{t}} - CostRatio_{Q_{t-4}}}{CostRatio_{Q_{t-4}}}

CostRatio_{Q_{t}}

CostRatio_{Q_{t-4}}  
DSL公式: /CostRatio_Q_t - CostRatio_Q_t-4CostRatio_Q_t-4
CostRatio_Q_t
CostRatio_Q_t-4  
描述: Factors DirectoryQuantitative Trading Factors单季度销售成本率同比变动率基础面因子因子公式单季度销售成本率同比变动率:CostRatioQt−CostRatioQt−4CostRatioQt−4 \frac{CostRatio_{Q_{t}} - CostRatio_{Q_{t-4}}}{CostRatio_{Q_{t-4}}} CostRatioQt−...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/single-quarter-cost-growth-rate
