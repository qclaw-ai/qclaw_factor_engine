# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_241  
因子名称: 布林买卖意愿比率  
分类: : 技术指标  
标签: : 流动性, 技术指标, 布林买卖意愿比率, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{\sum_{i=1}^{N} max(0, High_i - Close_{i-1})}{\sum_{i=1}^{N} max(0, Close_{i-1} - Low_i)}

HIGH

CLOSE[1]

LOW

参数说明：N：为回溯周期，默认为 20。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors布林买卖意愿比率 (Bullish/Bearish Ratio)技术因子因子公式BR(N) =  ∑(MAX(0, HIGH - CLOSE[1]), N) / ∑(MAX(0, CLOSE[1] - LOW), N)∑i=1Nmax(0,Highi−Closei−1)∑i=1Nmax(0,Closei−1−Lowi) \frac{\sum_{i=1}^{N} max(0, High_i - Close_{i-1})}{\sum_{i=1}^{N} max(0, Close_{i-1} - Low_i)} ∑i=1N​max(0,Closei−1​−Lowi​)∑i=1N​max(0,Highi​−Closei−1​)​BR 指标计算的是过去 N 个交易日内，多头力量总和与空头力量总和的比率。其中 N 为回溯周期，默认为 20。NNN:回溯周期，表示计算 BR 指标所使用的交易日数量。通常取值在 10 到 30 之间，默认值为 20。较短的周期对价格波动更敏感，较长的周期则更平滑。HIGHHIGHHIGH:当日最高价CLOSE[1]CLOSE[1]CLOSE[1]:前一日的收盘价LOWLOWLOW:当日最低价因子解释布林买卖意愿比率 (BR) 通过量化每日价格波动相对于前一日收盘价的范围，来评估市场中多头和空头的相对实力。具体来说：  
DSL公式: /SUM_i=1**N max(0, High_i - Close_i-1)SUM_i=1**N max(0, Close_i-1 - Low_i)
high
close[1]
low  
描述: BR 指标计算的是过去 N 个交易日内，多头力量总和与空头力量总和的比率。其中 N 为回溯周期，默认为 20。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors布林买卖意愿比率 (Bul...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/br-indicator
