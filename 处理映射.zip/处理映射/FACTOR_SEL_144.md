# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_144  
因子名称: Fama-French三因子模型残差动量  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, french, 动量, 成长, 规模, 价值  
原始公式: r_{i,t} = \alpha_{i} + \beta_{1,i}RMRF_{t} + \beta_{2,i}SMB_{t} + \beta_{3,i}HML_{t} + \epsilon_{i,t}

residualmom_{i,t} = \frac{\sum_{t=T-12}^{T-2} \epsilon_{i,t}}{\sqrt{\sum_{t=T-12}^{T-2}(\epsilon_{i,t} - \overline{\epsilon})^2}}

r_{i,t}

\alpha_{i}

\beta_{1,i}

\beta_{2,i}

\beta_{3,i}

\epsilon_{i,t}

\overline{\epsilon}

参数说明：ri：,tr_{i,t}ri,t​:资产i在t时刻的收益率。代表特定时间段内，资产i的价格变化幅度。αi\alpha_{i}αi​:资产i的截距项，表示在市场风险、规模和价值因子均为0时，资产i的预期收益率。该项反映了资产i的基准收益水平，也是一个衡量选股能力的重要指标。β1,i\beta_{1,i}β1,i​:资产i对市场风险溢价RMRF的敏感度（或称斜率系数）。表示市场风险溢价变动一个单位时，资产i收益率的预期变动幅度。也称为市场Beta，衡量了资产i的系统性风险暴露。β2,i\beta_{2,i}β2,i​:资产i对规模溢价SMB的敏感度。表示规模溢价变动一个单位时，资产i收益率的预期变动幅度。该值衡量了资产i受规模因子影响的程度。β3,i\beta_{3,i}β3,i​:资产i对价值溢价HML的敏感度。表示价值溢价变动一个单位时，资产i收益率的预期变动幅度。该值衡量了资产i受价值因子影响的程度。ϵi,t\epsilon_{i,t}ϵi,t​:资产i在t时刻的残差，即实际收益率与由Fama-French三因子模型预测的收益率之间的差异。该残差项代表了在市场、规模和价值因子影响之外，由公司特有信息驱动的收益部分，是残差动量因子的核心组成部分。ϵ‾\overline{\epsilon}ϵ:在计算动量窗口期（T-12至T-2）内，资产i残差的平均值。用于计算残差的标准差，从而实现残差动量的标准化。因子解释该因子基于行为金融学中的渐进信息扩散假说。该假说认为，市场信息，特别是公司特有信息，在投资者之间传播需要时间，并非瞬间完成。这导致投资者对这些信息的反应存在滞后性。通过Fama-French三因子模型剥离市场风险、规模和价值因素的影响，残差序列可以更纯粹地反映公司特有信息的价值效应。因此，如果过去一段时间残差表现较好，说明投资者可能尚未充分反应相关信息，在未来一段时间内，该股票仍然有持续上涨的可能性，反之亦然。此因子捕捉到的即是由公司特有信息驱动的，且未被市场充分定价的动量效应。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Blitz, David, Joop, Huij, and Martin Martens. (2011). Residual Momentum. Journal of Empirical FinanceBlitz, D., M. X. Hanauer, and M. Vidojevic. (2020). The idiosyncratic momentum anomaly. International Review of Economics & FinanceRelated Factors CAPM残差动量因子 残差偏度因子 特异性收益波动因子 残差市值偏...  
DSL公式: r_i,t = alpha_i + beta_1,iRMRF_t + beta_2,iSMB_t + beta_3,iHML_t + epsilon_i,t
residualmom_i,t = /SUM_t=T-12**T-2 epsilon_i,tSQRTSUM_t=T-12**T-2(epsilon_i,t - \overlineepsilon)**2
r_i,t
alpha_i
beta_1,i
beta_2,i
beta_3,i
epsilon_i,t
\overlineepsilon  
描述: 资产i对规模溢价SMB的敏感度。表示规模溢价变动一个单位时，资产i收益率的预期变动幅度。该值衡量了资产i受规模因子影响的程度。 资产i在t时刻的残差，即实际收益率与由Fama-French三因子模型预测的收益率之间的差异。该残差项代表了在市场、规模和价值因子影响之外，由公司特有信息驱动的收益部分，是残差动量因子的核心组成部分。 资产i对市场风险溢价RMRF的敏感度（或称斜率系数）。表示市场风险溢价...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/residual-momentum-ff3
