# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_355  
因子名称: 盈余公告超额收益率  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 质量, 动量, 成长, 盈余公告超额收益率, 价值, 量化交易  
原始公式: R_{stock,event} - R_{benchmark,event}

R_{stock,event}

R_{benchmark,event}

参数说明：Rstock：,eventR_{stock,event}Rstock,event​:个股在盈余公告事件窗口期内的累计收益率。事件窗口通常包括公告日当天及其前后若干交易日，例如3天（公告日-1，公告日，公告日+1）或5天（公告日-2，公告日-1，公告日，公告日+1，公告日+2）。收益率的计算可以采用简单收益率或对数收益率。Rbenchmark,eventR_{benchmark,event}Rbenchmark,event​:基准指数在盈余公告事件窗口期内的累计收益率。基准指数的选择通常采用与个股所在市场、行业或风格相匹配的指数，例如沪深300指数、中证500指数、行业指数等。收益率的计算方法应与个股一致。因子解释盈余公告超额收益率表示个股在盈余公告事件窗口期内的实际累计收益率与基准指数同期累计收益率的差值。正值表示个股收益率高于基准收益率，可能存在PEAD效应；负值则表示个股收益率低于基准收益率，可能存在信息负面冲击。该因子反映了市场对盈余公告的超预期反应，可以用于捕捉短期内的投资机会。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Brandt, M. W., Kishore, R., Santa-Clara, P., & Venkatachalam, M.. (2008). Earnings announcements are full of surprises. SSRN eLibraryRelated Factors 标准化季度营收意外 盈余公告日次日开盘跳空幅度 标准化盈利超预期因子 预期市盈率调整幅度 分析师预期EPS调整幅度 分析师一致预期EPS修正比率 标准化意外盈余 月度收益季节性动量因子 月度超额收益季节性反转因子 盈余公告超额收益率表示个股在盈余公告事件窗口期内的实际累计收益率与基准指数同期累计收益率的差值。正值表示个股收益率高于基准收益率，可能存在PEAD效应；负值则表示个股收益率低于基准收益率，可能存在信息负面冲击。该因子反映了市场对盈余公告的超预期反应，可以用于捕捉短期内的投资机会。 因子公式盈余公告超额收益率 =Rstock,event−Rbenchmark,event R_{stock,event} - R_{benchmark,event} Rstock,event​−Rbenchmark,event​其中：Rstock,eventR_{stock,event}Rstock,event​:个股在盈余公告事件窗口期内的累计收益率。事件窗口通常包括公告日当天及其前后若干交易日，例如3天（公告日-1，公告日，公告日+1）或5天（公告日-2，公告日-1，公告日，公告日+1，公告日+2）。收益率的计算可以采用简单收益率或对数收益率。Rbenchmark,eventR_{benchmark,event}Rbenchmark,event​:基准指数在盈余公告事件窗口期内的累计收益率。基准指数的选择通常采用与个股所在市场、行业或风格相匹配的指数，例如沪深300指数、中证500指数、行业指数等。收益率的计算方法应与个股一致。 其中：Rstock,eventR_{stock,event}Rstock,event​:个股在盈余公告事件窗口期内的累计收益率。事件窗口通常包括公告日当天及其前后若干交易日，例如3天（公告日-1，公告日，公告日+1）或5天（公告日-2，公告日-1，公告日，公告日+1，公告日+2）。收益率的计算可以采用简单收益率或对数收益率。Rbenchmark,eventR_{benchmark,event}Rbenchmark,event​:基准指数在盈余公告事件窗口期内的累计收益率。基准指数的选择通常采用与个股所在市场、行业或风格相匹配的指数，例如沪深300指数、中证500指数、行业指数等。收益率的计算方法应与个股一致。 标准化季度营收意外 盈余公告日次日开盘跳空幅度 标准化盈利超预期因子 预期市盈率调整幅度 分析师预期EPS调整幅度 分析师一致预期EPS修正比率 标准化意外盈余 月度收益季节性动量因子 月度超额收益季节性反转因子 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 盈...  
DSL公式: R_stock,event - R_benchmark,event
R_stock,event
R_benchmark,event  
描述: Factors DirectoryQuantitative Trading Factors盈余公告超额收益率情绪因子因子公式盈余公告超额收益率 =Rstock,event−Rbenchmark,event R_{stock,event} - R_{benchmark,event} Rstock,event​−Rbenchmark,event​其中：Rstock,eventR_{stock,even...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/earnings-announcement-return
