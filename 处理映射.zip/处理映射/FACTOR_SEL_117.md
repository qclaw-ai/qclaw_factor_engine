# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_117  
因子名称: 佳庆波动率离散指标  
分类: : 技术指标  
标签: : 流动性, 佳庆波动率离散指标, 技术指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: REM = EMA(HIGH-LOW,N)

CV = 100*(REM - REM_{M})/REM_{M}

N = 10, M = 10

REM

HIGH

LOW

REM_{M}  
DSL公式: REM = EMA(high-low,N)
CV = 100*(REM - REM_M)/REM_M
N = 10, M = 10
REM
high
low
REM_M  
描述: 波动率离散度，表示当前平滑波动幅度 (REM) 相较于 M 个周期前的平滑波动幅度的变化百分比。该值反映了当前波动率相对于过去一段时间的波动率的变化，是本指标的核心。正值表示波动率上升，负值表示波动率下降。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 Related Factors 相对波动性指标 成交量相对强度指标 随机摆动指标 蔡...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/jiaqing-discrete-index
