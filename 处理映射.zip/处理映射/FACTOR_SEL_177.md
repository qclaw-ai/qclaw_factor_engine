# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_177  
因子名称: 市盈率相对盈利增长率  
分类: : 成长性指标  
标签: : 流动性, 市盈率相对盈利增长率, 成长性指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: P/E_{TTM}

Growth_{NetProfit, TTM}

P/E_{TTM}

Growth_{NetProfit, TTM}  
DSL公式: P/E_TTM
Growth_NetProfit, TTM
P/E_TTM
Growth_NetProfit, TTM  
描述: Factors DirectoryQuantitative Trading Factors市盈率相对盈利增长率成长因子因子公式市盈率(TTM)P/ETTM P/E_{TTM} P/ETTM​市盈率（Trailing Twelve Months, TTM）是指股票的当前价格与过去12个月每股收益的比率。它是衡量股票估值水平的常用指标，反映了投资者愿意为每一单位的盈利支付多少价格。TTM市盈率使用过去...
因子类型: : 成长性指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/growth/p-e-growth
