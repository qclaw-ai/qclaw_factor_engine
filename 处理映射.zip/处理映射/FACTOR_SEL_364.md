# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_364  
因子名称: 创新研发强度及产出综合因子  
分类: : 成长性指标  
标签: : 流动性, 成长性指标, 质量, 动量, 成长, 创新研发强度及产出综合因子, 价值, 量化交易  
原始公式:   
DSL公式:   
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors创新研发强度及产出综合因子成长因子因子公式近12个月研发费用(TTM)公司最近12个月的研发费用总额。反映企业在研发活动中的资源投入力度。...
因子类型: : 成长性指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/growth/innovation-capacity-factor
