# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_015  
因子名称: 每股留存收益  
分类: : 价值指标  
标签: : 流动性, 波动率, 质量, 动量, 成长, 价值, 量化交易, 价值指标  
原始公式: REPS = \frac{Retained Earnings_{t}}{Shares Outstanding_{t}}

REPS

Retained Earnings_{t}

Shares Outstanding_{t}

参数说明：REPSREPSREPS：表示每股留存收益（Retained Earnings Per Share）。RetainedEarningstRetained Earnings_{t}RetainedEarningst​:表示最近报告期（t期）的留存收益。留存收益指的是公司从净利润中提取的、尚未分配给股东的部分，通常用于支持公司未来的发展和运营。该数值来自于资产负债表的留存收益科目，是衡量公司内部积累盈利能力的重要指标。SharesOutstandingtShares Outstanding_{t}SharesOutstandingt​:表示最近报告期（t期）的普通股总股本。总股本是指公司发行的并由股东持有的全部普通股股份的数量，它是计算每股指标的基础。该数值通常来源于公司的财务报告或公告。因子解释每股留存收益越高，意味着公司每股股票对应的累计未分配利润越高，可能代表公司有较强的内部融资能力和未来发展潜力。从价值投资角度来看，高每股留存收益可能预示着公司未来更高的分红或股票价值增长。然而，高留存收益也可能意味着公司缺乏投资机会或股东分红意愿较低，因此需要结合公司的具体情况和行业特点进行综合分析。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。财务报表分析公司财务管理Related Factors 每股留存收益 每股留存收益(Retained Earnings per Share, REPS) 每股未分配利润 (Retained Earnings Per Share) 每股盈余公积金 每股货币资金 分析师一致预期市盈率倒数 每股资本公积金 股东盈余市值比率 分析师一致预期EPS修正比率 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors每股留存收益价值因子因子公式每股留存收益:REPS=RetainedEarningstSharesOutstandingt REPS = \frac{Retained Earnings_{t}}{Shares Outstanding_{t}} REPS=SharesOutstandingt​RetainedEarningst​​其中:REPSREPSREPS:表示每股留存收益（Retained Earnings Per Share）。RetainedEarningstRetained Earnings_{t}RetainedEarningst​:表示最近报告期（t期）的留存收益。留存收益指的是公司从净利润中提取的、尚未分配给股东的部分，通常用于支持公司未来的发展和运营。该数值来自于资产负债表的留存收益科目，是衡量公司内部积累盈利能力的重要指标。SharesOutstandingtShares Outstanding_{t}SharesOutstandingt​:表示最近报告期（t期）的普通股总股本。总股本是指公司发行的并由股东持有的全部普通股股份的数量，它是计算每股指标的基础。该数值通常来源于公司的财务报告或公告。因子解释每股留存收益越高，意味着公司每股股票对应的累计未分配利润越高，可能代表公司有较强的内部融资能力和未来发展潜力。从价值投资角度来看，高每股留存收益可能预示着公司未来更高的分红或股票价值增长。然而，高留存收益也可能意味着公司缺乏投资机会或股东分红意愿较低，因此需要结合公司的具体情况和行业特点进行综合分析。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。财务报表分析公司财务管理Related Factors 每股留存收益 每股留存收益(Retained Earnings per Share, REPS) 每股未分配利润 (Retained Earnings Per Share) 每股盈余公积金 每股货币资金 分析师一致预期市盈率倒数 每股资本公积金 股东盈余市值比率 分析师一致预期EPS修正比率 ⚠️ 因子风险警告...  
DSL公式: REPS = /Retained Earnings_tShares Outstanding_t
REPS
Retained Earnings_t
Shares Outstanding_t  
描述: 每股留存收益价值因子因子公式每股留存收益:REPS=RetainedEarningstSharesOutstandingt REPS = \frac{Retained Earnings_{t}}{Shares Outstanding_{t}} REPS=SharesOutstandingt​RetainedEarningst​​其中:REPSREPSREPS:表示每股留存收益（Retained E...
因子类型: : 价值指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/value/value-retained-earnings-per-share
