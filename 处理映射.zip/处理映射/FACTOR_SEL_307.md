# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_307  
因子名称: 机构持仓家数  
分类: : 情绪指标  
标签: : 流动性, 机构持仓家数, 情绪指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式:   
DSL公式:   
描述: ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。胡骥聪, 刘均伟. (2020). 股东大类因子：拆解股东数据中的多元信息. 光大证券张三, 李四. (2022). 机构投资者行为研究. 金融研究 Factors DirectoryQuantitative Trading F...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/number-of-position-holding-agencies
