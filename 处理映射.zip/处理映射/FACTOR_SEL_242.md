# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_242  
因子名称: 投资者关注度占比因子  
分类: : 情绪指标  
标签: : 流动性, 投资者关注度占比因子, 情绪指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: N(i)

∑N(j)  
DSL公式: N(i)
∑N(j)  
描述: Factors DirectoryQuantitative Trading Factors投资者关注度占比情绪因子因子公式该因子计算公式较为简单，本质上是对自选股池进行统计，其隐含的公式可以理解为：iii:代表特定的目标股票。N(i)N(i)N(i):在所有投资者自选股池中，股票 i 被选中的总次数（或投资者人数）。jjj:代表所有被选入自选股池的股票，包括目标股票 i。∑N(j)∑N(j)∑N(...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/custom-stock-ratio
