# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_115  
因子名称: 随机动量指标 (SMI)  
分类: : 技术指标  
标签: : 随机动量指标, 流动性, 技术指标, 质量, 动量, 成长, smi, 价值  
原始公式: C(N) = \frac{MAX(HIGH,N)+MIN(LOW,N)}{2}

H = CLOSE - C(N)

SH1 = EMA(H,N1)

SH2 = EMA(SH1,N2)

R = MAX(HIGH,N) - MIN(LOW,N)

SR1 = EMA(R,N1)

SR2 = \frac{EMA(SR1,N2)}{2}

SMI = \frac{SH2}{SR2} * 100  
DSL公式: C(N) = /MAX(high,N)+MIN(low,N)2
H = close - C(N)
SH1 = EMA(H,N1)
SH2 = EMA(SH1,N2)
R = MAX(high,N) - MIN(low,N)
SR1 = EMA(R,N1)
SR2 = /EMA(SR1,N2)2
SMI = /SH2SR2 * 100  
描述: 短期平滑周期，用于计算 SH1 和 SR1，通常设置为 3，可以根据需求调整，值越小，对价格变动越敏感。 Factors DirectoryQuantitative Trading Factors随机动量指标 (Stochastic Momentum Indicator)技术因子因子公式中心价格 (C)C(N)=MAX(HIGH,N)+MIN(LOW,N)2 C(N) = \frac{MAX(HI...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/stochastic-momentum-indicator
