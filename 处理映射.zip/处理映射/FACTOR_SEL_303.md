# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_303  
因子名称: 修正琼斯模型操纵性应计盈余  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 动量, 成长, 修正琼斯模型操纵性应计盈余, 量化交易, 价值  
原始公式: \frac{TA_{i,t}}{A_{i,t-1}} = \alpha_{i,1} \frac{1}{A_{i,t-1}} + \alpha_{i,2} \frac{\Delta REV_{i,t}}{A_{i,t-1}} + \alpha_{i,3} \frac{PPE_{i,t}}{A_{i,t-1}} + \varepsilon_{i,t}

NDTAC_{i,t} = \alpha_{i,1} \frac{1}{A_{i,t-1}} + \alpha_{i,2} \frac{\Delta REV_{i,t} - \Delta REC_{i,t}}{A_{i,t-1}} + \alpha_{i,3} \frac{PPE_{i,t}}{A_{i,t-1}}

DTAC_{i,t} = \frac{TA_{i,t}}{A_{i,t-1}} - NDTAC_{i,t}

TA_{i,t}

A_{i,t-1}

\Delta REV_{i,t}

\Delta REC_{i,t}

PPE_{i,t}

\alpha_{i,1}

\alpha_{i,2}

参数说明：TAi：,tTA_{i,t}TAi,t​:股票i在t期的总应计盈余（Total Accruals），计算方式为当期净利润减去当期经营活动现金流。该指标反映了非现金交易对公司盈利的影响，是盈余质量分析的重要组成部分。Ai,t−1A_{i,t-1}Ai,t−1​:股票i在t-1期的总资产（Total Assets），作为标准化因子，用于消除公司规模差异对回归结果的影响，使得不同规模公司的数据具有可比性。ΔREVi,t\Delta REV_{i,t}ΔREVi,t​:股票i在t期相对t-1期的营业收入增加额（Change in Revenue）。收入变动是公司经营业绩的重要体现，也是应计盈余的驱动因素之一。ΔRECi,t\Delta REC_{i,t}ΔRECi,t​:股票i在t期相对t-1期的应收账款增加额（Change in Receivables）。应收账款变动可以反映企业收入质量，以及是否存在激进的收入确认行为。从收入增长中扣除应收账款的增长可以更好地估计非操纵性应计盈余PPEi,tPPE_{i,t}PPEi,t​:股票i在t期的期末固定资产总额（Gross Property, Plant, and Equipment）。固定资产代表了公司的投资和生产能力，也是应计盈余的重要组成部分。αi,1\alpha_{i,1}αi,1​:回归模型中的截距项系数，代表了在其他因素不变的情况下，由公司固有特征决定的应计盈余的基准水...  
DSL公式: /TA_i,tA_i,t-1 = alpha_i,1 /1A_i,t-1 + alpha_i,2 /\Delta REV_i,tA_i,t-1 + alpha_i,3 /PPE_i,tA_i,t-1 + \varepsilon_i,t
NDTAC_i,t = alpha_i,1 /1A_i,t-1 + alpha_i,2 /\Delta REV_i,t - \Delta REC_i,tA_i,t-1 + alpha_i,3 /PPE_i,tA_i,t-1
DTAC_i,t = /TA_i,tA_i,t-1 - NDTAC_i,t
TA_i,t
A_i,t-1
\Delta REV_i,t
\Delta REC_i,t
PPE_i,t
alpha_i,1
alpha_i,2  
描述: 因子解释本因子采用修正的琼斯模型，通过分行业分年度的横截面回归，将总应计盈余分解为非操纵性部分和操纵性部分。修正琼斯模型在原始琼斯模型的基础上，考虑了应收账款变化的影响，使其能更好地识别盈余管理行为。操纵性应计盈余反映了公司管理层出于特定动机（如满足盈利目标、避税等）而进行的盈余调整，是衡量盈余质量和会计稳健性的重要指标。该指标与股票未来收益通常呈现负相关关系，即操纵性应计盈余越高的公司，其未来收...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/accruals
