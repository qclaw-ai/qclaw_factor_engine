# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_367  
因子名称: 五年滚动平均独立权利要求项数  
分类: : 基本面指标  
标签: : 五年滚动平均独立权利要求项数, 流动性, 基本面指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式:   
DSL公式:   
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。郑兆磊. (2022). 专利研究系列四:专利全解析. 兴业证券 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 Factors DirectoryQuantitative Trading Factors五年滚动平均独立权利要求项数基础面因子因子公式因子解释独立权利要求项是指...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/independent-claim-count
