# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_268  
因子名称: 投入资本回报率环比变动  
分类: : 质量指标  
标签: : 流动性, 质量指标, 质量, 动量, 成长, 价值, 量化交易, 投入资本回报率环比变动  
原始公式: ROIC_{Q(t)} - ROIC_{Q(t-4)}

ROIC_Q(t)

ROIC_Q(t-4)

参数说明：t：代表最近报告期。ROICQ(t−4)ROIC_Q(t-4)ROICQ​(t−4):t-4 时刻的单季度投入资本回报率（Return on Invested Capital），其中 t-4 代表上年同期报告期（假设每季度报告一次）。 Factors DirectoryQuantitative Trading Factors投入资本回报率环比变动 (Quarter-over-Quarter Change in ROIC)质量因子因子公式ROIC_Q(t) - ROIC_Q(t-4)ROICQ(t)−ROICQ(t−4) ROIC_{Q(t)} - ROIC_{Q(t-4)} ROICQ(t)​−ROICQ(t−4)​该公式计算最近报告期单季度投入资本回报率与上年同期单季度投入资本回报率之差。ROICQ(t)ROIC_Q(t)ROICQ​(t):t 时刻的单季度投入资本回报率（Return on Invested Capital），其中 t 代表最近报告期。ROICQ(t−4)ROIC_Q(t-4)ROICQ​(t−4):t-4 时刻的单季度投入资本回报率（Return on Invested Capital），其中 t-4 代表上年同期报告期（假设每季度报告一次）。因子解释该因子属于质量成长类因子，旨在捕捉公司投入资本回报效率的短期变化趋势。  
DSL公式: ROIC_Q(t) - ROIC_Q(t-4)
ROIC_Q(t)
ROIC_Q(t-4)  
描述: 该公式计算最近报告期单季度投入资本回报率与上年同期单季度投入资本回报率之差。ROICQ(t)ROIC_Q(t)ROICQ​(t):t 时刻的单季度投入资本回报率（Return on Invested Capital），其中 t 代表最近报告期。ROICQ(t−4)ROIC_Q(t-4)ROICQ​(t−4):t-4 时刻的单季度投入资本回报率（Return on Invested Capital）...
因子类型: : 质量指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/quality/quality-return-on-invested-capital
