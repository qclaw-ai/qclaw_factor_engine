# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_330  
因子名称: 机构投资者持股比例  
分类: : 情绪指标  
标签: : 流动性, 机构投资者持股比例, 情绪指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{\text{机构投资者持股数量}}{\text{总股本}}

机构投资者持股数量

总股本  
DSL公式: /\text机构投资者持股数量\text总股本
机构投资者持股数量
总股本  
描述: 指报告期末，公司已发行的全部股份总数。总股本通常由公司定期报告或交易所公开信息披露。需要注意的是，总股本包括流通股和限售股，但在计算机构持股比例时，使用的是已发行的全部股份数量。 Factors DirectoryQuantitative Trading Factors机构投资者持股比例情绪因子因子公式机构投资者持股比例:机构投资者持股数量总股本 \frac{\text{机构投资者持股数量}}{\...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/institutional-holdings-ratio
