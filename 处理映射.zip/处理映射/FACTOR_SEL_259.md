# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_259  
因子名称: 日内信息不对称强度因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 日内信息不对称强度因子, 质量, 动量, 成长, 价值, 量化交易  
原始公式: r_i^{overnight}

R_i^{overnight}

r_i^{pm}

R_i^{pm}

r_i^{overnight} = \alpha + \beta R_i^{overnight} + \varepsilon_i^{overnight}

\varepsilon_i^{overnight}

r_i^{pm} = \alpha + \beta R_i^{pm} + \varepsilon_i^{pm}

\varepsilon_i^{pm}

\delta_i = \varepsilon_i^{overnight} - \varepsilon_i^{pm}

\mu(\delta_i)

参数说明：riovernightr_i：^{overnight}riovernight​:第i日个股的隔夜收益率，通常指当日开盘价相对于前一日收盘价的收益率，更精确的定义可以根据实际交易数据进行调整。RiovernightR_i^{overnight}Riovernight​:第i日指数的隔夜收益率，对应个股的隔夜收益率，定义应保持一致。ripmr_i^{pm}ripm​:第i日个股下午时段的收益率，通常定义为从当日下午开盘至收盘的价格收益率，具体时段定义需要根据交易所的实际交易时间进行精确调整。RipmR_i^{pm}Ripm​:第i日指数下午时段的收益率，对应个股下午时段的收益率，定义应保持一致。α\alphaα:线性回归中的截距项，代表在市场指数收益为零时，个股收益的预期值。β\betaβ:线性回归中的回归系数，表示指数收益变化一个单位时，个股收益预期变化的幅度。εiovernight\varepsilon_i^{overnight}εiovernight​:第i日个股隔夜收益率回归模型的残差项，代表模型无法解释的个股隔夜收益部分。该残差项可以理解为剔除市场影响后的个股隔夜收益信息。εipm\varepsilon_i^{pm}εipm​:第i日个股下午时段收益率回归模型的残差项，代表模型无法解释的个股下午时段收益部分，可以理解为剔除市...  
DSL公式: r_i**overnight
R_i**overnight
r_i**pm
R_i**pm
r_i**overnight = alpha + beta R_i**overnight + \varepsilon_i**overnight
\varepsilon_i**overnight
r_i**pm = alpha + beta R_i**pm + \varepsilon_i**pm
\varepsilon_i**pm
delta_i = \varepsilon_i**overnight - \varepsilon_i**pm
mu(delta_i)  
描述: 因子解释该因子基于知情交易者在上午交易更活跃的假设，构建了刻画股票日内信息不对称程度的量化指标。改进的APM因子使用隔夜收益率代替上午收益率，从而更好地捕捉开盘前的信息披露对价格的影响。通过线性回归剔除市场波动，并结合T统计量来衡量隔夜和下午收益残差差异的显著性。进一步通过横截面回归剔除动量效应，得到最终的日内信息不对称强度因子，该因子可用于量化选股策略中，帮助识别可能存在信息优势的股票。该因子可...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/apm-factor
