# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_108  
因子名称: 实体K线一致性交易强度因子  
分类: : 技术指标  
标签: : 线一致性交易强度因子, 流动性, 技术指标, 实体, 质量, 动量, 成长, 价值  
原始公式: |close - open| \le \alpha |high - low|

CTSI_t = \frac{1}{d}\sum_{i=1}^{d} \left(\frac{ConsistentVolume_i}{Volume_i} \right)_{t-i}

\alpha

ConsistentVolume_i

Volume_i

参数说明：α\alphaα:为一致性参数，控制实体K线的定义标准。$\alpha$ 值越大，表示实体K线定义越宽松，即允许更大的影线长度；$\alpha$ 值越小，表示实体K线定义越严格，影线长度需要更短。通常 (\alpha) 取值在 0.2 到 0.5 之间。ConsistentVolumeiConsistentVolume_iConsistentVolumei​:为第i个5分钟周期内，被判定为实体K线的成交量之和。该值代表该周期内市场一致性交易的强度，数值越大，表示一致性交易越强。VolumeiVolume_iVolumei​:为第i个5分钟周期的总成交量。该值代表该周期内市场整体的交易活跃度。ddd:为移动平均的周期参数。它决定了计算CTSI时使用的历史数据窗口长度，较小的d值对市场变化更为敏感，而较大的d值则更加平滑。该参数通常选取为5到20之间。因子解释本因子假设市场集体一致性交易行为预示着潜在的趋势性机会。当一段时间内，股票的交易呈现较高的一致性（即CTSI值较高）时，表明市场可能正在经历信息吸收和价格调整的过程。这种一致性通常是市场情绪或特定消息驱动的结果，并可能预示着股价未来可能出现显著的波动。通过跟踪和分析CTSI值，交易者可以识别出趋势形成或加速的潜在机会。同时，该因子也可以作为风险预警信号，当CTSI值异常高时，可能意味着市场情绪过热，需要警惕价格反转的风险。需要注意的是，该因子的有效性受到市场结构和交易标的特性的影响，可能需要根据实际情况进行调整和优化。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。刘均伟. (2018). 一致交易因子：挖掘集体行为背后的收益. 光大证券Related Factors 一致性下跌成交量比率因子 实体K线一致性买入强度因子 大单成交量价动量 主力成交同步性因子 开盘时段主动净买额占比 成交额波动率 主力成交额-价格相关性因子 收益动量一致性因子 开盘时段大单净买入强度标准化均值 一致性下跌成交量比率因子 实体K线一致性买入强度因子 大单成交量价动量 主力成交同步性因子 开盘时段主动净买额占比 成交额波动率 主力成交额-价格相关性因子 收益动量一致性因子 开盘时段大单净买入强度标准化均值 Factors DirectoryQuantitative Trading Factors实体K线一致性交易强度技术因子因子公式实体K线定义:∣close−open∣≤α∣high−low∣ |close - open| \le \alpha |high - low| ∣close−open∣≤α∣high−low∣实体K线一致性交易强度因子(CTSI):CTSIt=1d∑i=1d(ConsistentVolumeiVolumei)t−i CTSI_t = \frac{1}{d}\sum_{i=1}^{d} \left(\frac{ConsistentVolume_i}{Volume_i} \right)_{t-i} CTSIt​=d1​i=1∑d​(Volumei​ConsistentVolumei​​)t−i​其中：α\alphaα:为一致性参数，控制实体K线的定义标准。$\alpha$ 值越大，表示实体K线定义越宽松，即允许更大的影线长度；$\alpha$ 值越小，表示实体K线定义越严格，影线长度需要更短。通常 (\alpha) 取值在 0.2 到 0.5 之间。ConsistentVolumeiConsistentVolume_iConsistentVolumei​:为第i个5分钟周...  
DSL公式: |close - open| \le alpha |high - low|
CTSI_t = /1dSUM_i=1**d (/ConsistentVolume_iVolume_i )_t-i
alpha
ConsistentVolume_i
Volume_i  
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors实体K线一致性交易强度技术因子因子公式实体K线定义:∣close−open∣≤α∣high−low∣ |close - open| \le...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/consistent-trading
