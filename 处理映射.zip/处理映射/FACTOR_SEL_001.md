# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_001  
因子名称: 成交量价背离度  
分类: : 技术指标  
标签: : 成交量价背离度, 技术指标, 技术分析, 动量, 量化交易  
原始公式:   "CORR(VWAP_{t-d:t}, VOLUME_{t-d:t})
DSL公式:   CORR(VWAP_{t-d:t}, VOLUME_{t-d:t})
描述: 公式中CORR:表示皮尔逊相关系数 (Pearson Correlation Coefficient)，用于衡量两个变量之间的线性相关性强度。其值介于 -1 和 1 之间，-1表示完全负相关，1表示完全正相关，0表示无线性相关性。:表示从 t-d 时刻到 t 时刻的成交量加权平均价格 (Volume Weighted Average Price) 时间序列。VWAP能够体现该时间段内的平均交易成本，能有...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/price-volume-divergence
