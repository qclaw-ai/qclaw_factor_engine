# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_120  
因子名称: 资金流量累积指标 (Accumulation/Distribution Line, A/D)  
分类: : 技术指标  
标签: : 流动性, 资金流量累积指标, 技术指标, 技术分析, distribution, 质量, 动量, 成长  
原始公式: A/D_t = A/D_{t-1} + VOL_t * \frac{2 * CLOSE_t - HIGH_t - LOW_t}{HIGH_t - LOW_t}

A/D_t

A/D_{t-1}

VOL_t

CLOSE_t

HIGH_t

LOW_t

\frac{2 * CLOSE_t - HIGH_t - LOW_t}{HIGH_t - LOW_t}

参数说明：，每日资金流量通过价格区间与收盘价的关系，再乘以成交量得出。A/D指标的计算基于以下公式：A/DtA/D_tA/Dt​:第t日的资金流量累积指标值。A/Dt−1A/D_{t-1}A/Dt−1​:第t-1日的资金流量累积指标值，初始值通常设为0。VOLtVOL_tVOLt​:第t日的成交量。CLOSEtCLOSE_tCLOSEt​:第t日的收盘价。HIGHtHIGH_tHIGHt​:第t日的最高价。LOWtLOW_tLOWt​:第t日的最低价。2∗CLOSEt−HIGHt−LOWtHIGHt−LOWt\frac{2 * CLOSE_t - HIGH_t - LOW_t}{HIGH_t - LOW_t}HIGHt​−LOWt​2∗CLOSEt​−HIGHt​−LOWt​​:每日的资金流量乘数 (Money Flow Multiplier), 该值在-1到1之间波动，代表了当日的资金流量方向和强度，当收盘价接近当日最高价时该乘数为正且接近1，表示当日买方力量强劲；反之，当收盘价接近当日最低价时该乘数为负且接近-1，表示当日卖方力量强劲。分子部分(2*CLOSE_t - HIGH_t - LOW_t)衡量了收盘价在当日价格区间的位置，分母部分(HIGH_t - LOW_t)则为当日的价格区间宽度。当HIGH_t = LOW_t时，为了避免除0错误，通常将此值设置为0，此时资金流量也为0，对A/D指标不产生影响。因子解释资金流量累积指标 (A/D) 通过每日的成交量和价格变动来衡量资金流向，从而反映市场买卖双方的力量对比。当A/D指标上升时，表明资金流入，买盘力量占主导，可能预示着价格上涨的潜力；当A/D指标下降时，表明资金流出，卖盘力量占主导，可能预示着价格下跌的风险。A/D指标与价格之间的背离现象，可以作为重要的交易信号参考。例如，当价格创新低而A/D指标没有创新低时（底背离），可能预示着买盘力量正在积聚，价格可能即将反转上涨；反之，当价格创新高而A/D指标没有创新高时（顶背离），可能预示着卖盘力量正在增强，价格可能即将反转下跌。因此，A/D指标不仅可以帮助识别趋势的强度，还可以发现潜在的价格反转点，属于成交量驱动的，领先指标。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Martin J. Pring. (2008). 技术分析精解. 机械工业出版社Related Factors 蔡金资金流向指标 资金流量指标 方向性动量离散指标 (Directional Momentum Dispersion Index) 动态趋向指标 阿隆指标 移动平均汇聚背离指标 相对强弱人气指标 蔡金资金流量震荡指标 累计振荡指标 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors资金流量累积指标 (A/D)技术因子因子公式资金流量累积指标 (A/D):A/Dt=A/Dt−1+VOLt∗2∗CLOSEt−HIGHt−LOWtHIGHt−LOWt A/D_t = A/D_{t-1} + VOL_t * \frac{2 * CLOSE_t - HIGH_t - LOW_t}{HIGH_t - LOW_t} A/Dt​=A/Dt−1​+VOLt​∗HIGHt​−LOWt​2∗CLOSEt​−HIGHt​−LOWt​​A/D指标是每日资金流量的累积值。其中，每日资金流量通过价格区间与收盘价的关系，再乘以成交量得出。A/D指标的计算基于以下公式：A/DtA/D_tA/Dt​:第t日的资金流量累积指标值。A/Dt−1A/D_{t-1}A/Dt−1​:第t-1日的资金流量累积指标值，初始值通常设为0。VOLtVOL_tVOLt​:第t日的成交量。CLOSEtCLOSE_tCLOSEt...  
DSL公式: A/D_t = A/D_t-1 + VOL_t * /2 * CLOSE_t - HIGH_t - LOW_tHIGH_t - LOW_t
A/D_t
A/D_t-1
VOL_t
CLOSE_t
HIGH_t
LOW_t
/2 * CLOSE_t - HIGH_t - LOW_tHIGH_t - LOW_t  
描述: Factors DirectoryQuantitative Trading Factors资金流量累积指标 (A/D)技术因子因子公式资金流量累积指标 (A/D):A/Dt=A/Dt−1+VOLt∗2∗CLOSEt−HIGHt−LOWtHIGHt−LOWt A/D_t = A/D_{t-1} + VOL_t * \frac{2 * CLOSE_t - HIGH_t - LOW_t}{HIGH_t ...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/accumulative-distribution-line
