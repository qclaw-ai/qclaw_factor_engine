# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_349  
因子名称: 现金转换周期 (Cash Conversion Cycle, CCC)  
分类: : 基本面指标  
标签: : 流动性, conversion, 基本面指标, 质量, cycle, 现金转换周期, ccc, 动量  
原始公式: \frac{360}{应收账款周转率}

\frac{360}{应付账款周转率}

\frac{360}{存货周转率}  
DSL公式: /360应收账款周转率
/360应付账款周转率
/360存货周转率  
描述: ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Ludwig B. Chincarini, Daehwan Kim. (2006). Quantitative Equity Portfolio Management: An Active Approach to Portfol...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/cash-conversion-cycle
