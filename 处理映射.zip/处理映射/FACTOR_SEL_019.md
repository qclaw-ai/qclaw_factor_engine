# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_019  
因子名称: 成交量相对强度指标  
分类: : 技术指标  
标签: : 流动性, 技术指标, 技术分析, 质量, 动量, 成长, 基本面分析, 量化交易  
原始公式: A = \begin{cases} VOL & \text{if } CLOSE > CLOSE[1] \\ 0 & \text{otherwise} \end{cases}

B = \begin{cases} VOL & \text{if } CLOSE < CLOSE[1] \\ 0 & \text{otherwise} \end{cases}

VR = \frac{\sum_{i=1}^{N} A_i}{\sum_{i=1}^{N} B_i} \times 100

CLOSE

CLOSE[1]

VOL

A_i

B_i

\sum_{i=1}^{N} X_i

参数说明：CLOSECLOSECLOSE：当日收盘价：表示当前交易日结束时的股票价格。CLOSE[1]CLOSE[1]CLOSE[1]:前一日收盘价：表示前一个交易日结束时的股票价格。用于比较当日收盘价的变化方向。VOLVOLVOL:当日成交量：表示当前交易日内完成的股票交易总手数或总股数，是衡量市场活跃度的重要指标。AiA_iAi​:第i个交易日的上涨成交量：当天的收盘价高于前一天的收盘价时，A_i等于当天的成交量，否则为0。BiB_iBi​:第i个交易日的下跌成交量：当天的收盘价低于前一天的收盘价时，B_i等于当天的成交量，否则为0。∑i=1NXi\sum_{i=1}^{N} X_i∑i=1N​Xi​:X值在N个周期内的总和：表示对X值在过去N个交易日内的数值进行累加求和。NNN:计算周期：表示计算VR指标时所使用的历史交易日数量。默认值为20，可以根据不同的交易策略和市场情况进行调整。较短的周期通常对价格变动更敏感，而较长的周期则更平滑，能减少噪音。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 Related Factors 成交量相对强度指标 相对波动性指标 相对强弱人气指标 区域强度指数 相对强弱指标 (RSI) 相对强弱指标 (Relative Strength Index) 个股相对点击量因子 实体K线一致性买入强度因子 价格成交量趋势指标 其中:CLOSECLOSECLOSE:当日收盘价：表示当前交易日结束时的股票价格。CLOSE[1]CLOSE[1]CLOSE[1]:前一日收盘价：表示前一个交易日结束时的股票价格。用于比较当日收盘价的变化方向。VOLVOLVOL:当日成交量：表示当前交易日内完成的股票交易总手数或总股数，是衡量市场活跃度的重要指标。AiA_iAi​:第i个交易日的上涨成交量：当天的收盘价高于前一天的收盘价时，A_i等于当天的成交量，否则为0。BiB_iBi​:第i个交易日的下跌成交量：当天的收盘价低于前一天的收盘价时，B_i等于当天的成交量，否则为0。∑i=1NXi\sum_{i=1}^{N} X_i∑i=1N​Xi​:X值在N个周期内的总和：表示对X值在过去N个交易日内的数值进行累加求和。NNN:计算周期：表示计算VR指标时所使用的历史交易日数量。默认值为20，可以根据不同的交易策略和市场情况进行调整。较短的周期通常对价格变动更敏感，而较长的周期则更平滑，能减少噪音。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情...  
DSL公式: A = \begincases VOL & \textif close > close[1] \\ 0 & \textotherwise \endcases
B = \begincases VOL & \textif close < close[1] \\ 0 & \textotherwise \endcases
VR = /SUM_i=1**N A_iSUM_i=1**N B_i * 100
close
close[1]
VOL
A_i
B_i
SUM_i=1**N X_i  
描述: 因子解释成交量相对强度指标（VR）通过比较N个周期内股价上涨日的成交量总和与股价下跌日的成交量总和的比率，来衡量市场买卖双方力量的对比。当VR值较高时，表明市场买方力量较强，股价可能处于超买状态，反之，当VR值较低时，表明市场卖方力量较强，股价可能处于超卖状态。投资者可以通过VR指标的变化辅助判断市场的潜在趋势，并结合其他技术指标和基本面分析来制定更有效的交易策略。该指标尤其适用于中期趋势分析，帮...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/volume-ratio-indicator
