# -*- coding: utf-8 -*-
"""
Selenium增强版因子爬虫 - 优先从MathML annotation中提取LaTeX公式
"""

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import requests
from bs4 import BeautifulSoup, Comment
import time
import os
import re
import json
from datetime import datetime
import logging
from urllib.parse import urljoin, urlparse

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('selenium_enhanced_crawler.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)


class SeleniumEnhancedCrawler:
    def __init__(self):
        # 初始化Selenium WebDriver
        self.driver = self.setup_driver()

        # 初始化requests会话（用于快速获取链接）
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Referer': 'https://factors.directory/zh'
        })

        # 基础URL
        self.base_url = 'https://factors.directory'

        # 种子URL（覆盖所有分类）
        self.seed_urls = [
            # 技术指标
            'https://factors.directory/zh/factors/tech/price-volume-divergence',
            'https://factors.directory/zh/factors/tech/volume-moving-average-convergence-divergence',
            'https://factors.directory/zh/factors/tech/price-volume-trend',

            # 情绪指标
            'https://factors.directory/zh/factors/emotion/herd-effect',
            'https://factors.directory/zh/factors/emotion/main-force-trading-sentiment',

            # 基本面指标
            'https://factors.directory/zh/factors/basic-surface/sales-cash-ratio',
            'https://factors.directory/zh/factors/basic-surface/roe-diluted-non-recurring',

            # 动量指标
            'https://factors.directory/zh/factors/momentum/momentum-factor',
            'https://factors.directory/zh/factors/momentum/price-momentum',

            # 波动率指标
            'https://factors.directory/zh/factors/volatility/value-at-risk',
            'https://factors.directory/zh/factors/volatility/volatility-coefficient-of-turnover',

            # 流动性指标
            'https://factors.directory/zh/factors/liquidity/market-cap-adjusted-turnover',

            # 成长性指标
            'https://factors.directory/zh/factors/growth/yoy-growth-rate-of-net-assets-per-share',

            # 质量指标
            'https://factors.directory/zh/factors/quality/quality-retained-earnings-per-share',

            # 价值指标
            'https://factors.directory/zh/factors/value/value-retained-earnings-per-share',

            # 规模指标
            'https://factors.directory/zh/factors/scale/scale-log-market-cap'
        ]

        # 输出文件
        self.output_file = 'selenium_enhanced_factors_data_1.md'
        self.json_output_file = 'selenium_enhanced_factors_data_1.json'

        # 已访问的URL集合
        self.visited_urls = set()

        # 因子数据集合
        self.factors_data = []

        # 分类映射
        self.category_map = {
            'tech': '技术指标',
            'emotion': '情绪指标',
            'basic-surface': '基本面指标',
            'momentum': '动量指标',
            'volatility': '波动率指标',
            'liquidity': '流动性指标',
            'growth': '成长性指标',
            'quality': '质量指标',
            'value': '价值指标',
            'scale': '规模指标'
        }

        # 统计信息
        self.request_count = 0
        self.success_count = 0
        self.error_count = 0
        self.selenium_requests = 0

    def setup_driver(self):
        """设置Chrome WebDriver"""
        chrome_options = Options()

        # 无头模式（可注释掉以查看浏览器）
        chrome_options.add_argument('--headless')

        # 其他优化选项
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--window-size=1920,1080')
        chrome_options.add_argument('--disable-blink-features=AutomationControlled')
        chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
        chrome_options.add_experimental_option('useAutomationExtension', False)

        # 设置中文语言
        chrome_options.add_argument('--lang=zh-CN')

        driver = webdriver.Chrome(options=chrome_options)

        # 隐藏自动化特征
        driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")

        return driver

    def get_page_content_fast(self, url, max_retries=3):
        """快速获取页面内容（用于链接发现）"""
        self.request_count += 1

        for attempt in range(max_retries):
            try:
                response = self.session.get(url, timeout=10)
                response.encoding = 'utf-8'

                if response.status_code == 200:
                    self.success_count += 1
                    return response.text
                else:
                    logging.warning(f"快速请求失败，状态码: {response.status_code}, 尝试 {attempt + 1}/{max_retries}")
                    self.error_count += 1

            except Exception as e:
                logging.warning(f"快速请求异常: {e}, 尝试 {attempt + 1}/{max_retries}")
                self.error_count += 1

            if attempt < max_retries - 1:
                time.sleep(1)

        logging.error(f"无法快速获取页面: {url}")
        return None

    def get_page_content_selenium(self, url, wait_time=5):
        """使用Selenium获取完整渲染的页面内容"""
        self.selenium_requests += 1

        try:
            # 导航到页面
            self.driver.get(url)

            # 等待页面加载完成
            WebDriverWait(self.driver, wait_time).until(
                lambda driver: driver.execute_script('return document.readyState') == 'complete'
            )

            # 额外等待JavaScript内容加载
            time.sleep(2)

            # 获取完整的页面HTML
            html_content = self.driver.page_source

            logging.info(f"Selenium成功获取页面: {url}")
            return html_content

        except Exception as e:
            logging.error(f"Selenium获取页面失败 {url}: {e}")
            return None

    # ---------- 新增方法：从MathML annotation提取公式 ----------
    def extract_math_from_annotation(self, html_content):
        """
        从 <annotation encoding="application/x-tex"> 标签中提取LaTeX公式
        返回公式列表
        """
        soup = BeautifulSoup(html_content, 'html.parser')
        formulas = []
        annotation_tags = soup.find_all('annotation', attrs={'encoding': 'application/x-tex'})
        for tag in annotation_tags:
            latex = tag.get_text().strip()
            if latex and len(latex) > 2:
                formulas.append(latex)
        return formulas

    # ---------- 原有方法：从JSON提取 ----------
    def extract_factor_json(self, html_content):
        """
        从HTML中提取因子数据的JSON对象（增强版）
        返回解析后的字典，如果未找到则返回None
        """
        soup = BeautifulSoup(html_content, 'html.parser')

        # 常见的数据脚本ID或类型
        script_selectors = [
            {'id': '__NEXT_DATA__'},  # Next.js
            {'type': 'application/json'},  # 通用JSON
            {'type': 'application/ld+json'},  # 结构化数据
            {'id': 'factor-data'},  # 自定义ID
            {'id': 'page-data'},
        ]

        # 方法1：通过ID或类型查找
        for selector in script_selectors:
            script = soup.find('script', attrs=selector)
            if script and script.string:
                try:
                    data = json.loads(script.string)
                    if isinstance(data, dict) and ('formulas' in data or 'name' in data):
                        logging.info(f"通过 {selector} 找到JSON数据")
                        return data
                except:
                    continue

        # 方法2：查找所有<script>，尝试解析其内容（可能包含变量赋值）
        scripts = soup.find_all('script')
        for script in scripts:
            if not script.string:
                continue

            content = script.string.strip()
            if not content:
                continue

            # 尝试直接解析整个脚本内容（如果就是JSON）
            if content.startswith('{') and content.endswith('}'):
                try:
                    data = json.loads(content)
                    if isinstance(data, dict) and ('formulas' in data or 'name' in data):
                        logging.info("通过直接解析脚本内容找到JSON")
                        return data
                except:
                    pass

            # 尝试匹配常见的全局变量赋值
            patterns = [
                r'window\.__INITIAL_STATE__\s*=\s*(\{.*?\});',
                r'window\.__PROPS__\s*=\s*(\{.*?\});',
                r'var\s+pageData\s*=\s*(\{.*?\});',
                r'const\s+factorData\s*=\s*(\{.*?\});',
                r'window\.factorData\s*=\s*(\{.*?\});',
                r'var\s+data\s*=\s*(\{.*?\});',
                r'__NEXT_DATA__\s*=\s*(\{.*?\});',
            ]
            for pattern in patterns:
                match = re.search(pattern, content, re.DOTALL)
                if match:
                    try:
                        data = json.loads(match.group(1))
                        if isinstance(data, dict) and ('formulas' in data or 'name' in data):
                            logging.info(f"通过正则匹配 {pattern} 找到JSON")
                            return data
                    except:
                        continue

        # 方法3：尝试查找可能包含JSON的注释块（有些框架会注释掉）
        comments = soup.find_all(string=lambda text: isinstance(text, Comment) and 'formulas' in text)
        for comment in comments:
            json_match = re.search(r'(\{.*\})', comment, re.DOTALL)
            if json_match:
                try:
                    data = json.loads(json_match.group(1))
                    if isinstance(data, dict) and ('formulas' in data or 'name' in data):
                        logging.info("从注释中找到JSON")
                        return data
                except:
                    continue

        return None

    # ---------- 后备方法：从详细内容正则提取 ----------
    def extract_math_formulas_fallback(self, html_content):
        """
        后备方法：从详细内容中尝试提取公式（当其他方法失败时使用）
        """
        detailed_text = self.extract_detailed_content(html_content)
        formulas = []
        # 使用较精确的正则匹配LaTeX表达式
        patterns = [
            r'\\[a-zA-Z]+\{[^}]+\}',  # LaTeX命令带参数
            r'[A-Za-z]_\{[^}]+\}',  # 下标
            r'[A-Za-z]\^\{[^}]+\}',  # 上标
            r'\\frac\{[^}]+\}\{[^}]+\}',  # 分数
            r'\\sqrt(?:\[[^\]]+\])?\{[^}]+\}',  # 根号
            r'[A-Za-z]+\s*=\s*[^\s,;]+',  # 简单等式
        ]
        for p in patterns:
            matches = re.findall(p, detailed_text)
            for m in matches:
                if len(m) > 3 and not re.search(r'[/.]', m):  # 过滤掉路径
                    formulas.append(m)
        return list(set(formulas)) if formulas else ['未找到数学公式']

    def extract_factor_name(self, soup, url):
        """提取因子名称（后备方法）"""
        # 1. 从meta标签提取
        meta_title = soup.find('meta', attrs={'property': 'og:title'})
        if meta_title and meta_title.get('content'):
            title = meta_title.get('content')
            if ' - ' in title:
                return title.split(' - ')[0]
            return title

        # 2. 从title标签提取
        title_tag = soup.find('title')
        if title_tag:
            title_text = title_tag.get_text().strip()
            if title_text and title_text != 'Factors Directory':
                if ' - ' in title_text:
                    return title_text.split(' - ')[0]
                if ' | ' in title_text:
                    return title_text.split(' | ')[0]
                return title_text

        # 3. 从URL路径提取
        url_parts = url.split('/')
        if len(url_parts) >= 1:
            factor_name = url_parts[-1]
            factor_name = ' '.join(word.capitalize() for word in factor_name.split('-'))
            return factor_name

        return '未知因子'

    def extract_category_from_url(self, url):
        """从URL中提取分类信息"""
        url_parts = url.split('/')
        for i, part in enumerate(url_parts):
            if part == 'factors' and i + 1 < len(url_parts):
                category_key = url_parts[i + 1]
                return self.category_map.get(category_key, '未知分类')
        return '未知分类'

    def extract_detailed_content(self, html_content):
        """提取详细内容（后备方法）"""
        soup = BeautifulSoup(html_content, 'html.parser')

        content_blocks = []

        # 提取所有文本内容丰富的标签
        text_tags = ['p', 'div', 'section', 'article', 'main']

        for tag_name in text_tags:
            tags = soup.find_all(tag_name)
            for tag in tags:
                text = tag.get_text().strip()
                if len(text) > 50 and len(text) < 2000:
                    # 过滤掉导航和页脚内容
                    if any(keyword in text.lower() for keyword in
                           ['导航', '菜单', 'footer', 'header', 'copyright', '©']):
                        continue

                    # 检查是否包含因子相关内容
                    if any(keyword in text for keyword in
                           ['因子', '指标', '计算', '公式', '解释', '说明', '衡量', '评估', '分析']):
                        content_blocks.append(text)

        # 去重并合并
        unique_blocks = list(set(content_blocks))

        if unique_blocks:
            return ' '.join(unique_blocks)

        # 如果没找到内容块，尝试提取整个页面的主要文本
        main_text = soup.get_text()
        main_text = re.sub(r'\s+', ' ', main_text)
        return main_text if len(main_text) > 100 else '未找到详细内容'

    def extract_tags(self, html_content, factor_name, category):
        """提取标签"""
        tags = []

        # 基础标签
        tags.append('量化交易')
        tags.append(category)

        # 从因子名称提取关键词
        if factor_name and factor_name != '未知因子':
            # 中文关键词提取
            chinese_keywords = re.findall(r'[\u4e00-\u9fff]+', factor_name)
            tags.extend([kw for kw in chinese_keywords if len(kw) > 1])

            # 英文关键词提取
            english_keywords = re.findall(r'[A-Za-z]+', factor_name)
            tags.extend([kw.lower() for kw in english_keywords if len(kw) > 2])

        # 从内容中提取常见关键词
        common_keywords = ['技术分析', '基本面分析', '动量', '波动率', '流动性', '价值', '成长', '质量', '规模']
        for keyword in common_keywords:
            if keyword in html_content:
                tags.append(keyword)

        # 去重
        tags = list(set(tags))

        return tags

    def find_factor_links(self, html_content, current_url):
        """查找因子链接"""
        soup = BeautifulSoup(html_content, 'html.parser')
        factor_urls = []

        # 查找所有链接
        all_links = soup.find_all('a', href=True)

        for link in all_links:
            href = link.get('href', '')

            # 筛选因子相关链接
            if '/factors/' in href and href.count('/') >= 4:
                # 构建完整URL
                if href.startswith('/'):
                    full_url = f'{self.base_url}{href}'
                elif href.startswith('http'):
                    full_url = href
                else:
                    full_url = urljoin(current_url, href)

                # 确保是有效的因子链接
                if (full_url.startswith('http') and
                        full_url != current_url and
                        full_url not in self.visited_urls and
                        not full_url.endswith('/factors/') and
                        '/zh/factors/' in full_url):
                    factor_urls.append(full_url)

        # 去重
        factor_urls = list(set(factor_urls))

        logging.info(f"找到 {len(factor_urls)} 个因子链接")
        return factor_urls

    # ---------- 修改解析方法：优先从annotation提取 ----------
    def parse_factor_page_enhanced(self, url):
        """增强版因子页面解析（优先从MathML annotation中提取公式）"""
        if url in self.visited_urls:
            return None

        logging.info(f"解析因子页面: {url}")

        # 使用Selenium获取完整渲染的页面内容
        html_content = self.get_page_content_selenium(url)

        if not html_content:
            # 如果Selenium失败，尝试使用快速方法
            html_content = self.get_page_content_fast(url)
            if not html_content:
                return None

        factor_data = {}
        soup = BeautifulSoup(html_content, 'html.parser')

        try:
            # 1. 优先从MathML annotation提取公式
            formulas = self.extract_math_from_annotation(html_content)
            extraction_method = 'MathML Annotation'

            # 2. 如果annotation方法未找到公式，尝试从JSON提取
            if not formulas:
                json_data = self.extract_factor_json(html_content)
                if json_data:
                    # 从JSON中提取公式
                    if 'formulas' in json_data and isinstance(json_data['formulas'], list):
                        for f in json_data['formulas']:
                            if 'latex' in f:
                                formulas.append(f['latex'])
                            elif 'text' in f:
                                formulas.append(f['text'])
                    extraction_method = 'JSON'

                    # 从JSON中提取公式解释，附加到详细内容
                    explanation_text = ""
                    if 'formulaExplanation' in json_data:
                        exp = json_data['formulaExplanation']
                        if 'text' in exp:
                            explanation_text += exp['text'] + "\n"
                        if 'symbols' in exp and isinstance(exp['symbols'], list):
                            for sym in exp['symbols']:
                                explanation_text += f"- **{sym.get('symbol', '')}**: {sym.get('meaning', '')}\n"
                    if explanation_text:
                        factor_data['explanation'] = explanation_text

            # 3. 如果前两者都失败，使用后备方法
            if not formulas:
                formulas = self.extract_math_formulas_fallback(html_content)
                extraction_method = 'Fallback'

            # 提取因子名称
            factor_data['factor_name'] = self.extract_factor_name(soup, url)

            # 提取分类
            factor_data['category'] = self.extract_category_from_url(url)

            # 提取详细内容
            base_content = self.extract_detailed_content(html_content)
            if 'explanation' in factor_data:
                factor_data['content'] = base_content + "\n\n### 公式符号解释\n" + factor_data['explanation']
            else:
                factor_data['content'] = base_content

            # 保存公式
            factor_data['formulas'] = formulas if formulas else ['未找到数学公式']

            # 提取标签
            factor_data['tags'] = self.extract_tags(html_content, factor_data['factor_name'], factor_data['category'])

            # 添加元数据
            factor_data['url'] = url
            factor_data['crawl_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            factor_data['content_length'] = len(factor_data['content'])
            factor_data['formula_found'] = len([f for f in formulas if f != '未找到数学公式']) > 0
            factor_data['crawl_method'] = extraction_method

            # 标记为已访问
            self.visited_urls.add(url)

            logging.info(f"成功解析因子: {factor_data['factor_name']} (方法: {extraction_method})")
            return factor_data

        except Exception as e:
            logging.error(f"解析因子页面失败 {url}: {e}")
            return None

    def crawl_with_bfs_enhanced(self, max_factors=9999):
        """使用广度优先搜索进行大规模爬取（增强版）"""
        logging.info(f"开始大规模爬取，目标: {max_factors} 个因子")

        # 使用队列进行广度优先搜索
        queue = self.seed_urls.copy()
        crawled_count = 0

        start_time = time.time()

        while queue and crawled_count < max_factors:
            current_url = queue.pop(0)

            # 解析当前因子页面（使用Selenium增强版）
            factor_data = self.parse_factor_page_enhanced(current_url)

            if factor_data:
                self.factors_data.append(factor_data)
                crawled_count += 1

                # 使用快速方法获取页面内容用于查找相关因子
                html_content = self.get_page_content_fast(current_url)

                if html_content:
                    # 查找所有相关因子链接
                    related_urls = self.find_factor_links(html_content, current_url)

                    # 将新发现的链接加入队列
                    for url in related_urls:
                        if url not in self.visited_urls and url not in queue:
                            queue.append(url)

                # 显示进度
                if crawled_count % 10 == 0:
                    elapsed_time = time.time() - start_time
                    speed = crawled_count / elapsed_time if elapsed_time > 0 else 0
                    remaining = max_factors - crawled_count
                    eta = remaining / speed if speed > 0 else 0

                    logging.info(f"进度: {crawled_count}/{max_factors} 因子 | "
                                 f"速度: {speed:.2f} 因子/秒 | "
                                 f"预计剩余时间: {eta:.0f} 秒 | "
                                 f"队列长度: {len(queue)}")

                # 添加延迟，避免请求过快
                time.sleep(1)

            if not queue:
                logging.info("没有更多因子链接可爬取")
                break

        end_time = time.time()
        total_time = end_time - start_time

        logging.info(f"大规模爬取完成！共获取 {crawled_count} 个因子")
        logging.info(f"总时间: {total_time:.2f} 秒")
        logging.info(f"平均速度: {crawled_count / total_time:.2f} 因子/秒")
        logging.info(f"请求统计: 快速请求 {self.request_count}, Selenium请求 {self.selenium_requests}")

        return crawled_count

    def generate_md_content(self):
        """生成MD内容"""
        md_content = f"""# Factors Directory Selenium增强版因子库

> 最后更新时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
> 总因子数量: {len(self.factors_data)}
> 总数学公式数量: {sum(len([f for f in factor['formulas'] if f != '未找到数学公式']) for factor in self.factors_data)}
> 总内容长度: {sum(factor['content_length'] for factor in self.factors_data)} 字符
> 爬取方法: Selenium增强版（优先从MathML annotation提取）

## 目录
"""

        # 按分类组织目录
        categories = {}
        for factor in self.factors_data:
            category = factor['category']
            if category not in categories:
                categories[category] = []
            categories[category].append(factor['factor_name'])

        for category, factors in sorted(categories.items()):
            md_content += f"\n### {category}\n"
            for factor_name in sorted(factors):
                # 生成锚点链接
                anchor = factor_name.replace(' ', '-').replace('(', '').replace(')', '').lower()
                md_content += f"- [{factor_name}](#{anchor})\n"

        md_content += "\n---\n"

        # 添加所有因子内容
        for factor in self.factors_data:
            md_content += self.generate_factor_section(factor)

        return md_content

    def generate_factor_section(self, factor):
        """生成单个因子的MD内容"""
        section = f"""
## {factor['factor_name']}

### 基本信息
- **分类**: {factor['category']}
- **抓取时间**: {factor['crawl_time']}
- **来源URL**: {factor['url']}
- **爬取方法**: {factor['crawl_method']}
- **标签**: {', '.join(factor['tags'][:8])}
- **内容长度**: {factor['content_length']} 字符
- **找到数学公式**: {factor['formula_found']}

### 详细内容
{factor['content'][:2000]}{'...' if len(factor['content']) > 2000 else ''}

### 数学公式
"""

        # 添加数学公式
        for i, formula in enumerate(factor['formulas'][:10], 1):  # 限制显示前10个
            if formula != '未找到数学公式':
                section += f"\n#### 公式 {i}\n```latex\n{formula}\n```\n"
            else:
                section += f"\n#### 公式 {i}\n{formula}\n"

        section += "\n---\n"

        return section

    def save_results(self):
        """保存结果"""
        if not self.factors_data:
            logging.warning("没有因子数据可保存")
            return

        # 生成并保存MD文件
        md_content = self.generate_md_content()
        with open(self.output_file, 'w', encoding='utf-8') as f:
            f.write(md_content)

        # 保存为JSON文件
        with open(self.json_output_file, 'w', encoding='utf-8') as f:
            json.dump(self.factors_data, f, ensure_ascii=False, indent=2)

        logging.info(f"因子数据已保存到: {self.output_file} 和 {self.json_output_file}")

    def generate_detailed_statistics(self):
        """生成详细统计报告"""
        stats_file = 'selenium_enhanced_statistics_1.txt'

        with open(stats_file, 'w', encoding='utf-8') as f:
            f.write("=== Selenium增强版因子爬取统计报告 ===\n\n")
            f.write(f"总因子数量: {len(self.factors_data)}\n")
            f.write(f"快速请求次数: {self.request_count}\n")
            f.write(f"Selenium请求次数: {self.selenium_requests}\n")
            f.write(f"总请求次数: {self.request_count + self.selenium_requests}\n\n")

            # 按类别统计
            categories = {}
            for factor in self.factors_data:
                category = factor['category']
                if category not in categories:
                    categories[category] = 0
                categories[category] += 1

            f.write("按类别统计:\n")
            for category, count in sorted(categories.items(), key=lambda x: x[1], reverse=True):
                f.write(f"{category}: {count} 个因子\n")

            # 爬取方法统计
            methods = {}
            for factor in self.factors_data:
                method = factor['crawl_method']
                if method not in methods:
                    methods[method] = 0
                methods[method] += 1

            f.write(f"\n爬取方法统计:\n")
            for method, count in methods.items():
                f.write(f"{method}: {count} 个因子\n")

            # 公式统计
            formulas_found = sum(1 for factor in self.factors_data if factor['formula_found'])
            total_formulas = sum(
                len([f for f in factor['formulas'] if f != '未找到数学公式']) for factor in self.factors_data)

            f.write(f"\n公式统计:\n")
            f.write(f"找到公式的因子数量: {formulas_found}/{len(self.factors_data)}\n")
            f.write(f"总共找到的公式数量: {total_formulas}\n")

            # 标签统计
            all_tags = []
            for factor in self.factors_data:
                all_tags.extend(factor['tags'])

            from collections import Counter
            tag_counter = Counter(all_tags)

            f.write(f"\n热门标签 (前15):\n")
            for tag, count in tag_counter.most_common(15):
                f.write(f"{tag}: {count} 次\n")

        logging.info(f"详细统计报告已保存到: {stats_file}")

    def run_enhanced_crawler(self, max_factors=9999):
        """运行增强版爬虫"""
        logging.info("开始运行Selenium增强版因子爬虫...")

        try:
            # 大规模爬取所有因子
            crawled_count = self.crawl_with_bfs_enhanced(max_factors)

            # 保存结果
            if crawled_count > 0:
                self.save_results()

                # 生成详细统计报告
                self.generate_detailed_statistics()

                logging.info(f"Selenium增强版爬取完成！共获取 {crawled_count} 个因子")
                return True
            else:
                logging.error("未能获取任何因子数据")
                return False

        finally:
            # 确保关闭WebDriver
            if hasattr(self, 'driver') and self.driver:
                self.driver.quit()
                logging.info("WebDriver已关闭")

    def close(self):
        """关闭资源"""
        if hasattr(self, 'driver') and self.driver:
            self.driver.quit()


def main():
    """主函数"""
    crawler = SeleniumEnhancedCrawler()

    try:
        # 运行增强版爬虫（目标9999个因子）
        success = crawler.run_enhanced_crawler(max_factors=9999)

        if success:
            print("\nSelenium增强版爬取完成！")
            print(f"总因子数量: {len(crawler.factors_data)}")

            # 显示统计信息
            categories = {}
            for factor in crawler.factors_data:
                category = factor['category']
                if category not in categories:
                    categories[category] = 0
                categories[category] += 1

            print("\n按类别统计:")
            for category, count in sorted(categories.items(), key=lambda x: x[1], reverse=True):
                print(f"  {category}: {count} 个因子")

            # 爬取方法统计
            methods = {}
            for factor in crawler.factors_data:
                method = factor['crawl_method']
                if method not in methods:
                    methods[method] = 0
                methods[method] += 1

            print("\n爬取方法统计:")
            for method, count in methods.items():
                print(f"  {method}: {count} 个因子")

            print(f"\n输出文件: {crawler.output_file}")
            print(f"JSON文件: {crawler.json_output_file}")

    except KeyboardInterrupt:
        logging.info("用户中断爬取过程")
        crawler.close()
    except Exception as e:
        logging.error(f"爬取过程出现异常: {e}")
        crawler.close()


if __name__ == "__main__":
    main()