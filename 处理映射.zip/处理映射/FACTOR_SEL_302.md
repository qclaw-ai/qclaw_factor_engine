# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_302  
因子名称: 价格分位差振幅因子  
分类: : 波动率指标  
标签: : 流动性, 波动率, 质量, 动量, 成长, 价值, 量化交易, 波动率指标  
原始公式: \frac{High_t}{Low_t} - 1

V_{high}(\lambda) = \frac{1}{N \times \lambda} \sum_{t \in \mathcal{S}_{high}} \left( \frac{High_t}{Low_t} - 1 \right)

V_{low}(\lambda) = \frac{1}{N \times \lambda} \sum_{t \in \mathcal{S}_{low}} \left( \frac{High_t}{Low_t} - 1 \right)

V(\lambda) = V_{high}(\lambda) - V_{low}(\lambda)

High_t

Low_t

\mathcal{S}_{high}

\mathcal{S}_{low}

\lambda

参数说明：，High_t 表示第 t 个交易日的最高价，Low_t 表示第 t 个交易日的最低价。该公式计算了第 t 个交易日的相对价格波动幅度。 价格分位差振幅因子基于股价将振幅因子进行切割，旨在捕获股票在不同价格区间内的波动率分布信息。高价振幅因子通常具有更强的负向选股能力，表明在高价位区间股票的振幅可能预示着后续的回调风险。通过计算高低价格区间振幅的差异，该因子可以提供更具区分度的选股信号。该因子假设在不同的价格区间，股票的波动率行为存在差异，这种差异可以被用来辅助股票的选择和风险管理。相比直接使用总体的振幅，该因子更能反映特定价格区间下的波动特征，因此可能具有更强的选股能力。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors价格分位差振幅因子波动率因子因子公式每日振幅:HightLowt−1 \frac{High_t}{Low_t} - 1 Lowt​Hight​​−1其中，High_t 表示第 t 个交易日的最高价，Low_t 表示第 t 个交易日的最低价。该公式计算了第 t 个交易日的相对价格波动幅度。高价振幅因子:Vhigh(λ)=1N×λ∑t∈Shigh(HightLowt−1) V_{high}(\lambda) = \frac{1}{N \times \lambda} \sum_{t \in \mathcal{S}_{high}} \left( \frac{High_t}{Low_t} - 1 \right) Vhigh​(λ)=N×λ1​t∈Shigh​∑​(Lowt​Hight​​−1)其中，$\mathcal{S}_{high}$ 代表收盘价最高的 N * λ 个交易日的集合；High_t 和 Low_t 分别代表第 t 个交易日的最高价和最低价；N 代表回溯的交易日总数；λ 代表选取的收盘价较高（较低）的交易日比例，默认值为 0.25。低价振幅因子:Vlow(λ)=1N×λ∑t∈Slow(HightLowt−1) V_{low}(\lambda) = \frac{1}{N \times \lambda} \sum_{t \in \mathcal{S}_{low}} \left( \frac{High_t}{Low_t} - 1 \right) Vlow​(λ)=N×λ1​t∈Slow​∑​(Lowt​Hight​​−1)其中，$\mathcal{S}_{low}$ 代表收盘价最低的 N * λ 个交易日的集合；High_t 和 Low_t 分别代表第 t 个交易日的最高价和最低价；N 代表回溯的交易日总数；λ 代表选取的收盘价较高（较低）的交易日比例，默认值为 0.25。价格分位差振幅因子:V(λ)=Vhigh(λ)−Vlow(λ) V(\lambda) = V_{high}(\lambda) - V_{low}(\lambda) V(λ)=Vhigh​(λ)−Vlow​(λ)该公式计算了高价振幅因子与低价振幅因子的差值，反映了高低价格区间振幅的差异。此因子通过计算高低价格区间振幅的差异，旨在捕捉市场在高低价格区间的波动率差异。$\lambda$ 参数控制用于计算高低价振幅的样本数量。较高的$\lambda$ 值将使用更多的交易日进行平均，反之亦然。HightHigh_tHight​:第 t 个交易日的最高价LowtLow_tLowt​:第 t 个交易日的最低价NNN:回溯的交易日总数Shigh\mathcal{S}_{high}Shigh​:收盘价最高的 N * λ 个交易日的集合Slow\mathcal{S}_{low}Slow​:收盘价最低的 N * λ 个交易日的集合λ\lambdaλ:选取的收盘价较高（较低）的交易日比例因子解释价格分位差振幅因子基于股价将振幅因子进行切割，旨在捕获股票在不同价格区间内的波动率分布信息。高价振幅因子通常具有更强的负向选股能力，表明在高价位区间股票的振幅可能预示着后续的回调风险。通过计算高低价格区间振幅的差异，该因子可以提供更具区分度的选股信号。该因子假设在不同的价格区间，股票的波动率行为存在差异，这种差异可以被用来辅助股票的选择和风险管理。相比直接使用总体的振幅，该因子更能反映特定价格区间下的波动特征，因此可能具有更强的选股能力。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学...  
DSL公式: /High_tLow_t - 1
V_high(\lambda) = /1N * \lambda SUM_t \in \mathcalS_high ( /High_tLow_t - 1 )
V_low(\lambda) = /1N * \lambda SUM_t \in \mathcalS_low ( /High_tLow_t - 1 )
V(\lambda) = V_high(\lambda) - V_low(\lambda)
High_t
Low_t
\mathcalS_high
\mathcalS_low
\lambda  
描述: 其中，High_t 表示第 t 个交易日的最高价，Low_t 表示第 t 个交易日的最低价。该公式计算了第 t 个交易日的相对价格波动幅度。 价格分位差振幅因子基于股价将振幅因子进行切割，旨在捕获股票在不同价格区间内的波动率分布信息。高价振幅因子通常具有更强的负向选股能力，表明在高价位区间股票的振幅可能预示着后续的回调风险。通过计算高低价格区间振幅的差异，该因子可以提供更具区分度的选股信号。该因子...
因子类型: : 波动率指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/volatility/ideal-amplitude-factor
