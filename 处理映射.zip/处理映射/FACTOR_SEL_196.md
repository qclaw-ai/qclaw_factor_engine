# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_196  
因子名称: Amihud 非流动性指标  
分类: : 流动性指标  
标签: : 流动性, amihud, 流动性指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: ILLIQ_{i,t} = \frac{1}{D_t} \sum_{d=1}^{D_t} \frac{|R_{i,d}|}{VOLD_{i,d}}

ILLIQ_{i,t}

R_{i,d}

VOLD_{i,d}

D_t

参数说明：ILLIQi：,tILLIQ_{i,t}ILLIQi,t​:为股票i在t月的Amihud非流动性指标。Ri,dR_{i,d}Ri,d​:为股票i在t月内第d个交易日的收益率。VOLDi,dVOLD_{i,d}VOLDi,d​:为股票i在t月内第d个交易日的成交额 (通常以货币单位表示)。DtD_tDt​:为t月内股票i的有效交易日总数。通常要求月内有效交易日天数不少于15天。因子解释Amihud 非流动性指标旨在捕捉市场冲击成本，即单位交易量引起的资产价格变动。该指标基于一个核心假设：流动性较差的资产，其价格对交易量的波动更为敏感。因此，该指标数值越高，意味着资产的价格变动需要更大的交易量推动，反映出更高的流动性风险，投资者会要求更高的预期回报作为风险补偿，从而产生流动性溢价。该指标常被用于量化投资中的风险建模和选股策略。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Amihud, Yakov. (2002). Illiquidity and stock returns: Cross-section and time-series effects. Journal of Financial Markets 5, 31-56Related Factors Amihud非流动性冲击因子 非流动性变异系数 条件流动性冲击因子 负收益成交额加权非流动性因子 平均月度成交额 高频波动率路径长度加权非流动性因子 成交额波动率 流动性调整成交量零值天数比率 资金流量累积指标 (Accumulation/Distribution Line, A/D) ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 Related Factors Amihud非流动性冲击因子 非流动性变异系数 条件流动性冲击因子 负收益成交额加权非流动性因子 平均月度成交额 高频波动率路径长度加权非流动性因子 成交额波动率 流动性调整成交量零值天数比率 资金流量累积指标 (Accumulation/Distribution Line, A/D) 因子公式Amihud 非流动性指标 (ILLIQ):ILLIQi,t=1Dt∑d=1Dt∣Ri,d∣VOLDi,d ILLIQ_{i,t} = \frac{1}{D_t} \sum_{d=1}^{D_t} \frac{|R_{i,d}|}{VOLD_{i,d}} ILLIQi,t​=Dt​1​d=1∑Dt​​VOLDi,d​∣Ri,d​∣​其中：ILLIQi,tILLIQ_{i,t}ILLIQi,t​:为股票i在t月的Amihud非流动性指标。Ri,dR_{i,d}Ri,d​:为股票i在t月内第d个交易日的收益率。VOLDi,dVOLD_{i,d}VOLDi,d​:为股票i在t月内第d个交易日的成交额 (通常以货币单位表示)。DtD_tDt​:为t月内股票i的有效交易日总数。通常要求月内有效交易日天数不少于15天。 ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子仅供教育和研究目的，不构成投资建议。•在做出任何投资决策之前，请咨询合格的财务顾问。 因子解释Amihud 非流动性指标旨在捕捉市场冲击成本，即单位交易量引起的资产价格变动。该指标基于一个核心假设：流动性较差的资产，其价格对交易量的波动更为敏感。因此，该指标数值越高，意味着资产的价格变动需要更大的交易量推动，反映出更高的流动性风险，投资者会要求更高的预期回报作为风险补偿，从而产生流动性溢价。该指标常被用于量化投资中的风险建模和选股策略。 A...  
DSL公式: ILLIQ_i,t = /1D_t SUM_d=1**D_t /|R_i,d|VOLD_i,d
ILLIQ_i,t
R_i,d
VOLD_i,d
D_t  
描述: Amihud非流动性冲击因子 非流动性变异系数 条件流动性冲击因子 负收益成交额加权非流动性因子 平均月度成交额 高频波动率路径长度加权非流动性因子 成交额波动率 流动性调整成交量零值天数比率 资金流量累积指标 (Accumulation/Distribution Line, A/D) Factors DirectoryQuantitative Trading FactorsAmihud 非流动性...
因子类型: : 流动性指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/liquidity/amihud-illiquidity
