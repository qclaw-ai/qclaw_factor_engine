# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_054  
因子名称: 条件风险价值 (CVaR)  
分类: : 波动率指标  
标签: : cvar, 流动性, 质量, 条件风险价值, 动量, 成长, 价值, 量化交易  
原始公式: CVaR_{\alpha} = \frac{1}{\alpha} \int_{0}^{\alpha} VaR_p(X) dp

CVaR_{\alpha} = E[X | X \leq VaR_{\alpha}]

\alpha

VaR_p(X)

E[X | X \leq VaR_{\alpha}]

参数说明：α\alphaα:置信水平，表示我们关注损失超过VaR的概率，通常取值较高，如0.05、0.01等。例如，当 α = 0.05 时，表示在 5% 的最坏情况下，资产组合损失的平均期望值。注意，这里 α 通常表示的是损失尾部的概率，因此在公式中，α通常是较小的数值。VaRp(X)VaR_p(X)VaRp​(X):在概率 p 下，资产组合 X 的风险价值 VaR。VaR_p(X) 表示资产组合 X 的损失在概率 p 下的上限。  即在置信水平为 (1-p) 时，资产组合的最大损失额。XXX:资产组合的损失（或收益的负值），这里需要注意的是，损失通常定义为负值，所以当X小于等于VaR时，代表更大的损失E[X∣X≤VaRα]E[X | X \leq VaR_{\alpha}]E[X∣X≤VaRα​]:资产组合损失 X 在损失小于等于 VaR_{\alpha}  时的条件期望。即在损失已经超出VaR_{α} 的条件下，损失 X 的平均期望值。 Related Factors 风险价值 (Value at Risk - VaR) 系统性风险暴露 (Market Beta) 下行风险贝塔 下行/上行波动率比率 下尾风险贝塔 估值偏离度(误差修正模型) 特异性收益波动因子 盈余波动率因子 (Earnings Volatility Factor) 残差市值偏离度 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。R. T. Rockafellar, S. Uryasev. (2000). Optimization of conditional value-at-risk. Journal of Risk 条件风险价值（基于VaR积分）公式:CVaRα=1α∫0αVaRp(X)dp CVaR_{\alpha} = \frac{1}{\alpha} \int_{0}^{\alpha} VaR_p(X) dp CVaRα​=α1​∫0α​VaRp​(X)dp ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 Factors DirectoryQuantitative Trading Factors条件风险价值 (CVaR)波动率因子因子公式条件风险价值（基于VaR积分）公式:CVaRα=1α∫0αVaRp(X)dp CVaR_{\alpha} = \frac{1}{\alpha} \int_{0}^{\alpha} VaR_p(X) dp CVaRα​=α1​∫0α​VaRp​(X)dp条件风险价值（基于条件期望）公式:CVaRα=E[X∣X≤VaRα] CVaR_{\alpha} = E[X | X \leq VaR_{\alpha}] CVaRα​=E[X∣X≤VaRα​]其中：α\alphaα:置信水平，表示我们关注损失超过VaR的概率，通常取值较高，如0.05、0.01等。例如，当 α = 0.05 时，表示在 5% 的最坏情况下，资产组合损失的平均期望值。注意，这里 α 通常表示的是损失尾部的概率，因此在公式中，α通常是较小的数值。VaRp(X)VaR_p(X)VaRp​(X):在概率 p 下，资产组合 X 的风险价值 VaR。VaR_p(X) 表示资产组合 X 的损失在概率 p 下的上限。  即在置信水平为 (1-p) 时，资产组合的最大损失额...  
DSL公式: CVaR_alpha = /1alpha \int_0**alpha VaR_p(X) dp
CVaR_alpha = E[X | X <= VaR_alpha]
alpha
VaR_p(X)
E[X | X <= VaR_alpha]  
描述: 条件风险价值（基于条件期望）公式:CVaRα=E[X∣X≤VaRα] CVaR_{\alpha} = E[X | X \leq VaR_{\alpha}] CVaRα​=E[X∣X≤VaRα​] 因子解释条件风险价值 (CVaR)  是在给定置信水平 α 下，当损失超过风险价值 (VaR) 时，损失的平均期望值。CVaR 能够更全面地度量风险，因为其不仅考虑了损失超出VaR的可能性，还考虑了超出V...
因子类型: : 波动率指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/volatility/conditional-value-at-risk
