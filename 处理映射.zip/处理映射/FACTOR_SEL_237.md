# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_237  
因子名称: 时间加权平均相对价格位置  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 动量, 成长, 价值, 量化交易, 时间加权平均相对价格位置  
原始公式: RPP_{i,t} = \frac{P_{i,t} - L_i}{H_i - L_i}

ARPP_{i,T} = \frac{\int_0^T P_{i,t} dt - L_i T}{(H_i - L_i)T}  = \frac{TWAP_{i,[0,T]} - L_i}{H_i - L_i}

RPP_{i,t}

H_i

L_i

P_{i,t}

TWAP_{i,[0,T]}

参数说明：RPPi：,tRPP_{i,t}RPPi,t​:表示股票 i 在时间 t 的相对价格位置。其值介于 0 到 1 之间，0 表示价格处于区间最低点，1 表示价格处于区间最高点。HiH_iHi​:表示在指定时间区间内，股票 i 的最高价格。LiL_iLi​:表示在指定时间区间内，股票 i 的最低价格。Pi,tP_{i,t}Pi,t​:表示股票 i 在时间 t 的价格。TWAPi,[0,T]TWAP_{i,[0,T]}TWAPi,[0,T]​:表示股票 i 在时间区间 [0,T] 内的时间加权平均价格 (Time-Weighted Average Price)。$TWAP_{i,[0,T]} = \frac{\int_0^T P_{i,t} dt}{T}$，可以通过分钟级别或更小的时间粒度价格数据计算，例如可以取每分钟的开高低收的均价，然后在区间[0,T]内计算均值。TTT:表示计算时间加权平均价格的时间区间长度。因子解释该因子衡量股票在指定时间区间内，其价格相对于区间最高价和最低价的相对位置的时间加权平均值。$ARPP_{i,T}$ 取值范围在0到1之间，如果股票价格大部分时间都接近区间高点，则因子值接近1；反之，如果股票价格大部分时间都接近区间低点，则因子值接近0。 该因子可以用于识别股票的强势或弱势：因子值较高通常意味着股票在区间内表现强势，可能处于上升趋势中；因子值较低则可能意味着股票在区间内表现弱势，可能处于下跌趋势中。 该因子属于动量因子，可以反应股票在一段时间内的价格动量。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。朱剑涛. (2020). 基于时间尺度度量的日内买卖压力. 东方证券Related Factors 相对组合对数价差偏离度 多周期标准化移动平均动量因子 多时域移动平均动量因子 分析师预期收益率加权平均因子 双向价格差分自相关性标准化因子 分析师共识覆盖加权动量 大单成交量价动量 20日区间收益率动量/反转因子 机构活跃度因子 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors时间加权平均相对价格位置技术因子因子公式相对价格位置 $RPP_{i,t}$:RPPi,t=Pi,t−LiHi−Li RPP_{i,t} = \frac{P_{i,t} - L_i}{H_i - L_i} RPPi,t​=Hi​−Li​Pi,t​−Li​​时间加权平均相对价格位置 $ARPP_{i,T}$:ARPPi,T=∫0TPi,tdt−LiT(Hi−Li)T=TWAPi,[0,T]−LiHi−Li ARPP_{i,T} = \frac{\int_0^T P_{i,t} dt - L_i T}{(H_i - L_i)T}  = \frac{TWAP_{i,[0,T]} - L_i}{H_i - L_i} ARPPi,T​=(Hi​−Li​)T∫0T​Pi,t​dt−Li​T​=Hi​−Li​TWAPi,[0,T]​−Li​​其中:RPPi,tRPP_{i,t}RPPi,t​:表示股票 i 在时间 t 的相对价格位置。其值介于 0 到 1 之间，0 表示价格处于区间最低点，1 表示价格处于区间最高点。HiH_iHi​:表示在指定时间区间内，股票 i 的最高价格。LiL_iLi​:表示在指定时间区间内，股票 i 的最低价格。Pi,tP_{i,t}Pi,t​:表示股票 i 在时间 t 的价格。TWAPi,[0,T]TWAP_{i,[0,T]}TWAPi,[0,T]​:表示股票 ...  
DSL公式: RPP_i,t = /P_i,t - L_iH_i - L_i
ARPP_i,T = /\int_0**T P_i,t dt - L_i T(H_i - L_i)T = /TWAP_i,[0,T] - L_iH_i - L_i
RPP_i,t
H_i
L_i
P_i,t
TWAP_i,[0,T]  
描述: 时间加权平均相对价格位置技术因子因子公式相对价格位置 $RPP_{i,t}$:RPPi,t=Pi,t−LiHi−Li RPP_{i,t} = \frac{P_{i,t} - L_i}{H_i - L_i} RPPi,t​=Hi​−Li​Pi,t​−Li​​时间加权平均相对价格位置 $ARPP_{i,T}$:ARPPi,T=∫0TPi,tdt−LiT(Hi−Li)T=TWAPi,[0,T]−LiHi...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/time-weighted-average-stock-relative-price-position
