# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_209  
因子名称: 年度总负债对数增长率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 年度总负债对数增长率, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \ln\left( \frac{TotalDebt_{t}}{TotalDebt_{t-1}} \right)

TotalDebt_{t}

TotalDebt_{t-1}

\ln  
DSL公式: LN( /TotalDebt_tTotalDebt_t-1 )
TotalDebt_t
TotalDebt_t-1
LN  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Lyandres, Evgeny, Le Sun, and Lu Zhang. (2008). The new issues puzzle: Testing the investment-based explanation. Review of Financial Studies 21, 2825-2855. 年度总负债对数增长率基础...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/comprehensive-debt-issuance
