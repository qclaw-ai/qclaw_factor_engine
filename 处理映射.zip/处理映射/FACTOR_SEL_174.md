# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_174  
因子名称: 销售净利率 (Net Profit Margin)  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, net, 质量, 动量, 成长, 规模, 价值  
原始公式: 销售净利率 = \frac{归属于母公司股东的净利润(TTM)}{营业总收入(TTM)}

归属于母公司股东的净利润(TTM)

营业总收入(TTM)  
DSL公式: 销售净利率 = /归属于母公司股东的净利润(TTM)营业总收入(TTM)
归属于母公司股东的净利润(TTM)
营业总收入(TTM)  
描述: 注：该指标通常使用滚动12个月（Trailing Twelve Months, TTM）的数据进行计算，以消除季节性波动的影响，更准确地反映企业真实的盈利能力。 Factors DirectoryQuantitative Trading Factors销售净利率基础面因子因子公式归属于母公司股东的最近12个月净利润 (TTM)最近12个月营业总收入 (TTM)销售净利率销售净利率=归属于母公司股东...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/profit-margin
