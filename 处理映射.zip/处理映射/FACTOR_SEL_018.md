# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_018  
因子名称: 成交量能量潮指标 (On-Balance Volume)  
分类: : 技术指标  
标签: : 流动性, 技术指标, 成交量能量潮指标, 质量, 动量, 成长, volume, 价值  
原始公式: OBV_t = OBV_{t-1} +  \begin{cases}  VOL_t &  \text{if } CLOSE_t > CLOSE_{t-1} \\ -VOL_t & \text{if } CLOSE_t < CLOSE_{t-1} \\ 0 & \text{if } CLOSE_t = CLOSE_{t-1} \end{cases}

OBV_0 = 0

OBV_t

OBV_{t-1}

VOL_t

CLOSE_t

CLOSE_{t-1}  
DSL公式: OBV_t = OBV_t-1 + \begincases VOL_t & \textif CLOSE_t > CLOSE_t-1 \\ -VOL_t & \textif CLOSE_t < CLOSE_t-1 \\ 0 & \textif CLOSE_t = CLOSE_t-1 \endcases
OBV_0 = 0
OBV_t
OBV_t-1
VOL_t
CLOSE_t
CLOSE_t-1  
描述: OBV 计算公式:OBVt=OBVt−1+{VOLtif CLOSEt>CLOSEt−1−VOLtif CLOSEt<CLOSEt−10if CLOSEt=CLOSEt−1 OBV_t = OBV_{t-1} +  \begin{cases}  VOL_t &  \text{if } CLOSE_t > CLOSE_{t-1} \\ -VOL_t & \text{if } CLOSE_t < CL...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/energy-metrics
