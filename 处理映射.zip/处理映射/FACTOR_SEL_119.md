# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_119  
因子名称: 日内强度指标 (Intraday Momentum Index, IMI)  
分类: : 技术指标  
标签: : 流动性, 技术指标, intraday, index, 日内强度指标, 技术分析, 质量, 动量  
原始公式: USUM(N) = \sum_{i=1}^{N} \max(CLOSE_i-OPEN_i, 0)

DSUM(N) = \sum_{i=1}^{N} \max(OPEN_i-CLOSE_i, 0)

IMI(N) = \frac{USUM(N)}{USUM(N)+DSUM(N)}*100

CLOSE_i

OPEN_i

max(a,b)

参数说明：NNN：计算的时间窗口大小，表示用于计算 USUM 和 DSUM 的交易日数量或时间周期。CLOSEiCLOSE_iCLOSEi​:第 i 个交易日的收盘价。OPENiOPEN_iOPENi​:第 i 个交易日的开盘价。max(a,b)max(a,b)max(a,b):取最大值函数，返回a和b中较大的值。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 因子公式USUM(N) =USUM(N)=∑i=1Nmax⁡(CLOSEi−OPENi,0) USUM(N) = \sum_{i=1}^{N} \max(CLOSE_i-OPEN_i, 0) USUM(N)=i=1∑N​max(CLOSEi​−OPENi​,0)DSUM(N) =DSUM(N)=∑i=1Nmax⁡(OPENi−CLOSEi,0) DSUM(N) = \sum_{i=1}^{N} \max(OPEN_i-CLOSE_i, 0) DSUM(N)=i=1∑N​max(OPENi​−CLOSEi​,0)IMI(N) =IMI(N)=USUM(N)USUM(N)+DSUM(N)∗100 IMI(N) = \frac{USUM(N)}{USUM(N)+DSUM(N)}*100 IMI(N)=USUM(N)+DSUM(N)USUM(N)​∗100其中：NNN:计算的时间窗口大小，表示用于计算 USUM 和 DSUM 的交易日数量或时间周期。CLOSEiCLOSE_iCLOSEi​:第 i 个交易日的收盘价。OPENiOPEN_iOPENi​:第 i 个交易日的开盘价。max(a,b)max(a,b)max(a,b):取最大值函数，返回a和b中较大的值。 日内强度指标技术因子因子公式USUM(N) =USUM(N)=∑i=1Nmax⁡(CLOSEi−OPENi,0) USUM(N) = \sum_{i=1}^{N} \max(CLOSE_i-OPEN_i, 0) USUM(N)=i=1∑N​max(CLOSEi​−OPENi​,0)DSUM(N) =DSUM(N)=∑i=1Nmax⁡(OPENi−CLOSEi,0) DSUM(N)...  
DSL公式: USUM(N) = SUM_i=1**N MAX(CLOSE_i-OPEN_i, 0)
DSUM(N) = SUM_i=1**N MAX(OPEN_i-CLOSE_i, 0)
IMI(N) = /USUM(N)USUM(N)+DSUM(N)*100
CLOSE_i
OPEN_i
max(a,b)  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。John Murphy. (1999). 技术分析. NYIF Related Factors 动态趋向指标 随机动量指标 (SMI) 相对强弱指标 (RSI) 累计振荡指标 相对强弱指标 (Relative Strength Index) 区域强度指数 方向性动量离散指标 (Directional Momentum Dispersi...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/intraday-momentum
