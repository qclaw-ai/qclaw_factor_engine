# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_319  
因子名称: 账面市值比 (Book-to-Market Ratio)  
分类: : 价值指标  
标签: : 流动性, 账面市值比, ratio, market, 质量, 动量, 成长, 价值  
原始公式:   
DSL公式:   
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors账面市值比 (B/M)价值因子因子公式账面市值比是公司账面价值与其市场价值的比率。账面价值通常指的是股东权益总额，代表公司在会计上的净资产...
因子类型: : 价值指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/value/book-to-market-ratio
