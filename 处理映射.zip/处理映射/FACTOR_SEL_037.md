# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_037  
因子名称: 双向价格差分自相关性标准化因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 动量, 成长, 规模, 价值, 量化交易  
原始公式: CDPDP = \frac{CorrPos - mean(CorrPos)}{std(CorrPos)} + \frac{CorrNeg - mean(CorrNeg)}{std(CorrNeg)}

\Delta P_t

CorrPos

CorrNeg

mean()

std()

参数说明：$P_t$ 为t时刻的价格。 该因子逻辑基于价格的均值回归特性，并利用双序列差分的方式增强其捕捉反转信号的能力。当股票价格连续出现同方向变动时，该因子的取值会较高，反之则较低。通过标准化处理，确保因子在不同股票之间具有可比性。因此，因子值较低的股票，表示价格变动方向可能发生反转，通常被认为是潜在的买入机会，反之则可能是卖出机会。该因子与单序列差分自相关因子具有类似的逻辑，但通过分别计算正向和负向的价格差分自相关性，增强了对价格变动方向反转的捕捉能力。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors双向价格差分自相关性标准化因子技术因子因子公式CDPDP:CDPDP=CorrPos−mean(CorrPos)std(CorrPos)+CorrNeg−mean(CorrNeg)std(CorrNeg) CDPDP = \frac{CorrPos - mean(CorrPos)}{std(CorrPos)} + \frac{CorrNeg - mean(CorrNeg)}{std(CorrNeg)} CDPDP=std(CorrPos)CorrPos−mean(CorrPos)​+std(CorrNeg)CorrNeg−mean(CorrNeg)​其中:ΔPt\Delta P_tΔPt​:第t个时间点的价格一阶差分，计算公式为 $\Delta P_t = P_t - P_{t-1}$，其中 $P_t$ 为t时刻的价格。CorrPosCorrPosCorrPos:正向价格差分自相关性，表示在价格差分大于零的情况下（即 $\Delta P_t > 0$ ），取 $\Delta P_t$ 和 $\Delta P_{t+1}$ 构成的序列的20日相关系数的平均值。该值衡量了价格上涨的持续性。CorrNegCorrNegCorrNeg:负向价格差分自相关性，表示在价格差分小于零的情况下（即 $\Delta P_t < 0$），取 $\Delta P_t$ 和 $\Delta P_{t+1}$构成的序列的20日相关系数的平均值。该值衡量了价格下跌的持续性。mean()mean()mean():表示求取平均值操作，用于计算正向和负向自相关性的均值。std()std()std():表示求取标准差操作，用于计算正向和负向自相关性的标准差，进行标准化处理。因子解释该因子逻辑基于价格的均值回归特性，并利用双序列差分的方式增强其捕捉反转信号的能力。当股票价格连续出现同方向变动时，该因子的取值会较高，反之则较低。通过标准化处理，确保因子在不同股票之间具有可比性。因此，因子值较低的股票，表示价格变动方向可能发生反转，通常被认为是潜在的买入机会，反之则可能是卖出机会。该因子与单序列差分自相关因子具有类似的逻辑，但通过分别计算正向和负向的价格差分自相关性，增强了对价格变动方向反转的捕捉能力。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。高子剑. (2021). CPV因子移位版,价量自相关性中蕴藏的选股信息. 东吴证券Related Factors 相对组合对数价差偏离度 二阶动量加速度因子 20日区间收益率动量/反转...  
DSL公式: CDPDP = /CorrPos - mean(CorrPos)std(CorrPos) + /CorrNeg - mean(CorrNeg)std(CorrNeg)
\Delta P_t
CorrPos
CorrNeg
mean()
std()  
描述: 相对组合对数价差偏离度 二阶动量加速度因子 20日区间收益率动量/反转因子 散户同步性因子 高频价量相关性趋势因子 收益动量一致性因子 多周期标准化移动平均动量因子 主力成交额-价格相关性因子 Fama-French三因子模型残差动量 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。高子剑. (2021). CPV因子移位版,价量自相关性中蕴藏的选股信息. 东吴证券 ⚠️ 因子风险...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/price-auto-correlation
