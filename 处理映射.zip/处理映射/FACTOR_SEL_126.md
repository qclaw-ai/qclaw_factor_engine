# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_126  
因子名称: 主动成交额净额比率  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 主动成交额净额比率, 动量, 成长, 价值, 量化交易  
原始公式: ACT_{Large+Mid,t} = \frac{主动买入金额_{Large+Mid,t} - 主动卖出金额_{Large+Mid,t}}{主动买入金额_{Large+Mid,t} + 主动卖出金额_{Large+Mid,t}}

ACT_{Small,t} = \frac{主动买入金额_{Small,t} - 主动卖出金额_{Small,t}}{主动买入金额_{Small,t} + 主动卖出金额_{Small,t}}

ACT_{Large+Mid,t}

主动买入金额_{Large+Mid,t}

主动卖出金额_{Large+Mid,t}

ACT_{Small,t}

主动买入金额_{Small,t}

主动卖出金额_{Small,t}

参数说明：ACTLarge：+Mid,tACT_{Large+Mid,t}ACTLarge+Mid,t​:t日大中单主动成交额净额比率主动买入金额Large+Mid,t主动买入金额_{Large+Mid,t}主动买入金额Large+Mid,t​:t日大中单主动买入总金额主动卖出金额Large+Mid,t主动卖出金额_{Large+Mid,t}主动卖出金额Large+Mid,t​:t日大中单主动卖出总金额ACTSmall,tACT_{Small,t}ACTSmall,t​:t日小单主动成交额净额比率主动买入金额Small,t主动买入金额_{Small,t}主动买入金额Small,t​:t日小单主动买入总金额主动卖出金额Small,t主动卖出金额_{Small,t}主动卖出金额Small,t​:t日小单主动卖出总金额因子解释主动成交额净额比率因子通过区分大中单和小单的交易行为，更细致地刻画了不同规模交易者在市场上的主动交易意愿。该因子假设大中单交易者通常被认为是机构投资者或高净值投资者，其交易行为往往反映了更为专业的市场观点和策略；而小单交易者则可能代表散户投资者，其行为可能受市场情绪的影响更大。实证研究表明，大中单主动成交额净额比率在股票高收益区间可能呈现正向选股效应，表明当大中单呈现净买入时，股票收益率可能更高；反之，小单主动成交额净额比率在股票低收益区间可能呈现负向选股效应，即小单呈现净卖出时，股票收益率可能较低。因此，该因子可用于捕捉不同规模交易者之间的行为差异，并在量化选股策略中发挥作用，...  
DSL公式: ACT_Large+Mid,t = /主动买入金额_Large+Mid,t - 主动卖出金额_Large+Mid,t主动买入金额_Large+Mid,t + 主动卖出金额_Large+Mid,t
ACT_Small,t = /主动买入金额_Small,t - 主动卖出金额_Small,t主动买入金额_Small,t + 主动卖出金额_Small,t
ACT_Large+Mid,t
主动买入金额_Large+Mid,t
主动卖出金额_Large+Mid,t
ACT_Small,t
主动买入金额_Small,t
主动卖出金额_Small,t  
描述: 因子解释主动成交额净额比率因子通过区分大中单和小单的交易行为，更细致地刻画了不同规模交易者在市场上的主动交易意愿。该因子假设大中单交易者通常被认为是机构投资者或高净值投资者，其交易行为往往反映了更为专业的市场观点和策略；而小单交易者则可能代表散户投资者，其行为可能受市场情绪的影响更大。实证研究表明，大中单主动成交额净额比率在股票高收益区间可能呈现正向选股效应，表明当大中单呈现净买入时，股票收益率可...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/active-trading-factor
