# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_308  
因子名称: 分析师目标价隐含收益率  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 质量, 动量, 成长, 规模, 价值, 量化交易  
原始公式: \frac{P_{target}}{P_{current}} - 1

P_{target}

P_{current}  
DSL公式: /P_targetP_current - 1
P_target
P_current  
描述: 一致预期收益率 (Consensus Target Price Return) 分析师目标价调整动量因子 分析师预期收益率加权平均因子 分析师一致预期EPS修正比率 分析师一致预期市盈率倒数 一致预期PEG比率 分析师预期EPS调整幅度 预期市盈率调整幅度 52周最高价逼近度 分析师目标价隐含收益率情绪因子因子公式分析师目标价隐含收益率:PtargetPcurrent−1 \frac{P_{tar...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/target-price-implied-return
