# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_137  
因子名称: 行业日内隔夜动量因子  
分类: : 动量指标  
标签: : 流动性, 质量, 动量, 成长, 价值, 量化交易, 动量指标, 规模  
原始公式: R_{intraday,t} = \frac{Close_t}{Open_t} - 1

R_{overnight,t} = \frac{Open_t}{Close_{t-1}} - 1

IntradayMomentum = \sum_{i=1}^{20} R_{intraday,t-i+1}

OvernightMomentum = \sum_{i=1}^{20} R_{overnight,t-i+1}

R_{intraday,t}

R_{overnight,t}

Close_t

Open_t

Close_{t-1}

IntradayMomentum

参数说明：Rintraday：,tR_{intraday,t}Rintraday,t​:第t个交易日的日内收益率，表示该交易日收盘价相对于开盘价的变动幅度。Rovernight,tR_{overnight,t}Rovernight,t​:第t个交易日的隔夜收益率，表示该交易日开盘价相对于前一交易日收盘价的变动幅度。ClosetClose_tCloset​:第t个交易日的收盘价格，是该交易日最后成交的价格。OpentOpen_tOpent​:第t个交易日的开盘价格，是该交易日最早成交的价格。Closet−1Close_{t-1}Closet−1​:第t-1个交易日的收盘价格，即上一个交易日的最后成交价格。IntradayMomentumIntradayMomentumIntradayMomentum:日内动量因子，是过去20个交易日日内收益率的加总。OvernightMomentumOvernightMomentumOvernightMomentum:隔夜动量因子，是过去20个交易日隔夜收益率的加总。 实证研究表明，日内动量因子倾向于呈现动量效应，即因子值较高的行业在未来短期内更有可能获得超额收益，反之亦然。这反映了市场参与者在日内交易中可能存在的追涨杀跌行为。而隔夜动量因子则倾向于呈现反转效应，即因子值较高的行业在未来短期内更有可能表现较差，这可能与市场对隔夜消息的反应以及开盘价的调整有关。因此，在构建投资组合时，可以考虑综合利用这两个因子的特性，进行多空策略的构建，以提高投资组合的风险调整收益。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。魏建榕. (2020). A股行业动量的精细结构. 开源证券Tobias J. Moskowitz, Mark Grinblatt. (1999). Do industries explain momentum?. Journal of Finance 54 (4) 因子公式日内收益率 (Intraday Return):Rintraday,t=ClosetOpent−1 R_{intraday,t} = \frac{Close_t}{Open_t} - 1 Rintraday,t​=Opent​Closet​​−1隔夜收益率 (Overnight Return):Rovernight,t=OpentCloset−1−1 R_{overnight,t} = \frac{Open_t}{Close_{t-1}} - 1 Rovernight,t​=Closet−1​Opent​​−1日内动量因子 (Intraday Momentum Factor):IntradayMomentum=∑i=120Rintraday,t−i+1 IntradayMomentum = \sum_{i=1}^{20} R_{intraday,t-i+1} IntradayMomentum=i=1∑20​Rintraday,t−i+1​隔夜动量因子 (Overnight Momentum Factor):OvernightMomentum=∑i=120Rovernight,t−i+1 OvernightMomentum = \sum_{i=1}^{20} R_{overnight,t-i+1} OvernightMomentum=i=1∑20​Rovernight,t−i+1​其中：Rintraday,tR_{intraday,t}Rintraday,t​:第t个交易日的日内收益率，表示该交易日收盘价相对于开盘价的变动幅度。Rovernight,tR_{overnight,t}Rovernight,t​:第t个交易日的隔夜收益率，表示该交易日开盘价相对于前一交易日收盘价的变动幅度。ClosetClo...  
DSL公式: R_intraday,t = /Close_tOpen_t - 1
R_overnight,t = /Open_tClose_t-1 - 1
IntradayMomentum = SUM_i=1**20 R_intraday,t-i+1
OvernightMomentum = SUM_i=1**20 R_overnight,t-i+1
R_intraday,t
R_overnight,t
Close_t
Open_t
Close_t-1
IntradayMomentum  
描述: Related Factors 日内信息不对称强度因子 20日区间收益率动量/反转因子 日内开盘净委买增额成交额比率 过去K个月累计收益率动量因子 排序动量因子 隔夜新闻情感偏向因子 行业领头羊动量溢价因子 动量加速度因子 中期反转因子 (Medium-Term Reversal Factor) 因子解释实证研究表明，日内动量因子倾向于呈现动量效应，即因子值较高的行业在未来短期内更有可能获得超额收...
因子类型: : 动量指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/momentum/industry-momentum
