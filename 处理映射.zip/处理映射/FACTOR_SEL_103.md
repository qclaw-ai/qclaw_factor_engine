# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_103  
因子名称: 相对强弱指标 (Relative Strength Index)  
分类: : 技术指标  
标签: : 流动性, strength, 技术指标, index, relative, 波动率, 质量, 动量  
原始公式: RS = \frac{\text{Average Gain}}{\text{Average Loss}}

RSI = 100 - \frac{100}{1 + RS}

Average Gain

Average Loss

RSI

参数说明：，平均涨幅 (Average Gain) 和平均跌幅 (Average Loss) 通常采用指数移动平均 (EMA) 或简单移动平均 (SMA) 计算。初始平均值可以用简单的平均值计算，后续的平均值通过移动平均的方式进行更新，以反映近期价格变动的影响。计算相对强弱指标 (RSI):RSI=100−1001+RS RSI = 100 - \frac{100}{1 + RS} RSI=100−1+RS100​相对强弱指标 (RSI) 是通过将相对强度 (RS) 转换为0到100之间的标准化值得到的。这个转换使得指标更容易理解和应用。该公式将RS值映射到一个0到100的区间，使得RSI指标的波动范围更为明确。公式中的关键参数及其解释：AverageGainAverage GainAverageGain:指定周期内价格上涨幅度的平均值。通常用指数移动平均 (EMA) 或简单移动平均 (SMA) 计算。计算时，仅考虑价格上涨的情况，下跌情况按0处理。AverageLossAverage LossAverageLoss:指定周期内价格下跌幅度的平均值。通常用指数移动平均 (EMA) 或简单移动平均 (SMA) 计算。计算时，仅考虑价格下跌的情况，上涨情况按0处理。注意，该值通常是正数，尽管代表的是价格的下跌幅度。RSRSRS:相对强度，是平均涨幅与平均跌幅的比值，反映了价格上涨力量与下跌力量的相对强弱。RSIRSIRSI:相对强弱指标，是标准化后的动量指标，其值介于0到100之间，用于评估价格变动的强度和速度。因子解释RSI 的取值范围在 0 到 100 之间。通常，RSI 值接近 70 或更高时，表示资产可能处于超买状态，即价格可能被高估，存在回调风险；RSI 值接近 30 或更低时，表示资产可能处于超卖状态，即价格可能被低估，存在反弹机会。然而，需要注意的是，RSI 的阈值并非绝对，不同的资产或市场可能会有不同的适用范围。同时，RSI 应该结合其他技术指标和基本面分析一起使用，才能更准确地判断市场趋势和交易机会。需要使用多个样本（多只股票）并进行回测来验证不同参数和阈值设置下该指标的有效性。此外，RSI 的背离现象（价格创新高/低，而RSI指标没有同步创新高/低）也是一个重要的信号，可能预示着趋势的反转。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。Related Factors 相对强弱指标 (RSI) 区域强度指数 成交量相对强度指标 相对波动性指标 相对强弱人气指标 成交量相对强度指标 累计振荡指标 随机动量指标 (SMI) 日内强度指标 (Intraday Momentum Index, IMI) 相对强度 (RS) 是指定周期内所有价格上涨幅度的平均值与所有价格下跌幅度的平均值之比。其中，平均涨幅 (Average Gain) 和平均跌幅 (Average Loss) 通常采用指数移动平均 (EMA) 或简单移动平均 (SMA) 计算。初始平均值可以用简单的平均值计算，后续的平均值通过移动平均的方式进行更新，以反映近期价格变动的影响。 Factors DirectoryQuantitative Trading Factors相对强弱指标 (RSI)技术因子因子公式计算相对强度 (RS):RS=Average GainAverage Loss RS = \frac{\text{Average Gain}}{\text{Average Loss}} RS=Average LossAverage Gain​相对强度 (RS) 是指定周期内所有价格上涨幅度的平均值与所有价格下跌幅度的平均值之比。其中，平均涨幅 (Average Gain) 和平均跌幅 (Average Loss) 通常采用指数移动平均 (EMA) 或简单移动平均 (SMA) 计算。初始平均值可以用简单的平均值计算，后续的平均值通过移动平均的方式进行更新，以反映近期价格变动的影响。计算...  
DSL公式: RS = /\textAverage Gain\textAverage Loss
RSI = 100 - /1001 + RS
Average Gain
Average Loss
RSI  
描述: Related Factors 相对强弱指标 (RSI) 区域强度指数 成交量相对强度指标 相对波动性指标 相对强弱人气指标 成交量相对强度指标 累计振荡指标 随机动量指标 (SMI) 日内强度指标 (Intraday Momentum Index, IMI) 相对强弱指标 (RSI)技术因子因子公式计算相对强度 (RS):RS=Average GainAverage Loss RS = \fra...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/rsi
