# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_102  
因子名称: 区域强度指数  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 动量, 成长, 区域强度指数, 量化交易, 价值  
原始公式: TR = \max(HIGH - LOW, |CLOSE_{t-1} - HIGH|, |CLOSE_{t-1} - LOW|)

W = \begin{cases} \frac{TR}{CLOSE_t - CLOSE_{t-1}} & CLOSE_t > CLOSE_{t-1} \\ TR & CLOSE_t \le CLOSE_{t-1} \end{cases}

SR(N1) = \begin{cases} \frac{W - \min(W_{t-N1+1}, ..., W_t)}{\max(W_{t-N1+1}, ..., W_t) - \min(W_{t-N1+1}, ..., W_t)} \times 100 & \text{if} \; \max(W_{t-N1+1}, ..., W_t) - \min(W_{t-N1+1}, ..., W_t) > 0 \\ (W - \min(W_{t-N1+1}, ..., W_t)) \times 100 & \text{otherwise} \end{cases}

RSI(N1, N2) = EMA(SR(N1), N2)

HIGH

LOW

CLOSE_t

CLOSE_{t-1}

W_{t-N1+1}, ..., W_t

SR(N1)  
DSL公式: TR = MAX(high - low, |CLOSE_t-1 - high|, |CLOSE_t-1 - low|)
W = \begincases /TRCLOSE_t - CLOSE_t-1 & CLOSE_t > CLOSE_t-1 \\ TR & CLOSE_t \le CLOSE_t-1 \endcases
SR(N1) = \begincases /W - MIN(W_t-N1+1, ..., W_t)MAX(W_t-N1+1, ..., W_t) - MIN(W_t-N1+1, ..., W_t) * 100 & \textif \; MAX(W_t-N1+1, ..., W_t) - MIN(W_t-N1+1, ..., W_t) > 0 \\ (W - MIN(W_t-N1+1, ..., W_t)) * 100 & \textotherwise \endcases
RSI(N1, N2) = EMA(SR(N1), N2)
high
low
CLOSE_t
CLOSE_t-1
W_t-N1+1, ..., W_t
SR(N1)  
描述: Related Factors 相对强弱指标 (Relative Strength Index) 相对强弱指标 (RSI) 成交量相对强度指标 相对波动性指标 成交量相对强度指标 相对强弱人气指标 累计振荡指标 随机动量指标 (SMI) 随机摆动指标 公式中：TRTRTR:真实波幅（True Range），衡量当日价格的波动范围，取当日最高价与最低价之差、前一日收盘价与当日最高价之差的绝对值、前一...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/region-index
