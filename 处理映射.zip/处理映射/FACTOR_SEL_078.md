# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_078  
因子名称: 母公司股东权益环比增长率  
分类: : 基本面指标  
标签: : 流动性, 母公司股东权益环比增长率, 基本面指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{EQ_{t} - EQ_{t-1}}{|EQ_{t-1}|}

EQ_t

EQ_{t-1}

|EQ_{t-1}|  
DSL公式: /EQ_t - EQ_t-1|EQ_t-1|
EQ_t
EQ_t-1
|EQ_t-1|  
描述: 单季度净利润同比增速 单季度摊薄净资产收益率同比变动 TTM基本每股收益同比增长率 归母净利润加速增长动量因子 归母净利润同比增长率 单季度经营活动净现金流同比增速 季度同比销售收入增长率 有形资本回报率环比增长率 (TTM) 单季度营业利润同比增速 母公司股东权益环比增长率（Quarter-on-Quarter Growth Rate of Parent Company's Equity）基础面...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/growth-rate-of-shareholders-equity-attributable-to-the-parent-company
