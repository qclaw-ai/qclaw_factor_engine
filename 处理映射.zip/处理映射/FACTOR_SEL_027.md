# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_027  
因子名称: 异同离差乖离率振荡器  
分类: : 技术指标  
标签: : 流动性, 技术指标, 技术分析, 异同离差乖离率振荡器, 质量, 动量, 成长, 价值  
原始公式: BIAS = \frac{CLOSE - SMA(CLOSE, N_1)}{SMA(CLOSE, N_1)}

DIF = BIAS - BIAS[N_2]

DBCD = SMA(DIF, N_3, 1)

SMA(X, N, M) = \frac{X \times M + SMA(X, N, M)' \times (N-M)}{N}

CLOSE

SMA(CLOSE, N_1)

N_1

BIAS

N_2

N_3  
DSL公式: BIAS = /close - SMA(close, N_1)SMA(close, N_1)
DIF = BIAS - BIAS[N_2]
DBCD = SMA(DIF, N_3, 1)
SMA(X, N, M) = /X * M + SMA(X, N, M)' * (N-M)N
close
SMA(close, N_1)
N_1
BIAS
N_2
N_3  
描述: 因子公式BIAS (乖离率):BIAS=CLOSE−SMA(CLOSE,N1)SMA(CLOSE,N1) BIAS = \frac{CLOSE - SMA(CLOSE, N_1)}{SMA(CLOSE, N_1)} BIAS=SMA(CLOSE,N1​)CLOSE−SMA(CLOSE,N1​)​DIF (乖离率差值):DIF=BIAS−BIAS[N2] DIF = BIAS - BIAS[N_2]...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/deviation-rate
