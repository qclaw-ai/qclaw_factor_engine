# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_026  
因子名称: 移动平均汇聚背离指标  
分类: : 技术指标  
标签: : 流动性, 技术指标, 技术分析, 质量, 动量, 成长, 基本面分析, 量化交易  
原始公式: DIF = EMA(CLOSE, N_1) - EMA(CLOSE, N_2)

DEA = EMA(DIF, N_3)

MACD_{Histogram} = 2 * (DIF - DEA)

N_1

N_2

N_3

参数说明：N1N_1N1：​:快线EMA的时间窗口长度，表示计算快速指数移动平均线时所使用的历史数据周期数。通常设置为12，该参数决定了快线对近期价格变化的敏感程度，较小的值意味着对价格变化更敏感。N2N_2N2​:慢线EMA的时间窗口长度，表示计算慢速指数移动平均线时所使用的历史数据周期数。通常设置为26，该参数决定了慢线对价格变化的敏感程度，较大的值意味着对价格变化相对不敏感，主要反映长期趋势。N3N_3N3​:DEA平滑的时间窗口长度，表示对DIF值进行平滑计算时所使用的历史数据周期数。通常设置为9，该参数决定了DEA线对DIF变化的敏感程度，较小的值意味着对DIF的变化更敏感。因子解释MACD指标通过计算快慢两条指数移动平均线（EMA）的差值（DIF），并对该差值进行平滑处理（DEA）来实现对价格动量的分析。；具体来说：  
DSL公式: DIF = EMA(close, N_1) - EMA(close, N_2)
DEA = EMA(DIF, N_3)
MACD_Histogram = 2 * (DIF - DEA)
N_1
N_2
N_3  
描述: Related Factors 成交量异同移动平均线 (VMACD) 异同离差乖离率振荡器 梅斯指数 动态趋向指标 资金流量累积指标 (Accumulation/Distribution Line, A/D) 方向性动量离散指标 (Directional Momentum Dispersion Index) 蔡金资金流量震荡指标 商品通道指数 三重指数移动平均 (TEMA) 重要提示:
MACD指...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/moving-average-convergence-divergence
