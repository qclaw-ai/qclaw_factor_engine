#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
从 selenium_enhanced_factors_data.md 文件中提取每个因子的公式，
并转换为内部DSL，生成每个因子的Markdown文档。

用法：
    python selenium_enhanced_factors_to_md.py
"""

import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple


@dataclass
class RawFactor:
    """原始因子数据"""
    source: str          # 来源标识，如 "selenium_enhanced"
    factor_name: str     # 因子名称
    factor_id: str       # 生成的ID，如 FACTOR_SEL_001
    category: str        # 分类
    tags: List[str]      # 标签
    raw_formula: str     # 原始公式文本（包含解释）
    dsl_formula: str     # 转换后的DSL公式（纯公式）
    description: str     # 简要描述（截取部分）
    url: str             # 来源URL


def project_root() -> Path:
    """返回项目根目录"""
    return Path(__file__).resolve().parents[2]


def get_paths() -> Tuple[Path, Path]:
    """返回输入文件路径和输出目录（均为 Path 对象）"""
    root = project_root()
    input_path = root /"AIagent" / "selenium_enhanced_factors_data_1.md"
    # 输出目录：你指定的路径
    output_dir = Path(r"C:\Users\Tapmeswavk\PycharmProjects\pythonProject1\AIagent\处理映射")
    return input_path, output_dir


def read_file_chunks(input_path: Path) -> List[str]:
    """读取文件并按 '---' 分割，返回因子块列表（跳过文件头）"""
    if not input_path.is_file():
        raise FileNotFoundError(f"文件不存在: {input_path}")

    with input_path.open('r', encoding='utf-8') as f:
        content = f.read()

    blocks = content.split('---')
    factor_blocks = [b.strip() for b in blocks[1:] if b.strip()]
    return factor_blocks


def extract_basic_info(block: str) -> dict:
    """从因子块中提取基本信息，返回字典"""
    info = {
        'name': '',
        'category': '',
        'tags': [],
        'url': '',
        'detail': '',
        'math': ''
    }

    lines = block.split('\n')
    current_section = None

    for line in lines:
        if line.startswith('## '):
            if not info['name']:
                info['name'] = line[3:].strip()
        elif line.startswith('### '):
            section_name = line[4:].strip()
            if '基本信息' in section_name:
                current_section = 'basic'
            elif '详细内容' in section_name:
                current_section = 'detail'
            elif '数学公式' in section_name:
                current_section = 'math'
            else:
                current_section = None
            continue

        if current_section == 'basic':
            if '- **分类**' in line:
                info['category'] = line.split('**')[-1].strip()
            elif '- **标签**' in line:
                tags_part = line.split('**')[-1].strip()
                info['tags'] = [t.strip() for t in tags_part.split(',')]
            elif '- **来源URL**' in line:
                info['url'] = line.split('**')[-1].strip()
        elif current_section == 'detail':
            info['detail'] += line + '\n'
        elif current_section == 'math':
            info['math'] += line + '\n'

    return info


def is_html_content(text: str) -> bool:
    """判断文本是否包含HTML/JS标签，用于过滤无意义的抓取内容"""
    html_patterns = [
        r'<script',
        r'<link',
        r'href=',
        r'src=',
        r'async',
        r'</',
        r'\\"',
        r'background:',
    ]
    for pat in html_patterns:
        if re.search(pat, text, re.IGNORECASE):
            return True
    return False


def extract_raw_formula(math_content: str, detail_content: str) -> Tuple[str, str]:
    """
    从数学公式部分和详细内容中提取原始公式文本。
    返回 (raw_formula_with_explanation, pure_formulas)
    - raw_formula_with_explanation: 包含公式及其解释的完整文本
    - pure_formulas: 所有纯公式的拼接（用于DSL）
    """
    raw_parts = []
    pure_parts = []

    # 1. 首先尝试按 '#### 公式' 分割（支持可能的空格）
    formula_blocks = re.split(r'####\s*公式\s*\d+', math_content)
    if len(formula_blocks) > 1:
        # 第一个块是前面的无关内容，跳过
        for block in formula_blocks[1:]:
            lines = block.strip().split('\n')
            code = ''
            explanation = ''
            in_code = False
            for line in lines:
                if line.startswith('```'):
                    in_code = not in_code
                    continue
                if in_code:
                    code += line + '\n'
                else:
                    if line.strip() and not line.startswith('```'):
                        explanation += line + ' '
            code = code.strip()
            if code:
                pure_parts.append(code)
                explanation = re.sub(r'\s+', ' ', explanation).strip()
                if explanation:
                    raw_parts.append(f"{code}：{explanation}")
                else:
                    raw_parts.append(code)
        # 如果成功解析到纯公式，则进行后续处理
        if pure_parts:
            raw_formula = "\n\n".join(raw_parts) if raw_parts else ""
            pure_formulas = "\n".join(pure_parts)
            # 附加参数说明（如果有）
            param_section = re.search(r'(参数说明|其中)[:：]?\s*(.*?)(?=\n\n|\Z)', detail_content, re.DOTALL)
            if param_section:
                params_text = param_section.group(2).strip()
                param_lines = params_text.split('\n')
                param_desc = []
                for line in param_lines:
                    line = line.strip()
                    if not line:
                        continue
                    m = re.match(r'^([A-Za-z0-9_]+)[:：]?\s*(.*)', line)
                    if m:
                        param_desc.append(f"{m.group(1)}：{m.group(2)}")
                    else:
                        param_desc.append(line)
                if param_desc:
                    raw_formula += "\n\n参数说明：" + "；".join(param_desc)
            return raw_formula, pure_formulas

    # 2. 如果没有 '#### 公式' 标题或解析失败，回退到原有的代码块提取
    code_blocks = re.findall(r'```([^`]+)```', math_content, re.DOTALL)
    for block in code_blocks:
        block = block.strip()
        if is_html_content(block):
            continue
        # 移除 MathML: 或 LaTeX: 前缀
        if block.startswith('MathML:'):
            block = block[7:].strip()
        elif block.startswith('LaTeX:'):
            block = block[6:].strip()
        if block:
            pure_parts.append(block)
            raw_parts.append(block)   # 没有解释，直接使用公式作为原始
    if pure_parts:
        raw_formula = "\n\n".join(raw_parts)
        pure_formulas = "\n".join(pure_parts)
        return raw_formula, pure_formulas

    # 3. 如果仍然没有，尝试从详细内容中提取主公式（保守策略）
    lines = detail_content.split('\n')
    for line in lines:
        line = line.strip()
        if len(line) < 10 or len(line) > 300:
            continue
        if is_html_content(line):
            continue
        if '=' in line and re.search(r'[+\-*/^]', line):
            match = re.search(r'[A-Za-z0-9_()]+\s*=\s*[^;]+', line)
            if match:
                formula = match.group()
                pure_parts.append(formula)
                raw_parts.append(formula)
                break
    if pure_parts:
        raw_formula = "\n\n".join(raw_parts)
        pure_formulas = "\n".join(pure_parts)
        return raw_formula, pure_formulas

    # 4. 实在找不到，返回空
    return "", ""

def to_dsl(expr: str) -> str:
    """
    将原始公式（可能包含 LaTeX 标记）转换为内部 DSL 表达式。
    转换规则：
        - 字段名：CLOSE→close, OPEN→open, HIGH→high, LOW→low, VOLUME→volume, AMOUNT→turnover, VWAP→vwap
        - 函数名：\\frac→/, \\sum→SUM, \\prod→PROD, \\max→MAX, \\min→MIN, \\log→LOG, \\ln→LN, \\sqrt→SQRT
        - 希腊字母：\\alpha→alpha, \\beta→beta 等
        - 上标：^{...} 或 ^c → **...
        - 下标：_{...} 或 _c → _...
        - 去除多余的 LaTeX 标记如 \\left, \\right
    """
    if not expr:
        return ''

    # 字段映射（全大写转小写）
    field_map = {
        'CLOSE': 'close',
        'OPEN': 'open',
        'HIGH': 'high',
        'LOW': 'low',
        'VOLUME': 'volume',
        'AMOUNT': 'turnover',
        'TURNOVER': 'turnover',
        'VWAP': 'vwap',
        'RET': 'return',
    }

    # 函数名映射
    func_map = {
        '\\frac': '/',
        '\\sum': 'SUM',
        '\\prod': 'PROD',
        '\\max': 'MAX',
        '\\min': 'MIN',
        '\\log': 'LOG',
        '\\ln': 'LN',
        '\\sqrt': 'SQRT',
        '\\cdot': '*',
        '\\times': '*',
        '\\left': '',
        '\\right': '',
        '\\approx': '≈',
        '\\equiv': '≡',
        '\\neq': '!=',
        '\\leq': '<=',
        '\\geq': '>=',
    }

    # 先进行字段替换（加单词边界避免替换部分单词）
    for k, v in field_map.items():
        expr = re.sub(rf'\b{k}\b', v, expr)

    # 函数名替换
    for k, v in func_map.items():
        if v == '':
            expr = expr.replace(k, '')
        else:
            expr = expr.replace(k, v)

    # 处理分式：\\frac{a}{b} -> (a)/(b)
    def replace_frac(m):
        num = m.group(1).strip()
        den = m.group(2).strip()
        return f'({num})/({den})'
    expr = re.sub(r'\\frac\{([^}]+)\}\{([^}]+)\}', replace_frac, expr)

    # 处理上标：^{...} 或 ^c
    def replace_sup(m):
        if m.group(1):
            power = m.group(1)
        else:
            power = m.group(2)
        return f'**{power}'
    expr = re.sub(r'\^\{([^}]+)\}|\^([a-zA-Z0-9])', replace_sup, expr)

    # 处理下标：_{...} 或 _c
    def replace_sub(m):
        if m.group(1):
            return f'_{m.group(1)}'
        else:
            return f'_{m.group(2)}'
    expr = re.sub(r'\_\{([^}]+)\}|\_([a-zA-Z0-9])', replace_sub, expr)

    # 希腊字母映射
    greek_map = {
        '\\alpha': 'alpha',
        '\\beta': 'beta',
        '\\gamma': 'gamma',
        '\\delta': 'delta',
        '\\epsilon': 'epsilon',
        '\\mu': 'mu',
        '\\sigma': 'sigma',
        '\\tau': 'tau',
        '\\phi': 'phi',
    }
    for k, v in greek_map.items():
        expr = expr.replace(k, v)

    # 去除可能遗留的花括号（如果未被解析）
    expr = expr.replace('{', '').replace('}', '')

    # 清理多余空格
    expr = re.sub(r'\s+', ' ', expr).strip()

    return expr


def generate_factor_id(index: int) -> str:
    """生成因子ID，例如 FACTOR_SEL_001"""
    return f"FACTOR_SEL_{index:03d}"


def write_md(output_dir: Path, factor: RawFactor) -> None:
    """将因子写入 Markdown 文件"""
    if isinstance(output_dir, str):
        output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    file_path = output_dir / f"{factor.factor_id}.md"

    lines = [
        "# Selenium增强版因子（自动导入）",
        "",
        f"因子ID: {factor.factor_id}  ",
        f"因子名称: {factor.factor_name}  ",
        f"分类: {factor.category}  ",
        f"标签: {', '.join(factor.tags)}  ",
        f"原始公式: {factor.raw_formula}  ",
        f"DSL公式: {factor.dsl_formula}  ",
        f"描述: {factor.description[:200]}..." if len(factor.description) > 200 else f"描述: {factor.description}",
        f"因子类型: {factor.category}  ",
        f"适用股票池: ALL_A  ",
        f"调仓周期: 日线  ",
        f"因子方向: long  ",
        f"来源URL: {factor.url}",
        "",
    ]

    file_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"已生成: {file_path}")


def main():
    input_path, output_dir = get_paths()
    print(f"读取文件: {input_path}")

    blocks = read_file_chunks(input_path)
    print(f"找到 {len(blocks)} 个因子块")

    valid_count = 0
    for idx, block in enumerate(blocks, start=1):
        print(f"\n处理第 {idx} 个因子块...")
        info = extract_basic_info(block)

        if not info['name']:
            print("  跳过：未找到因子名称")
            continue
        if not info['category']:
            print("  警告：分类为空")
        if not info['url']:
            print("  警告：URL为空")

        raw_formula, pure_formulas = extract_raw_formula(info['math'], info['detail'])
        if not raw_formula:
            print("  警告：未提取到公式，将使用空字符串")
        else:
            print(f"  提取到公式长度: {len(raw_formula)} 字符")

        # 对纯公式进行DSL转换（如果有多个公式，分别转换后拼接）
        if pure_formulas:
            dsl_lines = []
            for line in pure_formulas.split('\n'):
                dsl_lines.append(to_dsl(line))
            dsl_formula = '\n'.join(dsl_lines)
        else:
            dsl_formula = ''

        desc = info['detail'].strip()
        if len(desc) > 200:
            desc = desc[:200] + '...'

        factor = RawFactor(
            source="selenium_enhanced",
            factor_name=info['name'],
            factor_id=generate_factor_id(valid_count + 1),
            category=info['category'],
            tags=info['tags'],
            raw_formula=raw_formula,
            dsl_formula=dsl_formula,
            description=desc,
            url=info['url']
        )

        write_md(output_dir, factor)
        valid_count += 1

    print(f"\n完成！成功生成 {valid_count} 个因子文档，位于: {output_dir}")


if __name__ == "__main__":
    main()