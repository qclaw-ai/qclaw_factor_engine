# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_213  
因子名称: 分析师预期EPS调整幅度  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 质量, 动量, 分析师预期, 成长, 价值, 量化交易  
原始公式: \frac{当前预期EPS - 三个月前预期EPS}{|三个月前预期EPS|}

当前预期EPS

三个月前预期EPS

|三个月前预期EPS|  
DSL公式: /当前预期EPS - 三个月前预期EPS|三个月前预期EPS|
当前预期EPS
三个月前预期EPS
|三个月前预期EPS|  
描述: Factors DirectoryQuantitative Trading Factors分析师预期EPS调整幅度情绪因子因子公式调整幅度 = (当前预期EPS - 三个月前预期EPS) / |三个月前预期EPS|当前预期EPS−三个月前预期EPS∣三个月前预期EPS∣ \frac{当前预期EPS - 三个月前预期EPS}{|三个月前预期EPS|} ∣三个月前预期EPS∣当前预期EPS−三个月前预...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/expected-eps-adjustment
