# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_346  
因子名称: 有形净值负债率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 有形净值负债率, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{Total Liabilities}{Tangible Net Worth}

Shareholder's Equity - Intangible Assets - Development Expenditure - Goodwill - Long-term Deferred Expenses - Deferred Tax Assets

Total Liabilities

Tangible Net Worth

Shareholder's Equity

Intangible Assets

Development Expenditure

Goodwill

Long-term Deferred Expenses

Deferred Tax Assets  
DSL公式: /Total LiabilitiesTangible Net Worth
Shareholder's Equity - Intangible Assets - Development Expenditure - Goodwill - Long-term Deferred Expenses - Deferred Tax Assets
Total Liabilities
Tangible Net Worth
Shareholder's Equity
Intangible Assets
Development Expenditure
Goodwill
Long-term Deferred Expenses
Deferred Tax Assets  
描述: ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 有形净值负债率基础面因子因子公式有形净值负债率 =TotalLiabilitiesTangibleNetWorth \frac{Total Liabilities}{Tangible Net Worth} TangibleNetWorthTotalLiabilities​有形净值 =Shar...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/tangible-net-debt-ratio
