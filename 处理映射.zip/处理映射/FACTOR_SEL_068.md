# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_068  
因子名称: 平均月度成交额  
分类: : 流动性指标  
标签: : 流动性, 平均月度成交额, 流动性指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{1}{K\times N} \sum_{t=1}^{K} \sum_{d=1}^{N} V_{t,d}

V_{t,d}

参数说明：KKK：代表回溯月份的数量，即计算均值时使用的最近月份数，该值通常为正整数。NNN:代表每个月交易日的天数，通常情况下，不同月份的交易日天数可能存在差异，此处为取均值做统一计算Vt,dV_{t,d}Vt,d​:代表第t个月的第d个交易日的成交额。成交额指的是在特定交易日内该股票交易的货币总量。因子解释平均月度成交额是一个衡量股票流动性的重要指标。流动性高的股票交易更便捷，交易成本更低，价格也更稳定，因此投资者对流动性高的股票通常要求较低的预期收益。相反，流动性低的股票，由于交易成本高和变现困难，投资者会要求更高的回报，这就是流动性溢价的体现。该因子可以捕捉市场中存在的流动性风险因素，并可用于构建量化投资策略。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Brennan, Michael J., Tarun Chordia, and Avanidhar Subrahmanyam. (1998). Alternative factor specifications, security characteristics, and the cross-section of expected stock returns. Journal of Financial EconomicsRelated Factors 成交额波动率 月均换手率因子 负收益成交额加权非流动性因子 流动性调整成交量零值天数比率 日均换手率 股票换手率 (Turnover Rate) 成交额变异系数 非流动性变异系数 Amihud 非流动性指标 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 因子公式最近K个月日度成交额的均值，计算公式如下：1K×N∑t=1K∑d=1NVt,d \frac{1}{K\times N} \sum_{t=1}^{K} \sum_{d=1}^{N} V_{t,d} K×N1​t=1∑K​d=1∑N​Vt,d​其中:KKK:代表回溯月份的数量，即计算均值时使用的最近月份数，该值通常为正整数。NNN:代表每个月交易日的天数，通常情况下，不同月份的交易日天数可能存在差异，此处为取均值做统一计算Vt,dV_{t,d}Vt,d​:代表第t个月的第d个交易日的成交额。成交额指的是在特定交易日内该股票交易的货币总量。 成交额波动率 月均换手率因子 负收益成交额加权非流动性因子 流动性调整成交量零值天数比率 日均换手率 股票换手率 (Turnover Rate) 成交额变异系数 非流动性变异系数 Amihud 非流动性指标 其中:KKK:代表回溯月份的数量，即计算均值时使用的最近月份数，该值通常为正整数。NNN:代表每个月交易日的天数，通常情况下，不同月份的交易日天数可能存在差异，此处为取均值做统一计算Vt,dV_{t,d}Vt,d​:代表第t个月的第d个交易日的成交额。成交额指的是在特定交易日内该股票交易的货币总量。 ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应...  
DSL公式: /1K* N SUM_t=1**K SUM_d=1**N V_t,d
V_t,d  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Brennan, Michael J., Tarun Chordia, and Avanidhar Subrahmanyam. (1998). Alternative factor specifications, security characteristics, and the cross-section of expected s...
因子类型: : 流动性指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/liquidity/trading-volume
