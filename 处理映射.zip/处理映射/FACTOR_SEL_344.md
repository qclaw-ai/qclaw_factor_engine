# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_344  
因子名称: 财务杠杆系数  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 波动率, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \text{平均总资产} = \frac{\text{期初总资产} + \text{期末总资产}}{2}

\text{平均归属母公司股东权益合计} = \frac{\text{期初归属母公司股东权益合计} + \text{期末归属母公司股东权益合计}}{2}

\text{财务杠杆系数} = \frac{\text{平均总资产}}{\text{平均归属母公司股东权益合计}}

\text{平均总资产}

\text{平均归属母公司股东权益合计}  
DSL公式: \text平均总资产 = /\text期初总资产 + \text期末总资产2
\text平均归属母公司股东权益合计 = /\text期初归属母公司股东权益合计 + \text期末归属母公司股东权益合计2
\text财务杠杆系数 = /\text平均总资产\text平均归属母公司股东权益合计
\text平均总资产
\text平均归属母公司股东权益合计  
描述: 平均归属母公司股东权益合计（Average Equity Attributable to Parent Company）：平均归属母公司股东权益合计=期初归属母公司股东权益合计+期末归属母公司股东权益合计2 \text{平均归属母公司股东权益合计} = \frac{\text{期初归属母公司股东权益合计} + \text{期末归属母公司股东权益合计}}{2} 平均归属母公司股东权益合计=2期初归属...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/equity-multiplier
