# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_113  
因子名称: 钱德动量振荡器  
分类: : 技术指标  
标签: : 钱德动量振荡器, 流动性, 技术指标, 技术分析, 质量, 动量, 成长, 价值  
原始公式: CZ1 = \begin{cases} CLOSE - CLOSE[1] & \text{if } CLOSE - CLOSE[1] > 0 \\ 0 & \text{otherwise} \end{cases}

CZ2 = \begin{cases} |CLOSE - CLOSE[1]| & \text{if } CLOSE - CLOSE[1] < 0 \\ 0 & \text{otherwise} \end{cases}

SU(N) = \sum_{i=0}^{N-1} CZ1_i

SD(N) = \sum_{i=0}^{N-1} CZ2_i

CMO = \frac{SU(N) - SD(N)}{SU(N) + SD(N)} * 100

N = 20

CLOSE

CLOSE[1]

ABS()

SUM()

参数说明：，CLOSE 表示当日收盘价，CLOSE[1] 表示前一日收盘价，ABS() 表示绝对值，SUM() 表示求和函数。CLOSECLOSECLOSE:当日收盘价CLOSE[1]CLOSE[1]CLOSE[1]:前一日收盘价ABS()ABS()ABS():绝对值函数SUM()SUM()SUM():求和函数因子解释钱德动量振荡器 (CMO) 的取值范围在 -100 到 100 之间。当 CMO 值接近 100 时，表明市场处于超买状态，价格可能出现回调；当 CMO 值接近 -100 时，表明市场处于超卖状态，价格可能出现反弹。一般来说，CMO 大于 50 被认为是超买信号，CMO 小于 -50 被认为是超卖信号。然而，在实际应用中，投资者应该根据具体情况和市场的特点，灵活调整超买超卖的阈值，并结合其他技术指标和分析方法进行综合判断。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。John J. Murphy. (1999). 技术分析指标详解. Technical Analysis of the Financial MarketsRelated Factors 蔡金资金流量震荡指标 随机动量指标 (SMI) 相对强弱指标 (RSI) 商品通道指数 价格变动速率因子 成交量动量摆动指标 蔡金资金流向指标 随机摆动指标 日内强度指标 (Intraday Momentum Index, IMI) 钱德动量振荡器 (CMO) =CMO=SU(N)−SD(N)SU(N)+SD(N)∗100 CMO = \frac{SU(N) - SD(N)}{SU(N) + SD(N)} * 100 CMO=SU(N)+SD(N)SU(N)−SD(N)​∗10...  
DSL公式: CZ1 = \begincases close - close[1] & \textif close - close[1] > 0 \\ 0 & \textotherwise \endcases
CZ2 = \begincases |close - close[1]| & \textif close - close[1] < 0 \\ 0 & \textotherwise \endcases
SU(N) = SUM_i=0**N-1 CZ1_i
SD(N) = SUM_i=0**N-1 CZ2_i
CMO = /SU(N) - SD(N)SU(N) + SD(N) * 100
N = 20
close
close[1]
ABS()
SUM()  
描述: 钱德动量振荡器 (Chande Momentum Oscillator, CMO)技术因子因子公式正向变动值 (CZ1) =CZ1={CLOSE−CLOSE[1]if CLOSE−CLOSE[1]>00otherwise CZ1 = \begin{cases} CLOSE - CLOSE[1] & \text{if } CLOSE - CLOSE[1] > 0 \\ 0 & \text{other...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/chande-momentum-oscillator
