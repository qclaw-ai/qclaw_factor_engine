# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_094  
因子名称: 相对组合对数价差偏离度  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 动量, 成长, 价值, 量化交易, 相对组合对数价差偏离度  
原始公式: ReferencePrice_{i,t} =  \frac{1}{N} \sum_{j=1}^{N} StockPrice_{j,t}

LogPriceSpread_{i,t} = ln(StockPrice_{i,t}) - ln(ReferencePrice_{i,t})

SpreadBias_{i,t} = \frac{LogPriceSpread_{i,t} - mean(LogPriceSpread_{i,t})}{std(LogPriceSpread_{i,t})}

ReferencePrice_{i,t}

StockPrice_{i,t}

StockPrice_{j,t}

LogPriceSpread_{i,t}

mean(LogPriceSpread_{i,t})

std(LogPriceSpread_{i,t})

参数说明：ReferencePricei：,tReferencePrice_{i,t}ReferencePricei,t​:股票i在t时刻的参考价格，由与其特征最相似的N只股票的价格等权平均得到。StockPricei,tStockPrice_{i,t}StockPricei,t​:股票i在t时刻的价格StockPricej,tStockPrice_{j,t}StockPricej,t​:第j只相似股票在t时刻的价格LogPriceSpreadi,tLogPriceSpread_{i,t}LogPriceSpreadi,t​:股票i在t时刻的价格与其参考价格的对数差值mean(LogPriceSpreadi,t)mean(LogPriceSpread_{i,t})mean(LogPriceSpreadi,t​):在一段时间内，股票i与其参考价格的对数差值的均值，用于衡量该股票价差的中心位置。std(LogPriceSpreadi,t)std(LogPriceSpread_{i,t})std(LogPriceSpreadi,t​):在一段时间内，股票i与其参考价格的对数差值的标准差，用于衡量该股票价差的波动程度。因子解释该因子捕捉了个股价格相对于其特征相似组合的相对强弱。当因子值较低时，表示个股价格低于其特征组合的平均水平，可能存在被低估的情况，暗示着未来价格回归的潜在动力。相反，较高的因子值则暗示个股价格高于其特征组合的平均水平，可能存在高估的风险，未来可能面临价格回调的压力。该因子的核心思想基于均值回归的假设，即当个股价格偏离其合理估值区间（由特征组合代表）时，存在向平均水平回归的趋势。因此，该因子可以用于识别短期内价格波动过度的股票，并进行相应的交易策略。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。朱剑涛. (2016). 投机、交易行为与股票收益(下). 东方证券Related Factors 双向价格差分自相关性标准化因子 残差市值偏离度 时间加权平均相对价格位置 市场反应滞后因子 特异性收益波动因子 基本面趋势预期收益率 估值偏离度(误差修正模型) 开盘时段大单净买入强度标准化均值 市值非线性偏离因子 双向价格差分自相关性标准化因子 残差市值偏离度 时间加权平均相对价格位置 市场反应滞后因子 特异性收益波动因子 基本面趋势预期收益率 估值偏离度(误差修正模型) 开盘时段大单净买入强度标准化均值 市值非线性偏离因子 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors相对组合对数价差偏离度技术因子因子公式参考价格:ReferencePricei,t=1N∑j=1NStockPricej,t ReferencePrice_{i,t} =  \frac{1}{N} \sum_{j=1}^{N} StockPrice_{j,...  
DSL公式: ReferencePrice_i,t = /1N SUM_j=1**N StockPrice_j,t
LogPriceSpread_i,t = ln(StockPrice_i,t) - ln(ReferencePrice_i,t)
SpreadBias_i,t = /LogPriceSpread_i,t - mean(LogPriceSpread_i,t)std(LogPriceSpread_i,t)
ReferencePrice_i,t
StockPrice_i,t
StockPrice_j,t
LogPriceSpread_i,t
mean(LogPriceSpread_i,t)
std(LogPriceSpread_i,t)  
描述: 相对组合对数价差偏离度技术因子因子公式参考价格:ReferencePricei,t=1N∑j=1NStockPricej,t ReferencePrice_{i,t} =  \frac{1}{N} \sum_{j=1}^{N} StockPrice_{j,t} ReferencePricei,t​=N1​j=1∑N​StockPricej,t​股票i与参考价格的对数价差:LogPriceSprea...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/price-spread-deviation
