# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_091  
因子名称: 市值非线性偏离因子  
分类: : 价值指标  
标签: : 流动性, 市值非线性偏离因子, 质量, 动量, 成长, 价值, 量化交易, 价值指标  
原始公式: LNCAP_{i,t}^{D3} = \varepsilon_{i,t}

\alpha_t + \beta_t LNCAP_{i,t} + \varepsilon_{i,t} =  LNCAP_{i,t}^{D2}

LNCAP_{i,t}

LNCAP_{i,t}^{D2}

\alpha_t

\beta_t

\varepsilon_{i,t}

参数说明：LNCAPi：,tLNCAP_{i,t}LNCAPi,t​:为第t期股票i的对数市值，即对股票i在t期的总市值取自然对数。LNCAPi,tD2LNCAP_{i,t}^{D2}LNCAPi,tD2​:为第t期股票i的对数市值因子值，即对数市值因子，是回归模型的因变量。αt \alpha_t αt​:为第t期的截距项，表示在市值为0时的理论因子值。βt\beta_tβt​:为第t期对数市值因子的回归系数，表示对数市值每变化一个单位，因子值相应的变化量，反映市值与因子值的线性关系。εi,t\varepsilon_{i,t}εi,t​:为回归模型的残差项，代表了股票i在t期实际对数市值因子值与线性回归模型预测值之间的偏离程度。残差项经过后续的去极值和标准化处理后，即可得到市值非线性偏离因子$LNCAP_{i,t}^{D3}$。对所有股票在t期的对数市值因子值进行横截面上的加权最小二乘法(WLS)回归，回归权重为各股票市值开根号，旨在减小大市值股票在回归过程中的影响，增强模型的稳健性。 市值非线性偏离因子，又称中市值偏离因子，其核心思想是利用市值与股票收益之间非线性的特征。尽管A股市场存在小市值溢价，但市值与收益的关系并非简单的线性关系。随着市值增大，其对收益的边际效应递减，即市值增长带来的收益增幅会逐渐降低。若直接使用线性市值因子，可能会高估中等市值股票的预期收益。此因子通过WLS回归模型，提取市值与其线性预期之间的残差，即为市值非线性偏离因子，该因子反映的是个股市值偏离其线性市值预期的程度。此因子的构建逻辑是，如果股票的市值偏离了线性模型所预期的市值水平，则该股票的实际表现也可能偏离预期。中等市值股票的残差通常较小，意味着其市值与线性模型预测相近；而极大小市值股票的残差值较大，说明其市值与线性预测存在较大偏差。该因子为负向因子，绝对值越大，代表市值非线性偏离越大。需要注意的是，此处的偏离是指相对于线性模型的偏离，而非市值本身的大小。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors市值非线性偏离价值因子因子公式市值非线性偏离因子公式:LNCAPi,tD3=εi,t LNCAP_{i,t}^{D3} = \varepsilon_{i,t} LNCAPi,tD3​=εi,t​回归模型公式：αt+βtLNCAPi,t+εi,t=LNCAPi,tD2 \alpha_t + \beta_t LNCAP_{i,t} + \varepsilon_{i,t} =  LNCAP_{i,t}^{D2} αt​+βt​LNCAPi,t​+εi,t​=LNCAPi,tD2​其中：LNCAPi,tLNCAP_{i,t}LNCAPi,t​:为第t期股票i的对数市值，即对股票i在t期的总市值取自然对数。LNCAPi,tD2LNCAP_{i,t}^{D2}LNCAPi,tD2​:为第t期股票i的对数市值因子值，即对数市值因子，是回归模型的因变量。αt \alpha_t αt​:为第t期的截距项，表示在市值为0时的理论因子值。βt\beta_tβt​:为第t期对数市值因子的回归系数，表示对数市值每变化一个单位，因子值相应的变化量，反映市值与因子值的线性关系。εi,t\varepsilon_{i,t}εi,t​:为回归模型的残差项，代表了股票i在t期实际对数市值因子值与线性回归模型预测值之间的偏离程度。残差项经过后续的去极值和标准化处理后，即可得到市值非线性偏离因子$LNCAP_{i,t}^{D3}$。对所有股票在t期的对数市值因子值进行横截面上的加权最小二乘法(WLS)回归，回归权重为各股票市值开根号，旨在减小大市值股票在回...  
DSL公式: LNCAP_i,t**D3 = \varepsilon_i,t
alpha_t + beta_t LNCAP_i,t + \varepsilon_i,t = LNCAP_i,t**D2
LNCAP_i,t
LNCAP_i,t**D2
alpha_t
beta_t
\varepsilon_i,t  
描述: 回归模型公式：αt+βtLNCAPi,t+εi,t=LNCAPi,tD2 \alpha_t + \beta_t LNCAP_{i,t} + \varepsilon_{i,t} =  LNCAP_{i,t}^{D2} αt​+βt​LNCAPi,t​+εi,t​=LNCAPi,tD2​ 因子公式市值非线性偏离因子公式:LNCAPi,tD3=εi,t LNCAP_{i,t}^{D3} = \varep...
因子类型: : 价值指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/value/non-linear-market-value
