# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_271  
因子名称: 有形资本回报率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 有形资本回报率, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{\text{EBIT}_{TTM}}{\text{Tangible Capital}}

\text{Tangible Capital} = \text{Net Working Capital} + \text{Net Fixed Assets}

\text{Net Working Capital} = \text{Current Assets} - \text{Current Liabilities}

\text{Net Fixed Assets} = \text{Fixed Assets}

\text{EBIT}_{TTM}

\text{Tangible Capital}

\text{Net Working Capital}

\text{Current Assets}

\text{Current Liabilities}

\text{Net Fixed Assets}

参数说明：，净营运资本计算公式为:Net Working Capital=Current Assets−Current Liabilities \text{Net Working Capital} = \text{Current Assets} - \text{Current Liabilities} Net Working Capital=Current Assets−Current Liabilities 因子解释有形资本回报率（ROTC）衡量的是公司利用有形资产（如厂房、设备等）创造利润的效率。该指标剔除了无形资产（如专利、商誉等）的影响，更侧重于评估公司在实物资产上的投资回报能力。ROTC越高，表明公司利用有形资本创造利润的能力越强，运营效率也越高。ROTC可以用来比较不同公司在实体资产利用上的效率，帮助投资者筛选出经营能力更强、更具竞争优势的企业。在行业比较分析中，该指标尤为重要，因为不同行业的有形资产密集程度差异很大。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 其中，净固定资本计算公式为:Net Fixed Assets=Fixed Assets \text{Net Fixed Assets} = \text{Fixed Assets} Net Fixed Assets=Fixed Assets 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Ludwig B. Chincarini, Daehwan Kim. (2006). Quantitative Equity Portfolio Management: An Active Approach to Portfolio Construction and Management. McGraw-Hill Library of Investment and Finance 净固定资产，通常情况下，直接使用固定资产替代净固定资产。该指标代表公司用于长期生产经营的实物资产，如厂房、设备等。这里简化为固定资产，忽略累计折旧等因素。 因子公式有形资本回报率（ROTC）计算公式:EBITTTMTangible Capital \frac{\text{EBIT}_{TTM}}{\text{Tangible Capital}} Tangible CapitalEBITTTM​​其中，有形资本计算公式为:Tangible Capital=Net Working Capital+Net Fixed Assets \text{Tangible Capital} = \text{Net Working Capital} + \text{Net Fixed Assets} Tangible Capital=Net Working Capital+Net Fixed Assets其中，净营运资本计算公式为:Net Working Capital=Current Assets−Current Liabilities \text{Net Working Capital} = \text{Current Assets} - \text{Current Liabilities} Net Working Capital=Current Assets−Current Liabilities其中，净固定资本计算公式为:Net Fixed Assets=Fixed Assets \text{Net Fixed Assets} = \text{Fixed Assets} Net Fixed Assets=Fixed Assets公式中各参数的含义如下：EBITTTM\text{EBIT}_{TTM}EBITTTM​:最近12个月的息税前利润（Earnings Before Interest and Taxes）。这是一个滚动时间段的利润指标，能够反映公司最近一年的盈利表现，避免季节性波动带来的影响。Tangible Capital\text{Tangible Capital}Tangible Capital:有形资本，代表公司日常经营活动中使用的实物资产。它是衡量公司实体资产投资规模的重要指标，剔除了无形资产的影响，更侧重于评估实体资产的盈利能力。Net Working Capital\text{Net Working Capital}Net Working Capital:净营运资本，指公司流动资产减去流动负债后的余额。它反映了公司短期经营活动的资金状况，以及偿还短期债务的能力。Current Assets\text{Current Assets}Current Assets:流动资产，指可以在一年或一个经营周期内变现或耗用的资产，包...  
DSL公式: /\textEBIT_TTM\textTangible Capital
\textTangible Capital = \textNet Working Capital + \textNet Fixed Assets
\textNet Working Capital = \textCurrent Assets - \textCurrent Liabilities
\textNet Fixed Assets = \textFixed Assets
\textEBIT_TTM
\textTangible Capital
\textNet Working Capital
\textCurrent Assets
\textCurrent Liabilities
\textNet Fixed Assets  
描述: 其中，净营运资本计算公式为:Net Working Capital=Current Assets−Current Liabilities \text{Net Working Capital} = \text{Current Assets} - \text{Current Liabilities} Net Working Capital=Current Assets−Current Liabilit...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/tangible-capital-return-rate
