# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_147  
因子名称: 投入资本回报率(ROIC)  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 投入资本回报率, 波动率, 质量, 动量, 成长, 价值  
原始公式: \frac{EBIT_{TTM} * (1-TaxRate)}{InvestedCapital}

EBIT_{TTM}*(1-TaxRate)

OperatingProfit_{TTM} + InterestExpense_{TTM}

TotalShareholdersEquity + InterestBearingDebt

ShortTermBorrowings + LongTermBorrowings + BondsPayable + CurrentPortionOfLongTermDebt

EBIT_{TTM}

OperatingProfit_{TTM}

InterestExpense_{TTM}

TaxRate

InvestedCapital

参数说明：EBITTTMEBIT_：{TTM}EBITTTM​:最近12个月的息税前利润（Earnings Before Interest and Taxes），通常使用TTM (Trailing Twelve Months) 数据，代表过去12个月的累计值。OperatingProfitTTMOperatingProfit_{TTM}OperatingProfitTTM​:最近12个月的营业利润，也使用TTM数据。InterestExpenseTTMInterestExpense_{TTM}InterestExpenseTTM​:最近12个月的利息费用，也使用TTM数据。TaxRateTaxRateTaxRate:公司的有效税率，可以是实际税率或者行业平均税率，公式中使用简化税率0.25，在实际使用中，应该替换为企业真实税率。InvestedCapitalInvestedCapitalInvestedCapital:投入资本，即公司用于经营活动的总资本，包括股东权益和有息负债。TotalShareholdersEquityTotalShareholdersEquityTotalShareholdersEquity:股东权益合计，代表股东在公司中的所有权。InterestBearingDebtInterestBearingDebtInterestBearingDebt:有息负债，即公司需要支付利息的债务，包括短期借款、长期借款、应付债券和一年内到期的长期负债。ShortTermBorrowingsShortTermBorrowingsShortTermBorrowings:短期借款，是指需要在一...  
DSL公式: /EBIT_TTM * (1-TaxRate)InvestedCapital
EBIT_TTM*(1-TaxRate)
OperatingProfit_TTM + InterestExpense_TTM
TotalShareholdersEquity + InterestBearingDebt
ShortTermBorrowings + LongTermBorrowings + BondsPayable + CurrentPortionOfLongTermDebt
EBIT_TTM
OperatingProfit_TTM
InterestExpense_TTM
TaxRate
InvestedCapital  
描述: 因子解释投入资本回报率(ROIC)是一个关键的盈利能力和资本效率指标。它衡量公司利用所有投入资本（包括股东权益和有息负债）产生税后经营利润的能力。该指标越高，表明公司在管理和利用其资本方面越有效率，能够为投资者创造更多的价值。ROIC不仅可以用于评估公司的盈利能力，还可以用于比较不同公司之间的资本效率，以及评估公司长期价值创造能力。投资者通常会将ROIC与公司的加权平均资本成本(WACC)进行比较...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/return-on-invested-capital
