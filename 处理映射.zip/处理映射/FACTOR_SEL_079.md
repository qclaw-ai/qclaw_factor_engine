# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_079  
因子名称: TTM基本每股收益同比增长率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, ttm, 质量, 动量, 成长, 基本每股收益同比增长率, 价值  
原始公式: \frac{EPS_{TTM,current} - EPS_{TTM,previousYear}}{abs(EPS_{TTM,previousYear})}

EPS_{TTM,current}

EPS_{TTM,previousYear}

abs()  
DSL公式: /EPS_TTM,current - EPS_TTM,previousYearabs(EPS_TTM,previousYear)
EPS_TTM,current
EPS_TTM,previousYear
abs()  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Stephen H. Penman. (2013). 财务报表分析与估值. McGraw-Hill EducationZvi Bodie, Alex Kane, Alan J. Marcus. (2017). 投资学. McGraw-Hill Education Related Factors 稀释每股收益同比增长率 (TTM) 单季...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/earnings-growth-rate
