# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_136  
因子名称: 52周最高价逼近度  
分类: : 动量指标  
标签: : 流动性, 质量, 动量, 成长, 价值, 量化交易, 周最高价逼近度, 动量指标  
原始公式: Close_t

Max(Close_{t-52week}, ..., Close_t)

Close_t / Max(Close_{t-52week}, ..., Close_t)

Close_t

Max(Close_{t-52week}, ..., Close_t)

Close_t / Max(Close_{t-52week}, ..., Close_t)  
DSL公式: Close_t
Max(Close_t-52week, ..., Close_t)
Close_t / Max(Close_t-52week, ..., Close_t)
Close_t
Max(Close_t-52week, ..., Close_t)
Close_t / Max(Close_t-52week, ..., Close_t)  
描述: 52周最高价逼近度动量因子因子公式当前收盘价Closet Close_t Closet​过去52周最高价Max(Closet−52week,...,Closet) Max(Close_{t-52week}, ..., Close_t) Max(Closet−52week​,...,Closet​)52周最高价逼近度Closet/Max(Closet−52week,...,Closet) Close...
因子类型: : 动量指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/momentum/52-week-high
