# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_138  
因子名称: 中期反转因子 (Medium-Term Reversal Factor)  
分类: : 情绪指标  
标签: : 流动性, factor, 情绪指标, 波动率, 质量, 动量, 成长, 价值  
原始公式: R_{t-59:t-12} = \prod_{d=t-59}^{t-12} (1 + r_d) - 1

R_{t-59:t-12}

r_d

\prod  
DSL公式: R_t-59:t-12 = PROD_d=t-59**t-12 (1 + r_d) - 1
R_t-59:t-12
r_d
PROD  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。De Bondt, Werner F. M., and Richard Thaler. (1985). Does the stock market overreact?. Journal of Finance 公式解释：Rt−59:t−12R_{t-59:t-12}Rt−59:t−12​:表示从第(t-59)月至第(t-12)月的累计...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/long-term-reversal
