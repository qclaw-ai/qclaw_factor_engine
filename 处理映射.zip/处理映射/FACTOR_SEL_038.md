# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_038  
因子名称: 日均负向成交额占比相对强度  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 日均负向成交额占比相对强度, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{1}{T} \sum_{n=t-T+1}^{t} \frac{\frac{\sum_{j=1}^{N} Amt_{i,j,n} \cdot I_{r_{i,j,n}<0}}{\sum_{j=1}^{N} TrdNum_{i,j,n} \cdot I_{r_{i,j,n}<0}}}{\frac{\sum_{j=1}^{N} Amt_{i,j,n}}{\sum_{j=1}^{N} TrdNum_{i,j,n}}} / \frac{1}{T} \sum_{n=t-T+1}^{t} \frac{\sum_{i=1}^{M} \frac{\sum_{j=1}^{N} Amt_{i,j,n} \cdot I_{r_{i,j,n}<0}}{\sum_{j=1}^{N} TrdNum_{i,j,n} \cdot I_{r_{i,j,n}<0}}}{\sum_{i=1}^{M} \frac{\sum_{j=1}^{N} Amt_{i,j,n}}{\sum_{j=1}^{N} TrdNum_{i,j,n}}}

Amt_{i,j,n}

r_{i,j,n}

TrdNum_{i,j,n}

I_{r_{i,j,n}<0}

参数说明：$price_{i,j,n}$ 表示股票i在第n天第j分钟的成交均价。 为回溯的时间窗口，单位为交易日。月度选股下，通常 T=20 个交易日；周度选股下，通常 T=5 个交易日。该参数定义了计算因子值的时间范围。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 因子解释该因子计算的是一段时间内，股票的日均单笔负向成交额占比的相对强度。具体来说，首先，我们计算股票在每日的单笔负向成交额（即主动卖出成交额）与总单笔成交额的比值，这体现了当日主动卖出的相对强度。接着，我们对一段时间内（例如20个交易日）的日均单笔负向成交额占比求平均值，得到股票在该段时间内的平均负向成交额占比。最后，我们将该平均值与同期市场平均水平的平均负向成交额占比进行比较，计算其相对强度，从而得到最终的因子值。该因子旨在捕捉市场中主动抛售的强度，数值越高，表示该股票在过去一段时间内负向成交额占比相对市场平均水平较高，可能预示着该股票存在一定的抛售压力，也可能是主力资金逆势抄底。反之，若该值较低，则可能表明市场对该股票的抛售意愿较弱。该因子可以反映市场情绪和资金流向，作为量化选股和风险控制的参考。 其中：Amti,j,nAmt_{i,j,n}Amti,j,n​:为股票i在第n个交易日内第j分钟的成交额。成交额指在该分钟内该股票所有交易的总金额。ri,j,nr_{i,j,n}ri,j,n​:为股票i在第n个交易日内第j分钟的收益率，表示该分钟相对上一分钟的涨跌幅度。计算公式为： $r_{i,j,n} = \frac{price_{i,j,n} - price_{i,j-1,n}}{price_{i,j-1,n}}$，其中 $price_{i,j,n}$ 表示股票i在第n天第j分钟的成交均价。TrdNumi,j,nTrdNum_{i,j,n}TrdNumi,j,n​:为股票i在第n个交易日内第j分钟的成交笔数。成交笔数指该分钟内该股票所有交易的总笔数。Iri,j,n<0I_{r_{i,j,n}<0}Iri,j,n​<0​:为指示函数，当股票i在第n个交易日第j分钟的收益率 $r_{i,j,n}$ 小于0时，该函数值为1；否则为0。用于筛选出主动卖出的交易（负向成交）。TTT:为回溯的时间窗口，单位为交易日。月度选股下，通常 T=20 个交易日；周度选股下，通常 T=5 个交易日。该参数定义了计算因子值的时间范围。NNN:为每个交易日内的分钟数。例如，如果是一天的交易日，N=240(4小时，每分钟1笔数据)MMM:为市场中所有股票的总数量，用于计算市场平均值。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。冯佳睿,姚石. (2019). 日内分时成交中的玄机. 海通证券 因子公式1T∑n=t−T+1t∑j=1NAmti,j,n⋅Iri,j,n<0∑j=1NTrdNumi,j,n⋅Iri,j,n<0∑j=1NAmti,j,n∑j=1NTrdNumi,j,n/1T∑n=t−T+1t∑i=1M∑j=1NAmti,j,n⋅Iri,j,n<0∑j=1NTrdNumi,j,n⋅Iri,j,n<0∑i=1M∑j=1NAmti,j,n∑j=1NTrdNumi,j,n \frac{1}{T} \sum_{n=t-T+1}^{t} \frac{\frac{\sum_{j=1}^{N} Amt_{i,j,n} \cdot I_{r_{i,j,n}<0}}{\sum_{j=1}^{N} TrdNum_{i,j,n} \cdot I_{r_{i,j,n}<0}}}{\frac{\sum_{j=1}^{N} Amt_{i,j,n}}{\sum_{j=1}^{N} TrdNum_{i,j,n}}} / \frac{1}{T} \sum_{n=t-T+1}^{t} \frac{\sum_{i=1}^{M} \frac{\sum_{j=1}^{N} Amt_{i,j,n} \cdot I_{r_{i,j,n}<0}}{\sum_{j=1}^{N} TrdNum_{i,j,n} \cdot I_{r_{i,j,n}<0}}}{\sum_{i=1}^{M} \frac{\sum_{j=1}^{N} Amt_{i,j,n}}{\sum_{j=1}^{N} TrdNum_{i,j,n}}} T1​n=t−T+1∑t​∑j=1N​TrdNumi,j,n​∑j=1N​Amti,j,n​​∑j=1N​TrdN...  
DSL公式: /1T SUM_n=t-T+1**t //SUM_j=1**N Amt_i,j,n * I_r_i,j,n<0SUM_j=1**N TrdNum_i,j,n * I_r_i,j,n<0/SUM_j=1**N Amt_i,j,nSUM_j=1**N TrdNum_i,j,n / /1T SUM_n=t-T+1**t /SUM_i=1**M /SUM_j=1**N Amt_i,j,n * I_r_i,j,n<0SUM_j=1**N TrdNum_i,j,n * I_r_i,j,n<0SUM_i=1**M /SUM_j=1**N Amt_i,j,nSUM_j=1**N TrdNum_i,j,n
Amt_i,j,n
r_i,j,n
TrdNum_i,j,n
I_r_i,j,n<0  
描述: 为股票i在第n个交易日内第j分钟的收益率，表示该分钟相对上一分钟的涨跌幅度。计算公式为： $r_{i,j,n} = \frac{price_{i,j,n} - price_{i,j-1,n}}{price_{i,j-1,n}}$，其中 $price_{i,j,n}$ 表示股票i在第n天第j分钟的成交均价。 为回溯的时间窗口，单位为交易日。月度选股下，通常 T=20 个交易日；周度选股下，通常 T=...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/average-single-transaction-outflow-ratio
