# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_208  
因子名称: 线性回归残差净利润  
分类: : 基本面指标  
标签: : 流动性, 线性回归残差净利润, 基本面指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: NetProfit_i = \alpha + \beta_1 NonOperatingIncome_i + \beta_2 CashPaidEmployees_i + \epsilon_i

NetProfit_i

NonOperatingIncome_i

CashPaidEmployees_i

\alpha

\beta_1

\beta_2

\epsilon_i

参数说明：iii：表示第i个季度，其中i从最近一个季度(t)回溯至N个季度前，即 i = t, t-1, t-2 ... t-N+1NNN:表示用于回归分析的最近季度数量，默认为8，可根据实际情况调整NetProfitiNetProfit_iNetProfiti​:表示第i个季度的归属于母公司的净利润，该数据需进行Z-score标准化处理，以消除量纲和分布差异NonOperatingIncomeiNonOperatingIncome_iNonOperatingIncomei​:表示第i个季度的营业外收入，该数据需进行Z-score标准化处理，以消除量纲和分布差异CashPaidEmployeesiCashPaidEmployees_iCashPaidEmployeesi​:表示第i个季度支付给职工以及为职工支付的现金，该数据需进行Z-score标准化处理，以消除量纲和分布差异α\alphaα:回归模型的截距项，表示当自变量为0时，因变量的期望值，在因子计算中不直接使用，仅用于回归模型构建β1\beta_1β1​:回归模型中营业外收入的系数，表示在其他因素不变的情况下，每单位营业外收入变动对净利润的影响程度β2\beta_2β2​:回归模型中支付给职工以及为职工支付的现金的系数，表示在其他因素不变的情况下，每单位支付给职工以及为职工支付的现金变动对净利润的影响程度ϵi\epsilon_iϵi​:表示第i个季度回归的残差项，反映了净利润中未被营业外收入和支付给职工以及为职工支付的现金所解释的部分，即当期的纯化净利润部分。该因子的取值取最近一个季度(t)对应的残差，记为 $\epsilon_0$ 因子解释财务数据中既包含能够预测未来股价的有效信息，也包含对股价没有预测能力的噪音。提高数据的信噪比是构建有效因子的关键。净利润受到多种因素的影响，其中一些因素可能与公司核心经营能力关联较弱，例如营业外收入和支付给职工的现金。本因子旨在通过线性回归剔除这些噪音，从而提升净利润的预测能力。具体而言，通过回归模型，我们试图找出净利润中可由营业外收入和支付给职工现金流量解释的部分，并将其视为噪音剔除，剩余的残差则被认为是与公司核心盈利能力更为相关的信号，因此，该因子被命名为“线性回归残差净利润”。通过此方法，可以获得更为纯粹的净利润信号，从而提高因子选股的有效性。Z-score标准化在回归前对所有变量进行处理，目的是消除不同变量之间量纲和分布上的差异，使得回归分析更加合理可靠。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。刘均伟. (2018). 创新基本面因子:提纯净利数据中的选股信息. 光大证券 财务数据中既包含能够预测未来股价的有效信息，也包含对股价没有预测能力的噪音。提高数据的信噪比是构建有效因子的关键。净利润受到多种因素的影响，其中一些因素可能与公司核心经营能力关联较弱，例如营业外收入和支付给职工的现金。本因子旨在通过线性回归剔除这些噪音，从而提升净利润的预测能力。具体而言，通过回归模型，我们试图找出净利润中可由营业外收入和支付给职工现金流量解释的部分，并将其视为噪音剔除，剩余的残差则被认为是与公司核心盈利能力更为相关的信号，因此，该因子被命名为“线性回归残差净利润”。通过此方法，可以获得更为纯粹的净利润信号，从而提高因子选股的有效性。Z-score标准化在回归前对所有变量进行处理，目的是消除不同变量之间量纲和分布上的差异，使得回归分析更加合理可靠。 因子公式NetProfiti=α+β1NonOperatingIncomei+β2CashPaidEmployeesi+ϵi NetProfit_i = \alpha + \beta_1 NonOperatingIncome_i + \beta_2 CashPaidEmployees_i + \epsilon_i NetProfiti​=α+β1​NonOperatingIncomei​+β2​CashPaidEmployeesi​+ϵi​其中：iii:表示第i个季度，其中i从最近一个季度(t)回溯至N个季度前，即 i = t, t-1, t-2 ... t-N+1NNN:表示用于回归分析的最近季度数量，默认为8，可根据实际情况调整NetProfitiNetProfit_iNetProfiti​:表示第i个季度的归属于母公司的净利润，该数据需进行Z-score标准化处理，以消除量纲和分布差异NonOperatingIncomeiNonOperatingIncome_iNonOperatingIncomei​:表示第i个季度的营业外收入，该数据需进行Z-score标准化...  
DSL公式: NetProfit_i = alpha + beta_1 NonOperatingIncome_i + beta_2 CashPaidEmployees_i + epsilon_i
NetProfit_i
NonOperatingIncome_i
CashPaidEmployees_i
alpha
beta_1
beta_2
epsilon_i  
描述: 其中：iii:表示第i个季度，其中i从最近一个季度(t)回溯至N个季度前，即 i = t, t-1, t-2 ... t-N+1NNN:表示用于回归分析的最近季度数量，默认为8，可根据实际情况调整NetProfitiNetProfit_iNetProfiti​:表示第i个季度的归属于母公司的净利润，该数据需进行Z-score标准化处理，以消除量纲和分布差异NonOperatingIncomeiNo...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/linear-purified-net-profit
