# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_270  
因子名称: 单季度投入资本回报率 (QoQ ROIC)  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 波动率, qoq, 质量, 动量, 成长, 单季度投入资本回报率  
原始公式: \frac{EBIT_{adj,Q} * (1 - TaxRate_{assumed})}{InvestedCapital_{end}}

EBIT_{adj,Q} = OperatingProfit_Q + InterestExpense_Q

InvestedCapital_{end} = TotalShareholdersEquity_{end} + InterestBearingDebt_{end}

InterestBearingDebt_{end} = ShortTermBorrowings_{end} + LongTermBorrowings_{end} + BondsPayable_{end} + CurrentPortionOfLongTermDebt_{end}

EBIT_{adj,Q}

OperatingProfit_Q

InterestExpense_Q

TaxRate_{assumed}

InvestedCapital_{end}

TotalShareholdersEquity_{end}  
DSL公式: /EBIT_adj,Q * (1 - TaxRate_assumed)InvestedCapital_end
EBIT_adj,Q = OperatingProfit_Q + InterestExpense_Q
InvestedCapital_end = TotalShareholdersEquity_end + InterestBearingDebt_end
InterestBearingDebt_end = ShortTermBorrowings_end + LongTermBorrowings_end + BondsPayable_end + CurrentPortionOfLongTermDebt_end
EBIT_adj,Q
OperatingProfit_Q
InterestExpense_Q
TaxRate_assumed
InvestedCapital_end
TotalShareholdersEquity_end  
描述: ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 单季度投入资本回报率 (QoQ ROIC) 是衡量公司在单季度内，投入资本产生利润效率的指标。它通过将调整后的息税前利润（扣除假设税率影响）与期末投入资本的比率，反映了公司利用资本进行盈利的能力。相较于年度ROIC，QoQ ROIC能够提供更及时、更具动态性的公司盈利能力评估，有助于投资者把...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/basic-surface-return-on-invested-capital
