# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_366  
因子名称: 营运资本同比增速（YoY Working Capital Growth Rate）  
分类: : 基本面指标  
标签: : yoy, 流动性, rate, growth, 基本面指标, capital, 质量, 营运资本同比增速  
原始公式: \frac{WC_{t} - WC_{t-1}}{abs(WC_{t-1})}

WC \approx (Current Assets - Cash and Cash Equivalents) - (Current Liabilities - Notes Payable - Current Portion of Long-Term Debt)

WC_{t}

WC_{t-1}

Current Assets

Cash and Cash Equivalents

Current Liabilities

Notes Payable

Current Portion of Long-Term Debt

abs()

参数说明：，营运资本（Working Capital，WC）近似等于:WC≈(CurrentAssets−CashandCashEquivalents)−(CurrentLiabilities−NotesPayable−CurrentPortionofLong−TermDebt) WC \approx (Current Assets - Cash and Cash Equivalents) - (Current Liabilities - Notes Payable - Current Portion of Long-Term Debt) WC≈(CurrentAssets−CashandCashEquivalents)−(CurrentLiabilities−NotesPayable−CurrentPortionofLong−TermDebt)公式中各个参数的含义如下：WCtWC_{t}WCt​:最近报告期（t期）的营运资本。WCt−1WC_{t-1}WCt−1​:上年同期（t-1期）的营运资本。CurrentAssetsCurrent AssetsCurrentAssets:流动资产总额，包括但不限于：货币资金，交易性金融资产，应收账款，应收款项融资，预付款项，其他应收款，存货等。CashandCashEquivalentsCash and Cash EquivalentsCashandCashEquivalents:货币资金，包括现金，银行存款及其他流动性极高的短期投资，这些短期投资的期限很短，容易转换为现金，并且价值变动风险很小。CurrentLiabilitiesCurrent LiabilitiesCurrentLiabilities:流动负债总额，包括短期借款，应付账款，预收款项，应付职工薪酬，应交税费，一年内到期的非流动负债等。NotesPayableNotes PayableNotesPayable:应付票据，企业在购买原材料、商品或接受劳务供应等经营活动中，开出、承兑的商业汇票，包括银行承兑汇票和商业承兑汇票等。CurrentPortionofLong−TermDebtCurrent Portion of Long-Term DebtCurrentPortionofLong−TermDebt:一年內到期的非流动负债，指到期日在一年或一个营业周期内（以较长者为准）的非流动负债，如一年内到期的长期借款，一年内到期的应付债券等。abs()abs()abs():绝对值函数，用于确保分母为正值，避免除数为零。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 单季度经营活动净现金流同比增速 权益报酬环比动量-净资产同比增速差 有形资本回报率环比增长率 (TTM) 现金资产占比因子 经营性现金流净额/现金及现金等价物净增加额比率 (TTM) 企业自由现金流/经营性净资产市值比率 (去杠杆) 流动性经营资产变动率 投入资本回报率环比变动 单季度营业利润率同比变动率 营运资本同比增速是衡量企业营运效率和流动性变化的重要指标。正值可能预示着企业在营运资产上的投资增加，但同时也可能带来流动性压力；负值则可能预示着企业营运效率的提升和流动性的释放。该指标需要结合企业的业务模式、行业特点以及宏观经济环境进行综合分析。在进行量化分析时，可以将其与其他财务指标（例如：存货周转率、应收账款周转率、流动比率等）结合使用，以更全面地评估企业的财务健康状况。此外，在构建多因子模型时，通常会对该因子进行适当的去极值、标准化等处理，以提高模型的稳健性和有效性。 因子解释营运资本同比增速是衡量企业营运效率和流动性变化的重要指标。正值可能预示着企业在营运资产上的投资增加，但同时也可能带来流动性压力；负值则可能预示着企业营运效率的提升和流动性的释放。该指标需要结合企业的业务模式、行业特点以及宏观经济环境进行综合分析。在进行量化分析时，可以将其与其他财务指标（例如：存货周转率、应收账款周转率、流动比率等）结合使用，以更全面地评估企业的财务健康状况。此外，在构建多因子模型时，通常会对该因子进行适当的去极值、标准化等处理，以提高模型的稳健性和有效性。 公式中各个参数的含义如下：WCtWC_{t}WCt​:最近报告期（t期）的营运资本。WCt−1WC_{t-1}WCt−1​:上年同期（t-1期）的营运资本。CurrentAssetsCurrent Asse...  
DSL公式: /WC_t - WC_t-1abs(WC_t-1)
WC ≈ (Current Assets - Cash and Cash Equivalents) - (Current Liabilities - Notes Payable - Current Portion of Long-Term Debt)
WC_t
WC_t-1
Current Assets
Cash and Cash Equivalents
Current Liabilities
Notes Payable
Current Portion of Long-Term Debt
abs()  
描述: 因子公式营运资本同比增速（YoY Working Capital Growth Rate）:WCt−WCt−1abs(WCt−1) \frac{WC_{t} - WC_{t-1}}{abs(WC_{t-1})} abs(WCt−1​)WCt​−WCt−1​​其中，营运资本（Working Capital，WC）近似等于:WC≈(CurrentAssets−CashandCashEquivalent...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/yoy-growth-in-working-capital
