# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_142  
因子名称: 排序动量因子  
分类: : 动量指标  
标签: : 流动性, 质量, 动量, 排序动量因子, 成长, 价值, 量化交易, 动量指标  
原始公式: rank_{i,d} = \frac{y(R_{i,d}) - \frac{N_d + 1}{2}}{\sqrt{\frac{(N_d + 1)(N_d - 1)}{12}}}

rank_{i,m} = \frac{1}{D_m} \sum_{d=1}^{D_m} rank_{i,d}

RankMomentum_{i,t}(N, M) = \frac{1}{N} \sum_{m=t-N-M}^{t-M} rank_{i,m}

R_{i,d}

y(R_{i,d})

N_d

D_m

rank_{i,d}

rank_{i,m}

RankMomentum_{i,t}(N, M)

参数说明：$P_{i,d}$为股票i在d日的收盘价。 因子考察期内股票收益率排名标准化得分均值:RankMomentumi,t(N,M)=1N∑m=t−N−Mt−Mranki,m RankMomentum_{i,t}(N, M) = \frac{1}{N} \sum_{m=t-N-M}^{t-M} rank_{i,m} RankMomentumi,t​(N,M)=N1​m=t−N−M∑t−M​ranki,m​ ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子仅供教育和研究目的，不构成投资建议。•在做出任何投资决策之前，请咨询合格的财务顾问。 金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。 其中：Ri,dR_{i,d}Ri,d​:股票 i 在 d 日的日收益率，计算方式为：$R_{i,d} = \frac{P_{i,d} - P_{i,d-1}}{P_{i,d-1}}$，其中$P_{i,d}$为股票i在d日的收盘价。y(Ri,d)y(R_{i,d})y(Ri,d​):股票 i 在 d 日的日收益率 $R_{i,d}$ 在所有股票中的升序排名。例如，如果当天有 100 只股票，该股票的收益率排在第 30 位，则 $y(R_{i,d}) = 30$。NdN_dNd​:在 d 日参与排名的股票总数（即在d日有有效收益率数据的股票数量）DmD_mDm​:第 m 月的总交易天数，表示该月参与计算的有效交易日数量。ranki,drank_{i,d}ranki,d​:股票 i 在 d 日的日收益率排名标准化得分。该标准化步骤将原始排名转换为均值为0，标准差为1的分布。分母中的$\sqrt{\frac{(N_d + 1)(N_d - 1)}{12...  
DSL公式: rank_i,d = /y(R_i,d) - /N_d + 12SQRT/(N_d + 1)(N_d - 1)12
rank_i,m = /1D_m SUM_d=1**D_m rank_i,d
RankMomentum_i,t(N, M) = /1N SUM_m=t-N-M**t-M rank_i,m
R_i,d
y(R_i,d)
N_d
D_m
rank_i,d
rank_i,m
RankMomentum_i,t(N, M)  
描述: 考察时间窗口大小，表示计算动量因子时回溯的月份数量。例如，若 N=6，则计算过去 6 个月的月度收益率排名标准化得分均值。 时间偏移量，用于延迟动量计算的开始时间。例如，若 M=1，则将从 t-N-1 个月到 t-1 个月计算动量因子。这样可以避免使用最新月度数据，降低短期反转等效应的影响。 股票 i 在 t 时刻，基于过去 N 个月并偏移 M 个月的排序动量因子值。该值是指定时间窗口内月度收益率...
因子类型: : 动量指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/momentum/momentum-based-on-ranking
