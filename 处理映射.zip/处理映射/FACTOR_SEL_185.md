# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_185  
因子名称: 尾部风险厚度因子  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 尾部风险厚度因子, 质量, 动量, 成长, 价值, 量化交易  
原始公式: H(x; \mu, \sigma, \gamma) = \begin{cases}  \exp \left( - \left( 1 + \gamma \frac{x - \mu}{\sigma} \right)^{- \frac{1}{\gamma}} \right) , & \gamma \neq 0  \\  \exp \left( - \exp \left( - \frac{x - \mu}{\sigma} \right) \right) , & \gamma = 0 \end{cases}

1 + \gamma \frac{x - \mu}{\sigma} > 0, \quad  \sigma > 0

\gamma

\mu

\sigma

参数说明：γ\gammaγ:形状参数 (Shape Parameter)，度量尾部分布的厚度。$\gamma$ > 0 表示重尾分布（例如t分布），$\gamma$ < 0 表示轻尾分布 (有上限的分布)，$\gamma$ = 0  对应 Gumbel 分布。μ\muμ:位置参数 (Location Parameter)，决定分布的中心位置。σ\sigmaσ:尺度参数 (Scale Parameter)，决定分布的离散程度，必须大于0。xxx:观测到的残差收益率月度最小值 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Huang, W., Liu, Q., Rhee, S. G., & Wu, F.. (2012). Extreme downside risk and expected stock returns.. Journal of Banking & Finance 36(5), 1492-1502.朱剑涛. (2017). 技术类新 Alpha 因子的批量测试. 东方证券 因子解释尾部风险厚度因子通过拟合残差收益率最小值序列的广义极值分布，提取形状参数。该参数可以有效捕捉收益率分布的尾部特征，尤其关注极端下行风险。当形状参数 $\gamma$ 越大，则表示收益率分布的尾部越厚，极端负收益事件发生的概率越高，风险越大。实证研究表明，在部分市场（如美股市场），该因子与股票的预期收益呈正相关关系，但在A股市场上的表现可能存在差异，需要进一步研究。该因子是对传统波动率因子的一个补充，它关注收益率分布的极端情况，而不是整体的波动水平。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors尾部风险厚度情绪因子因子公式广义极值分布函数 (GEV):H(x;μ,σ,γ)={exp⁡(−(1+γx−μσ)−1γ),γ≠0exp⁡(−exp⁡(−x−μσ)),γ=0 H(x; \mu, \sigma, \gamma) = \begin{cases}  \exp \left( - \left( 1 + \gamma \frac{x - \mu}{\sigma} \right)^{- \frac{1}{\gamma}} \right) , & \gamma \neq 0  \\  \exp \left( - \exp \left( - \frac{x - \mu}{\sigma} \right) \right) , & \gamma = 0 \end{cases} H(x;μ,σ,γ)={exp(−(1+γσx−μ​)−γ1​),exp(−exp(−σx−μ​)),​γ=0γ=0​约束条件:1+γx−μσ>0,σ>0 1 + \gamma \frac{x - \mu}{\sigma} > 0, \quad  \sigma > 0 1+γσx−μ​>0,σ>0其中：γ\gammaγ:形状参数 (Shape Parameter)，度量尾部分布的厚度。$\gamma$ > 0 表示重尾分布（例如t分布），$\gamma$ < 0 表示轻尾分布 (有上限的分布)，$\gamma$ = 0  对应 Gumbel 分布。μ\muμ:位置参数 (Location Parameter)，决...  
DSL公式: H(x; mu, sigma, gamma) = \begincases \exp ( - ( 1 + gamma /x - musigma )**- /1gamma ) , & gamma != 0 \\ \exp ( - \exp ( - /x - musigma ) ) , & gamma = 0 \endcases
1 + gamma /x - musigma > 0, \quad sigma > 0
gamma
mu
sigma  
描述: 因子公式广义极值分布函数 (GEV):H(x;μ,σ,γ)={exp⁡(−(1+γx−μσ)−1γ),γ≠0exp⁡(−exp⁡(−x−μσ)),γ=0 H(x; \mu, \sigma, \gamma) = \begin{cases}  \exp \left( - \left( 1 + \gamma \frac{x - \mu}{\sigma} \right)^{- \frac{1}{\gamm...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/extreme-downside-risk
