# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_084  
因子名称: 每股留存收益  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 波动率, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{RetainedEarnings_{latest}}{CommonSharesOutstanding_{latest}}

RetainedEarnings_{latest}

CommonSharesOutstanding_{latest}

参数说明：RetainedEarningslatestRetainedEarnings_：{latest}RetainedEarningslatest​:最近报告期留存收益：指公司在最近报告期末累计的未分配利润，是企业盈利中扣除已分配给股东的部分后剩余的利润，也称作盈余公积。该数据来源于公司资产负债表。CommonSharesOutstandinglatestCommonSharesOutstanding_{latest}CommonSharesOutstandinglatest​:最近报告期末普通股总股本： 指公司在最近报告期末发行的普通股总数。该数据来源于公司资产负债表或者权益变动表。需要注意区分总股本和流通股本，此处使用的是总股本。因子解释每股留存收益 (REPS) 代表公司每股普通股所对应的累计留存收益，它反映了公司运用盈利进行再投资和发展的能力。该指标数值越高，通常表明公司积累的利润越多，其内部融资能力和未来增长潜力也可能越高，但需要结合行业特性进行分析。投资者可以通过该指标，结合其他财务指标，评估公司的经营状况、盈利能力和风险水平。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。斯蒂芬·佩恩曼. (2017). 公司财务报表分析. 机械工业出版社阿斯沃斯·达莫达兰. (2016). 投资估值. 中国人民大学出版社Related Factors 每股留存收益(Retained Earnings per Share, REPS) 每股未分配利润 (Retained Earnings Per Share) 每股留存收益 每股盈余公积金 每股资本公积金 每股货币资金 分析师一致预期市盈率倒数 股东盈余市值比率 摊薄每股收益 (Diluted EPS) ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子仅供教育和研究目的，不构成投资建议。•在做出任何投资决策之前，请咨询合格的财务顾问。 每股留存收益基础面因子因子公式每股留存收益 (REPS) =RetainedEarningslatestCommonSharesOutstandinglatest \frac{RetainedEarnings_{latest}}{CommonSharesOutstanding_{latest}} CommonSharesOutstandinglatest​RetainedEarningslatest​​其中：RetainedEarningslatestRetainedEarnings_{latest}RetainedEarningslatest​:最近报告期留存收益：指公司在最近报告期末累计的未分配利润，是企业盈利中扣除已分配给股东的部分后剩余的利润，也称作盈余公积。该数据来源于公司资产负债表。CommonSharesOutstandinglatestCommonSharesOutstanding_{latest}CommonSharesOutstandinglatest​:最近报告期末普通股总股本： 指公司在最近报告期末发行的普通股总数。该数据来源于公司资产负债表或者权益变动表。需要注意区分总股本和流通股本，此处使用的是总股本。因子解释每股留存收益 (REPS) 代表公司每股普通股所对应的累计留存收益，它反映了公司运用盈利进行再投资和发展的能力。该指标数值越高，通常表明公司积累的利润越多，其内部融资能力和未来增长潜力也可能越高...  
DSL公式: /RetainedEarnings_latestCommonSharesOutstanding_latest
RetainedEarnings_latest
CommonSharesOutstanding_latest  
描述: ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 每股留存收益 (REPS) 代表公司每股普通股所对应的累计留存收益，它反映了公司运用盈利进行再投资和发展的能力。该指标数值越高，通常表明公司积累的利润越多，其内部融资能力和未来增长潜力也可能越高，但需要结合行业特性进行分析。投资者可以通过该指标，结合其他财务指标，评估公司的经营状况、盈利能力...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/basic-surface-retained-earnings-per-share
