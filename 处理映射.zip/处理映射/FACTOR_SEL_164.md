# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_164  
因子名称: 现金资产占比因子  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 质量, 动量, 成长, 现金资产占比因子, 价值, 量化交易  
原始公式: \frac{\text{现金及现金等价物}_{TTM}}{\frac{\text{期初总资产} + \text{期末总资产}}{2}}

现金及现金等价物_{TTM}

期初总资产

期末总资产

\frac{\text{期初总资产} + \text{期末总资产}}{2}  
DSL公式: /\text现金及现金等价物_TTM/\text期初总资产 + \text期末总资产2
现金及现金等价物_TTM
期初总资产
期末总资产
/\text期初总资产 + \text期末总资产2  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Palazzo, Berardino. (2012). Cash holdings, risk, and expected returns. Journal of Financial Economics Factors DirectoryQuantitative Trading Factors现金资产占总资产比率基础面因子因子公式现金...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/cash-to-total-assets
