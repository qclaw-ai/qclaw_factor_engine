# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_221  
因子名称: 一致预期收益率 (Consensus Target Price Return)  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, return, 质量, 一致预期收益率, 动量, 成长, consensus  
原始公式: R_{consensus} = \frac{\sum_{i=1}^{N} \frac{P_i^e - P}{P}}{N} = \frac{1}{N} \sum_{i=1}^{N} \frac{P_i^e}{P} - 1

P_i^e

R_{consensus}

参数说明：PieP_i：^ePie​:第i家机构发布的股票目标价格，反映该机构对股票未来价格的预期。PPP:月末计算因子时的股票收盘价，作为当前股价的基准。NNN:发布分析师预期目标价格的机构数量，代表参与预测的分析师数量。RconsensusR_{consensus}Rconsensus​:一致预期收益率，表示所有分析师预期目标价格相对于当前价格的平均预期收益率。因子解释该因子计算了所有分析师目标价相对于当前股价的平均收益率，其绝对值越大表示市场预期该股票未来价格波动幅度越大。一致预期收益率的符号（正负）表示市场对股票未来收益的预期方向（上涨或下跌）。；该因子在实践中应注意：  
DSL公式: R_consensus = /SUM_i=1**N /P_i**e - PPN = /1N SUM_i=1**N /P_i**eP - 1
P_i**e
R_consensus  
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors一致预期收益率情绪因子因子公式一致预期收益率公式：Rconsensus=∑i=1NPie−PPN=1N∑i=1NPieP−1 R_{con...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/consistent-expected-return-rate
