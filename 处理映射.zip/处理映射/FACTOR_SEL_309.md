# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_309  
因子名称: 科技关联加权动量因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 动量, 成长, 价值, 量化交易, 规模  
原始公式: TECH_{ijt} = \frac{T_{it} \cdot T_{jt}}{\lVert T_{it} \rVert \lVert T_{jt} \rVert}

TECHRET_{it} = \frac{\sum_{j \neq i} TECH_{ijt} \times RET_{jt}}{\sum_{j \neq i} TECH_{ijt}}

TECH_{ijt}

T_{it}

\lVert

RET_{jt}

参数说明：TECHijtTECH_：{ijt}TECHijt​:为公司i和公司j在第t期的科技关联度，取值范围在[-1, 1]，数值越高表示两公司技术关联度越高。TitT_{it}Tit​:为公司i在第t期所处的N维专利分布向量，N代表专利商标局所定义的科技大类总数。该向量的每个元素代表公司i在过去五年内获得的各类科技专利在对应科技大类中所占的比例。更具体来说，$T_{it}$ = [$t_{i1t}$, $t_{i2t}$, ..., $t_{iNt}$], 其中 $t_{ikt}$  表示公司 i 在 t 时刻， 在第 k 类科技方向的专利占比。该向量的计算考虑了公司在不同技术领域的专利布局情况。∥\lVert ∥T_{it} \rVert$$:表示向量 $T_{it}$ 的欧几里得范数（或称L2范数），即 $\sqrt{T_{it} \cdot T_{it}}$.  用于对专利分布向量进行标准化，避免因为专利数量规模不同而导致的关联度计算偏差。RETjtRET_{jt}RETjt​:为公司j在t期的收益率，通常指股票的算术收益率，即 $RET_{jt} = \frac{P_{jt} - P_{j(t-1)}}{P_{j(t-1)}}$,  其中 $P_{jt}$ 为公司j在t期的股票价格。因子解释该因子利用公司间的技术关联度来构建动量信号。其核心思想是，当一家公司的技术进步具有溢出效应时，与其在技术上关联密切的其他公司也会受到影响，进而导致其股价发生相应变动。具体来说，若一家公司与多家近期收益表现较好的公司具有较高的技术关联度，那么该公司未来的收益可能也会受到正向影响。因此，该因子通过加权平均与目标公司技术关联度高的其他公司的收益率，来捕捉这一技术溢出效应带来的动量效应。这反映了市场对技术创新和溢出效应的定价反应。该因子不仅利用了传统的动量效应，还考虑了技术因素，因此可以提供更丰富的信息，并可能具有更强的预测能力。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Lee, C. M. C., S. T. Sun, R. Wang, and R. Zhang. (2019). Technological Links and Return Predictability. Journal of Financial EconomicsRelated Factors 分析师共识覆盖加权动量 财务相似度加权收益动量 基本面趋势预期...  
DSL公式: TECH_ijt = /T_it * T_jt\lVert T_it \rVert \lVert T_jt \rVert
TECHRET_it = /SUM_j != i TECH_ijt * RET_jtSUM_j != i TECH_ijt
TECH_ijt
T_it
\lVert
RET_jt  
描述: 科技关联度计算公式:TECHijt=Tit⋅Tjt∥Tit∥∥Tjt∥ TECH_{ijt} = \frac{T_{it} \cdot T_{jt}}{\lVert T_{it} \rVert \lVert T_{jt} \rVert} TECHijt​=∥Tit​∥∥Tjt​∥Tit​⋅Tjt​​ 科技关联加权动量因子计算公式:TECHRETit=∑j≠iTECHijt×RETjt∑j≠iTEC...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/technology-momentum
