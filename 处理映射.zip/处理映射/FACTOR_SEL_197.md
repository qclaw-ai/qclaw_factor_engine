# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_197  
因子名称: 流动性调整成交量零值天数比率  
分类: : 流动性指标  
标签: : 流动性, 流动性指标, 质量, 动量, 成长, 价值, 量化交易, 流动性调整成交量零值天数比率  
原始公式: Lm^2 = \frac{\text{NumZeroVolDays}}{\text{Scale}} + \frac{1}{\text{AvgTurnover}} - \frac{2 \times \text{Lookback}}{\text{TotalTradingDays}}

\text{NumZeroVolDays}

\text{Scale}

\text{AvgTurnover}

\text{Lookback}

\text{TotalTradingDays}

参数说明：NumZeroVolDays：\text{NumZeroVolDays}NumZeroVolDays:为过去一段时间（Lookback）内，股票每日成交量为零的交易日数量，反映了股票流动性不足的程度。成交量为零通常意味着该股票在当天缺乏交易活动，表明其流动性较差。Scale\text{Scale}Scale:为缩放因子，等于1。此项为对零值天数进行缩放，避免因子数值过大。此处为1，不进行缩放。AvgTurnover\text{AvgTurnover}AvgTurnover:为过去一段时间（Lookback）内，股票的日平均换手率的倒数。换手率越高，股票的流动性越好，该项数值越低。使用倒数是为了与零值天数形成一致的负向关系。换手率的计算方法通常为每日成交量除以总股本。Lookback\text{Lookback}Lookback:为回溯期长度，单位为月。表示计算因子时所参考的过去时间窗口大小。例如，如果Lookback为3，则表示该因子使用过去3个月的数据进行计算。TotalTradingDays\text{TotalTradingDays}TotalTradingDays:为过去一段时间（Lookback）内的交易日总天数。用于对零值天数和回溯期长度进行标准化。 该因子旨在通过结合成交量为零的交易日数量和平均换手率信息，更全面地捕捉股票的流动性风险。流动性差的股票往往具有更高的风险溢价，因此，该因子可用于识别可能存在超额收益机会的股票。因子值越高，表示股票流动性越差，相应的流动性风险溢价可能越高。该因子可以与其他的因子结合使用，构建更有效的量化选股策略。该因子数值一般为负值，绝对值越大，流动性越差。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 流动性调整成交量零值天数比率流动性因子因子公式流动性调整成交量零值比率 (Lm²):Lm2=NumZeroVolDaysScale+1AvgTurnover−2×LookbackTotalTradingDays Lm^2 = \frac{\text{NumZeroVolDays}}{\text{Scale}} + \frac{1}{\text{AvgTurnover}} - \frac{2 \times \text{Lookback}}{\text{TotalTradingDays}} Lm2=ScaleNumZeroVolDays​+AvgTurnover1​−TotalTradingDays2×Lookback​其中：NumZeroVolDays\text{NumZeroVolDays}NumZeroVolDays:为过去一段时间（Lookback）内，股票每日成交量为零的交易日数量，反映了股票流动性不足的程度。成交量为零通常意味着该股票在当天缺乏交易活动，表明其流动性较差。Scale\text{Scale}Scale:为缩放因子，等于1。此项为对零值天数进行缩放，避免因子数值过大。此处为1，不进行缩放。AvgTurnover\text{AvgTurnover}AvgTurnover:为过去一段时间（Lookback）内，股票的日平均换手率的倒数。换手率越高，股票的流动性越好，该项数值越低。使用倒数是为了与零值天数形成一致的负向关系。换手率的计算方法通常为每日成交量除以总股本。Lookback\text{Lookback}Lookback:为回溯期长度，单位为月。表示计算因子时所参考的过去时间窗口大小。例如，如果Lookback为3，则表示该因子使用过去3个月的数据进行计算。TotalTradingDays\text{TotalTradingDays}TotalTradingDays:为过去一段时间（Lookback）内的交易日总天数。用于对零值天数和回溯期长度进行标准化。因子解释该因子旨在通过结合成交量为零的交易日数量和平均换手率信息，更全面地捕捉股票的流动性风险。流动性差的股票往往具有更高的风险溢价，因此，该因子可用于识别可能存在超额收益机会的股票。因子值越高，表示股票流动性越差，相应的流动性风险溢价可能越高。该因子可以与其他的因子结合使用，构建更有效的量化选股策略。该因子...  
DSL公式: Lm**2 = /\textNumZeroVolDays\textScale + /1\textAvgTurnover - /2 * \textLookback\textTotalTradingDays
\textNumZeroVolDays
\textScale
\textAvgTurnover
\textLookback
\textTotalTradingDays  
描述: 负收益成交额加权非流动性因子 成交额波动率 日均负向成交额占比相对强度 月均换手率因子 平均月度成交额 月度相对换手率溢出 成交额分位数反转强度因子 市值中性化换手率残差 高频波动率路径长度加权非流动性因子 Related Factors 负收益成交额加权非流动性因子 成交额波动率 日均负向成交额占比相对强度 月均换手率因子 平均月度成交额 月度相对换手率溢出 成交额分位数反转强度因子 市值中性化...
因子类型: : 流动性指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/liquidity/liquidity-adjusted-volume
