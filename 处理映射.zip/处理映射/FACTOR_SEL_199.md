# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_199  
因子名称: 日均换手率  
分类: : 技术指标  
标签: : 日均换手率, 流动性, 技术指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \text{TurnoverRate} = \frac{\text{PeriodVolume}}{\text{TotalShares}}

PeriodVolume

TotalShares  
DSL公式: \textTurnoverRate = /\textPeriodVolume\textTotalShares
PeriodVolume
TotalShares  
描述: 日均换手率计算公式:TurnoverRate=PeriodVolumeTotalShares \text{TurnoverRate} = \frac{\text{PeriodVolume}}{\text{TotalShares}} TurnoverRate=TotalSharesPeriodVolume​ 股票在市场中可以自由交易的股份总数，即流通股本。需要注意的是，TotalShares指的是流...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/turnover-rate
