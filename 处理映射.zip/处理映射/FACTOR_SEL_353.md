# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_353  
因子名称: 股息收益率  
分类: : 价值指标  
标签: : 流动性, 质量, 动量, 成长, 股息收益率, 价值, 量化交易, 价值指标  
原始公式: \frac{D_{TTM}}{MV}

D_{TTM}

参数说明：DTTMD_：{TTM}DTTM​:最近12个月（Trailing Twelve Months，TTM）累计派发的现金股息总额。它反映了公司过去一年向股东分配的现金收益总量。该数值的计算通常使用连续四个季度的派息数据累加得出。MVMVMV:股票的总市值，等于当前股票的市场价格乘以已发行股票的总数量。总市值反映了市场对公司整体价值的评估。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors股息收益率价值因子因子公式股息收益率 =DTTMMV \frac{D_{TTM}}{MV} MVDTTM​​其中：DTTMD_{TTM}DTTM​:最近12个月（Trailing Twelve Months，TTM）累计派发的现金股息总额。它反映了公司过去一年向股东分配的现金收益总量。该数值的计算通常使用连续四个季度的派息数据累加得出。MVMVMV:股票的总市值，等于当前股票的市场价格乘以已发行股票的总数量。总市值反映了市场对公司整体价值的评估。因子解释股息收益率是评估股票价值和收益潜力的重要指标。高股息收益率通常被认为是公司估值偏低，有投资吸引力的信号，但投资者需结合公司的基本面、行业前景及财务健康状况综合考量，避免陷入高股息率陷阱。此外，股息收益率还可以用于比较不同股票的投资回报，帮助投资者进行资产配置。 需要注意的是，股息收益率受到市场情绪、宏观经济环境和公司自身经营状况等多方面因素的影响，因此，不应单独将其作为投资决策的依据。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Litzenberger, Robert H., and Krishna Ramaswamy. (1979). The effect of personal taxes and dividends on capital asset prices: Theory and empirical evidence. Journal of Financial EconomicsRelated Factors 市盈率增长率-股息收益率比率 (PEG-DY Ratio) 盈利率 普通股股东权益回报率(TTM) 稀释每股收益同比增长率 (TTM) 摊薄扣非净资产收益率（TTM） 每股货币资金 股东盈余市值比率 60日盈利市值比率变动 市盈率相对盈利增长率 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Litzenberger, Robert H., and Krishna Ramaswamy. (1979). The effect of personal taxes and dividends on capital asset prices: Theory and empirical evidence. Journal of Financial Economics 股息收益率价值因子因子公式股息收益率 =DTTMMV \frac{D_{TTM}}{MV} MVDTTM​​其中：DTTMD_{TTM}DTTM​:最近12个月（Trailing Twelve Months，TTM）累计派发的现金股息总额。它反映了公司过去一年向股东分配的现金收益总量。该数值的计算通常使用连续四个季度的派息数据累加得出。MVMVMV:股票的总市值，等于当前股票的市场价格乘以已发行股票的总数量。总市值反映了市场对公司整体价值的评估。因子解释股息收益率是评估股票价值和收益潜力的重要指标。高股息收益率通常被认为是公司估值偏低，有投资吸引力的信号，但投资者需结合公司的基本面、行业前景及财务健康状况综合考量，避免陷入高股息率陷阱。此外，股息收益率还可以用于比较不同股票的投资回报，帮助投资者进行资产配置。 需要注意的是，股息收益率受到市场情绪、宏观经济环境和公司自身经营状况等多方面因素的影响，因此，不应单独将其作为投资决策的依据。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Litzenberger, Robert H., and Krishna Ramaswamy. (1979). The effect of personal taxes and divid...  
DSL公式: /D_TTMMV
D_TTM  
描述: 因子公式股息收益率 =DTTMMV \frac{D_{TTM}}{MV} MVDTTM​​其中：DTTMD_{TTM}DTTM​:最近12个月（Trailing Twelve Months，TTM）累计派发的现金股息总额。它反映了公司过去一年向股东分配的现金收益总量。该数值的计算通常使用连续四个季度的派息数据累加得出。MVMVMV:股票的总市值，等于当前股票的市场价格乘以已发行股票的总数量。总市值...
因子类型: : 价值指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/value/dividend-rate
