# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_190  
因子名称: 振幅切割动量累积因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 振幅切割动量累积因子, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \text{Momentum}_{AC} = \sum_{i=1}^{n} R_i \quad \text{where} \quad R_i \quad \text{is the daily return, and} \quad i \in \text{lowest A\% amplitude days}, \quad n \quad \text{is the number of lowest A\% amplitude days}.

R_i

参数说明：AA：%A:低振幅交易日占比阈值。表示在回溯窗口期内，选取每日振幅最低的交易日所占的比例，取值范围为[50%, 70%]。此参数体现了对低波动事件的敏感度，数值越大，纳入计算的低振幅交易日越多。nnn:低振幅交易日的数量。即回溯窗口期内，每日振幅排名最低的A%交易日的实际数量，具体数值取决于回溯窗口期的长度和A%的取值。RiR_iRi​:第i个低振幅交易日的股票收益率。通常使用每日收盘价的对数收益率 (log(Close_t) - log(Close_{t-1}))，或者简单收益率 (Close_t - Close_{t-1}) / Close_{t-1} 计算。此收益率代表了该交易日的价格变动幅度。因子解释该因子从交易行为的角度出发，利用日内振幅作为筛选标准，选取波动性较低的交易日。该因子的核心假设是：在低振幅时期内，价格的微小波动可能具有更强的趋势延续性，即呈现动量效应。该研究发现低振幅区间的收益率具有显著的动量效应，而高振幅区间则表现出反转效应。此外，动量效应和反转效应的强度和分布往往是不对称的。该因子通过累加低振幅日的收益率，试图捕捉这种低波动环境下的动量效应，为量化策略提供有效的信号。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。魏建榕, 高鹏, 王志豪. (2020). A股市场中如何构造动量因子?. 开源证券Related Factors 价格分位差振幅因子 成交额分位数反转强度因子 大单成交量价动量 日均负向成交额占比相对强度 日内信息不对称强度因子 20日区间收益率动量/反转因子 收益动量一致性因子 负收益成交额加权非流动性因子 开盘时段主动净买额占比 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 振幅切割动量累积因子计算公式:MomentumAC=∑i=1nRiwhereRiis the daily return, andi∈lowest A% amplitude days,nis the number of lowest A% amplitude days. \text{Momentum}_{AC} = \sum_{i=1}^{n} R_i \quad \text{where} \quad R_i \quad \text{is the daily return, and} \quad i \in \text{lowest A\% amplitude days}, \quad n \quad \text{is the number of lowest A\% amplitude days}. MomentumAC​=i=1∑n​Ri​whereRi​is the daily return, andi∈lowest A% amplitude days,nis the number of lowest A% amplitude days. 价格分位...  
DSL公式: \textMomentum_AC = SUM_i=1**n R_i \quad \textwhere \quad R_i \quad \textis the daily return, and \quad i \in \textlowest A\% amplitude days, \quad n \quad \textis the number of lowest A\% amplitude days.
R_i  
描述: 因子解释该因子从交易行为的角度出发，利用日内振幅作为筛选标准，选取波动性较低的交易日。该因子的核心假设是：在低振幅时期内，价格的微小波动可能具有更强的趋势延续性，即呈现动量效应。该研究发现低振幅区间的收益率具有显著的动量效应，而高振幅区间则表现出反转效应。此外，动量效应和反转效应的强度和分布往往是不对称的。该因子通过累加低振幅日的收益率，试图捕捉这种低波动环境下的动量效应，为量化策略提供有效的信号...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/amplitude-cutting-momentum
