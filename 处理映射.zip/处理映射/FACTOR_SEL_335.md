# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_335  
因子名称: 近五年平均专利寿命月数  
分类: : 基本面指标  
标签: : 流动性, 近五年平均专利寿命月数, 基本面指标, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{1}{N} \sum_{i=1}^{N} \text{PatentLifeMonths}_i

PatentLifeMonths_i  
DSL公式: /1N SUM_i=1**N \textPatentLifeMonths_i
PatentLifeMonths_i  
描述: 第i个发明专利的有效寿命月数。具体计算方法为：如果专利在报告期末之前已经失效，则使用失效日期减去专利授权日期；如果专利在报告期末仍然有效，则使用报告期末日期减去专利授权日期。时间单位为月。 近五年平均专利寿命月数基础面因子因子公式近五年平均专利寿命月数 = 平均值 (  截至报告期末前五年内新授权的有效发明专利寿命月数 )1N∑i=1NPatentLifeMonthsi \frac{1}{N} \...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/average-number-of-months-of-life
