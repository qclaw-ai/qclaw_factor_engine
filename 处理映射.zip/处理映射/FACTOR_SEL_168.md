# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_168  
因子名称: 流动比率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 流动比率, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{\text{Current Assets}}{\text{Current Liabilities}}

\text{Current Assets}

\text{Current Liabilities}  
DSL公式: /\textCurrent Assets\textCurrent Liabilities
\textCurrent Assets
\textCurrent Liabilities  
描述: 流动比率是衡量企业短期偿债能力的指标。该比率越高，表明企业流动资产相对于流动负债的覆盖能力越强，短期偿债能力也越强。一般来说，流动比率大于1被认为是正常的，但不同行业可能存在差异。过高的流动比率可能意味着企业资金利用效率不高，因此需要结合企业的具体情况进行综合分析。此因子在量化投资中常被用作评估企业财务健康状况和风险水平的重要指标。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/current-ratio
