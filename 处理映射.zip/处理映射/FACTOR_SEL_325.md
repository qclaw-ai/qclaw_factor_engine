# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_325  
因子名称: 非操纵性应计利润比率  
分类: : 基本面指标  
标签: : 流动性, 基本面指标, 非操纵性应计利润比率, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \frac{TA_{i,t}}{A_{i,t-1}} = \alpha_{i,1} \frac{1}{A_{i,t-1}} + \alpha_{i,2} \frac{\Delta REV_{i,t}}{A_{i,t-1}} + \alpha_{i,3} \frac{PPE_{i,t}}{A_{i,t-1}} + \epsilon_{i,t}

NDTAC_{i,t} = \alpha_{i,1} \frac{1}{A_{i,t-1}} + \alpha_{i,2} \frac{\Delta REV_{i,t} - \Delta REC_{i,t}}{A_{i,t-1}} + \alpha_{i,3} \frac{PPE_{i,t}}{A_{i,t-1}}

TA_{i,t}

A_{i,t-1}

\Delta REV_{i,t}

\Delta REC_{i,t}

PPE_{i,t}

\alpha_{i,1}, \alpha_{i,2}, \alpha_{i,3}

NDTAC_{i,t}

参数说明：TAi：,tTA_{i,t}TAi,t​:股票i在t期的总应计利润，等于经营活动产生的现金流量与净利润之差，计算细节如下：$TA_{i,t} = 净利润_{i,t} - 经营活动产生的现金流量净额_{i,t}$。Ai,t−1A_{i,t-1}Ai,t−1​:股票i在t-1期的总资产，作为规模因子进行标准化处理，以消除公司规模对总应计利润的影响。该指标可以提高不同规模公司之间应计利润的可比性。ΔREVi,t\Delta REV_{i,t}ΔREVi,t​:股票i在t期相对t-1期的营业收入增加额。该变量反映了公司销售收入的变化，是影响应计利润的一个重要因素。ΔRECi,t\Delta REC_{i,t}ΔRECi,t​:股票i在t期相对t-1期的应收账款增加额。该变量反映了公司信用销售额的变化，是应计利润中与收入相关的部分。在修正的Jones模型中，减去应收账款的变动，可以更精确地剔除因信用销售而产生的应计利润，从而更准确地衡量非操纵性应计利润。PPEi,tPPE_{i,t}PPEi,t​:股票i在t期的期末固定资产总额。该变量代表了公司的长期投资，是影响应计利润的另一个重要因素，固定资产的折旧也会影响应计利润。αi,1,αi,2,αi,3\a...  
DSL公式: /TA_i,tA_i,t-1 = alpha_i,1 /1A_i,t-1 + alpha_i,2 /\Delta REV_i,tA_i,t-1 + alpha_i,3 /PPE_i,tA_i,t-1 + epsilon_i,t
NDTAC_i,t = alpha_i,1 /1A_i,t-1 + alpha_i,2 /\Delta REV_i,t - \Delta REC_i,tA_i,t-1 + alpha_i,3 /PPE_i,tA_i,t-1
TA_i,t
A_i,t-1
\Delta REV_i,t
\Delta REC_i,t
PPE_i,t
alpha_i,1, alpha_i,2, alpha_i,3
NDTAC_i,t  
描述: 股票i在t-1期的总资产，作为规模因子进行标准化处理，以消除公司规模对总应计利润的影响。该指标可以提高不同规模公司之间应计利润的可比性。 修正琼斯模型操纵性应计盈余 应计盈余比率（经标准化） 应计盈余比率（总额） 应计盈余比率 (Accruals Ratio) 应计质量 应计盈余资产比率 (Accruals-to-Assets Ratio) 摊薄扣非净资产收益率（TTM） 股东盈余市值比率 内生无...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/non-manipulative-accruals
