# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_343  
因子名称: 企业价值 (Enterprise Value)  
分类: : 基本面指标  
标签: : 流动性, value, 基本面指标, enterprise, 质量, 动量, 成长, 价值  
原始公式: EV = MC + TD + PS - (CASH + STI)

CASH

STI  
DSL公式: EV = MC + TD + PS - (CASH + STI)
CASH
STI  
描述: 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子Factors DirectoryQuantitative Trading Factors企业价值 (Enterprise Value)基础面因子因子公式企业价值计算公式：EV=MC+TD+PS−(CASH+STI) EV = ...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/enterprise-value
