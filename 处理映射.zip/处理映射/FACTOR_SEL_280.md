# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_280  
因子名称: 净经营资产变动率 (Net Operating Assets Change Rate)  
分类: : 基本面指标  
标签: : 流动性, rate, 基本面指标, net, 质量, assets, 动量, 成长  
原始公式: \frac{NOA_{t} - NOA_{t-1}}{TotalAssets_{t}}

NOA = TotalEquity + FinancialLiabilities - FinancialAssets

NOA = OperatingAssets - OperatingLiabilities

NOA_t

NOA_{t-1}

TotalAssets_t

TotalEquity

FinancialLiabilities

FinancialAssets

OperatingAssets  
DSL公式: /NOA_t - NOA_t-1TotalAssets_t
NOA = TotalEquity + FinancialLiabilities - FinancialAssets
NOA = OperatingAssets - OperatingLiabilities
NOA_t
NOA_t-1
TotalAssets_t
TotalEquity
FinancialLiabilities
FinancialAssets
OperatingAssets  
描述: 净经营资产 (NOA) 计算公式:NOA=TotalEquity+FinancialLiabilities−FinancialAssets NOA = TotalEquity + FinancialLiabilities - FinancialAssets NOA=TotalEquity+FinancialLiabilities−FinancialAssets 该因子衡量企业净经营资产的变动幅度，...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/net-operating-assets-change
