# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_173  
因子名称: 去杠杆化经营现金流/经营性净资产市值  
分类: : 价值指标  
标签: : 经营性净资产市值, 流动性, 去杠杆化经营现金流, 质量, 动量, 成长, 价值, 量化交易  
原始公式: CFO_{TTM}

NMV_{Op}

NMV_{Op} = FinancialLiabilities - FinancialAssets + MarketCap

\frac{CFO_{TTM}}{NMV_{Op}}

CFO_{TTM}

NMV_{Op}

FinancialLiabilities

FinancialAssets

MarketCap  
DSL公式: CFO_TTM
NMV_Op
NMV_Op = FinancialLiabilities - FinancialAssets + MarketCap
/CFO_TTMNMV_Op
CFO_TTM
NMV_Op
FinancialLiabilities
FinancialAssets
MarketCap  
描述: 该因子通过将最近12个月的经营活动现金流量净额（CFO_TTM）除以当日的经营性净资产市值（NMV_Op）来计算，从而衡量每单位经营性净资产市值所产生的经营现金流。其核心逻辑在于：用企业经营活动产生的现金流量来衡量企业创造价值的能力，并与企业的经营性净资产市值进行比较，评估其资本回报率。 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因...
因子类型: : 价值指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/value/value-cash-flow-to-market-value
