# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_071  
因子名称: 月均换手率因子  
分类: : 流动性指标  
标签: : 流动性, 流动性指标, 月均换手率因子, 质量, 动量, 成长, 价值, 量化交易  
原始公式: \text{Monthly Turnover Rate} = \frac{1}{N} \sum_{i=1}^{N} \text{Daily Turnover Rate}_i

\text{Daily Turnover Rate}_i = \frac{\text{Volume}_i}{\text{Circulating Shares}_i}

\text{Monthly Turnover Rate}

\text{N}

\text{Daily Turnover Rate}_i

\text{Volume}_i

\text{Circulating Shares}_i

参数说明：，日度换手率计算公式:Daily Turnover Ratei=VolumeiCirculating Sharesi \text{Daily Turnover Rate}_i = \frac{\text{Volume}_i}{\text{Circulating Shares}_i} Daily Turnover Ratei​=Circulating Sharesi​Volumei​​公式中，各参数的含义如下:Monthly Turnover Rate\text{Monthly Turnover Rate}Monthly Turnover Rate:月均换手率，表示一个自然月内每日换手率的平均值。N\text{N}N:表示当月交易日的总天数。Daily Turnover Ratei\text{Daily Turnover Rate}_iDaily Turnover Ratei​:第i个交易日的日度换手率。Volumei\text{Volume}_iVolumei​:第i个交易日的股票成交量（单位：股）。Circulating Sharesi\text{Circulating Shares}_iCirculating Sharesi​:第i个交易日股票的流通股本（单位：股）。因子解释月均换手率因子旨在量化股票的交易活跃度。较高的月均换手率表明该股票在过去一个月内成交量大，市场参与者可以更方便地买入或卖出，不易产生较大的价格冲击，该股票的流动性较好。相反，较低的月均换手率则表明该股票在过去一个月内成交量较小，交易不活跃，流动性较差，大额交易可能导致股价的波动较大。在量化投资中，投资者通常会使用换手率因子来控制组合的流动性风险，同时也可以将换手率与其他因子结合使用，以构建更有效的投资策略。例如，在构建做多动量因子的投资组合时，通常会选择流动性较好的股票。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。朱剑涛. (2016). 非流动性的度量及其横截面溢价. 东方证券Related Factors 日均换手率 股票换手率 (Turnover Rate) 月度相对换手率溢出 换手率波动率 日均负向成交额占比相对强度 市值中性化换手率残差 日内换手率分布离散度 平均月度成交额 流动性调整成交量零值天数比率 因子公式月均换手率计算公式:Monthly Turnover Rate=1N∑i=1NDaily Turnover Ratei \text{Monthly Turnover Rate} = \frac{1}{N} \sum_{i=1}^{N} \text{Daily Turnover Rate}_i Monthly Turnover Rate=N1​i=1∑N​Daily Turnover Ratei​其中，日度换手率计算公式:Daily Turnover Ratei=VolumeiCirculating Sharesi \text{Daily Turnover Rate}_i = \frac{\text{Volume}_i}{\text{Circulating Shares}_i} Daily Turnover Ratei​=Circulating Sharesi​Volumei​​公式中，各参数的含义如下:Monthly Turnover Rate\text{Monthly Turnover Rate}Monthly Turnover ...  
DSL公式: \textMonthly Turnover Rate = /1N SUM_i=1**N \textDaily Turnover Rate_i
\textDaily Turnover Rate_i = /\textVolume_i\textCirculating Shares_i
\textMonthly Turnover Rate
\textN
\textDaily Turnover Rate_i
\textVolume_i
\textCirculating Shares_i  
描述: 月均换手率因子旨在量化股票的交易活跃度。较高的月均换手率表明该股票在过去一个月内成交量大，市场参与者可以更方便地买入或卖出，不易产生较大的价格冲击，该股票的流动性较好。相反，较低的月均换手率则表明该股票在过去一个月内成交量较小，交易不活跃，流动性较差，大额交易可能导致股价的波动较大。在量化投资中，投资者通常会使用换手率因子来控制组合的流动性风险，同时也可以将换手率与其他因子结合使用，以构建更有效的...
因子类型: : 流动性指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/liquidity/monthly-turnover-rate
