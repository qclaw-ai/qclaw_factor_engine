# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_206  
因子名称: 分析师覆盖率  
分类: : 情绪指标  
标签: : 流动性, 情绪指标, 分析师覆盖率, 质量, 动量, 成长, 价值, 量化交易  
原始公式: 覆盖分析师数

可追踪分析师总数

分析师覆盖率  
DSL公式: 覆盖分析师数
可追踪分析师总数
分析师覆盖率  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Charles M.C. Lee, Eric C. So. (2016). Uncovering expected returns: Information in analyst coverage proxies. Journal of Financial Economics朱剑涛. (2017). 分析师研报的数据特征与 alpha...
因子类型: : 情绪指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/emotion/total-analyst-coverage
