# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_139  
因子名称: 多周期标准化移动平均动量因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 质量, 多周期标准化移动平均动量因子, 动量, 成长, 价值, 量化交易  
原始公式: MA_{j,t,L} = \frac{\sum_{i=d-L+1}^{d} P_{j,i}^{t}}{L}

\tilde{MA}_{j,t,L} = \frac{MA_{j,t,L}}{P_{j,d}^{t}}

P_{j,i}^{t}

MA_{j,t,L}

\tilde{MA}_{j,t,L}

参数说明：Pj：,itP_{j,i}^{t}Pj,it​:股票 j 在第 t 月的第 i 个交易日的收盘价。其中， i 从 d-L+1 到 d。LLL:移动平均计算的时间窗口长度，以交易日为单位，例如3、5、10、20等。 L 代表考察的动量周期。MAj,t,LMA_{j,t,L}MAj,t,L​:股票 j 在第 t 月最后一个交易日 d 时，以 L 个交易日为窗口计算得到的移动平均价格。MA~j,t,L\tilde{MA}_{j,t,L}MA~j,t,L​:股票 j 在第 t 月最后一个交易日 d 时，以 L 个交易日为窗口计算得到的标准化移动平均价格，即移动平均价格除以当日收盘价。 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Chan, Louis K. C., Josef Lakonishok, and Theodore Sougiannis. (2001). The stock market valuation of research and development expenditures. Journal of Finance 股票 j 在第 t 月最后一个交易日 d 时，以 L 个交易日为窗口计算得到的标准化移动平均价格，即移动平均价格除以当日收盘价。 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 该因子的核心思想在于利用多时间尺度上的移动平均价格，来捕捉股票在不同周期内的动量或反转效应。短周期的移动...  
DSL公式: MA_j,t,L = /SUM_i=d-L+1**d P_j,i**tL
\tildeMA_j,t,L = /MA_j,t,LP_j,d**t
P_j,i**t
MA_j,t,L
\tildeMA_j,t,L  
描述: 因子解释该因子通过计算不同时间窗口的移动平均价格，并使用当期收盘价进行标准化，旨在捕捉不同时间尺度下的股票动量效应。由于股票价格的绝对值存在显著差异，直接使用移动平均价格可能导致因子在截面上的可比性较差。标准化处理能够消除这种量级差异，使得不同股票的动量信号具有统一的比较基准。
该因子的核心思想在于利用多时间尺度上的移动平均价格，来捕捉股票在不同周期内的动量或反转效应。短周期的移动平均线（例如L=...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/momentum-factor
