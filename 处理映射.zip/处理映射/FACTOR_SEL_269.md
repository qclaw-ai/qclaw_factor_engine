# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_269  
因子名称: 季度投入资本回报率 (Quarterly ROIC)  
分类: : 质量指标  
标签: : 流动性, 质量指标, 波动率, 季度投入资本回报率, 质量, 动量, 成长, roic  
原始公式: \frac{\text{最近单季度扣非后EBIT} \times (1 - \text{所得税税率})}{\text{期末投入资本}}

\text{扣非后EBIT} = \text{营业利润} + \text{利息费用}

\text{期末投入资本} = \text{股东权益合计} + \text{有息负债}

\text{有息负债} = \text{短期借款} + \text{长期借款} + \text{应付债券} + \text{一年内到期的非流动负债}

扣非后EBIT

所得税税率

期末投入资本  
DSL公式: /\text最近单季度扣非后EBIT * (1 - \text所得税税率)\text期末投入资本
\text扣非后EBIT = \text营业利润 + \text利息费用
\text期末投入资本 = \text股东权益合计 + \text有息负债
\text有息负债 = \text短期借款 + \text长期借款 + \text应付债券 + \text一年内到期的非流动负债
扣非后EBIT
所得税税率
期末投入资本  
描述: 因子解释季度投入资本回报率 (Quarterly ROIC) 是一种衡量公司利用投入资本产生利润的效率的指标，它反映了公司在一个季度内的盈利能力和资本运营效率。该指标通过使用扣除非经常性损益后的息税前利润，更准确地评估了公司核心业务的盈利能力，并使用期末投入资本来衡量投入资本的实际回报。相比年度ROIC，季度ROIC能更及时地反映公司经营状况的短期变化，是评估公司短期经营效率，并为长期趋势分析提供...
因子类型: : 质量指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/quality/single-return-on-invested-capital
