# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_064  
因子名称: 换手率波动率系数  
分类: : 波动率指标  
标签: : 换手率波动率系数, 流动性, 质量, 动量, 成长, 价值, 量化交易, 波动率指标  
原始公式: \frac{std(T_t, T_{t-1}, ..., T_{t-K+1})}{mean(T_t, T_{t-1}, ..., T_{t-K+1})}

\frac{Volume_t}{SharesOutstanding_t}

T_t

Volume_t

SharesOutstanding_t

std(T_t, T_{t-1}, ..., T_{t-K+1})

mean(T_t, T_{t-1}, ..., T_{t-K+1})

参数说明：TtT_tTt：​:t 日的日度换手率。VolumetVolume_tVolumet​:t 日的成交量。SharesOutstandingtSharesOutstanding_tSharesOutstandingt​:t 日的流通股本。KKK:计算换手率波动率系数的时间窗口长度（单位：月）。例如，K=3表示使用最近3个月的日度换手率数据进行计算。std(Tt,Tt−1,...,Tt−K+1)std(T_t, T_{t-1}, ..., T_{t-K+1})std(Tt​,Tt−1​,...,Tt−K+1​):最近K个月日度换手率序列的标准差，衡量换手率的波动程度。mean(Tt,Tt−1,...,Tt−K+1)mean(T_t, T_{t-1}, ..., T_{t-K+1})mean(Tt​,Tt−1​,...,Tt−K+1​):最近K个月日度换手率序列的平均值，衡量这段时间内的平均交易活跃度。 ⚠️ 重要投资风险披露金融市场交易和投资涉及重大亏损风险。任何交易因子或策略的过往表现并不保证未来收益。您不应投资任何您无法承受损失的资金。•所有提供的交易因子仅供教育和研究目的，不构成投资建议。•在做出任何投资决策之前，请咨询合格的财务顾问。 换手率波动率系数波动率因子因子公式换手率波动率系数:std(Tt,Tt−1,...,Tt−K+1)mean(Tt,Tt−1,...,Tt−K+1) \frac{std(T_t, T_{t-1}, ..., T_{t-K+1})}{mean(T_t, T_{t-1}, ..., T_{t-K+1})} mean(Tt​,Tt−1​,...,Tt−K+1​)std(Tt​,Tt−1​,...,Tt−K+1​)​日度换手率 (T_t):VolumetSharesOutstandingt \frac{Volume_t}{SharesOutstanding_t} SharesOutstandingt​Volumet​​其中:TtT_tTt​:t 日的日度换手率。VolumetVolume_tVolumet​:t 日的成交量。SharesOutstandingtSharesOutstanding_tSharesOutstandingt​:t 日的流通股本。KKK:计算换手率波动率系数的时间窗口长度...  
DSL公式: /std(T_t, T_t-1, ..., T_t-K+1)mean(T_t, T_t-1, ..., T_t-K+1)
/Volume_tSharesOutstanding_t
T_t
Volume_t
SharesOutstanding_t
std(T_t, T_t-1, ..., T_t-K+1)
mean(T_t, T_t-1, ..., T_t-K+1)  
描述: 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Chordia, Tarun, Avanidhar Subrahmanyam, and V. Ravi Anshuman. (2001). Trading activity and expected stock returns. Journal of Financial Economics 因子解释换手率波动率系数是衡量股票流动性风险...
因子类型: : 波动率指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/volatility/turnover-rate-variation
