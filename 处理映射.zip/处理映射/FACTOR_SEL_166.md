# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_166  
因子名称: 标准化营业利润(TTM)  
分类: : 基本面指标  
标签: : 流动性, 标准化营业利润, 基本面指标, ttm, 质量, 动量, 成长, 价值  
原始公式: \frac{OperatingProfit_{TTM,t} - \mu(OperatingProfit_{TTM,t-T:t-1})}{\sigma(OperatingProfit_{TTM,t-T:t-1})}

OperatingProfit_{TTM,t}

\mu(OperatingProfit_{TTM,t-T:t-1})

\sigma(OperatingProfit_{TTM,t-T:t-1})

参数说明：OperatingProfitTTM：,tOperatingProfit_{TTM,t}OperatingProfitTTM,t​:t 时刻的滚动过去12个月(Trailing Twelve Months, TTM)营业利润。μ(OperatingProfitTTM,t−T:t−1)\mu(OperatingProfit_{TTM,t-T:t-1})μ(OperatingProfitTTM,t−T:t−1​):过去 T 个季度 (不包含 t 时刻)的滚动过去12个月营业利润的均值。σ(OperatingProfitTTM,t−T:t−1)\sigma(OperatingProfit_{TTM,t-T:t-1})σ(OperatingProfitTTM,t−T:t−1​):过去 T 个季度 (不包含 t 时刻)的滚动过去12个月营业利润的标准差。TTT:回溯历史窗口期，表示回溯的季度数量，默认为6个季度。因子解释该因子衡量当前滚动12个月营业利润相对于其过去T个季度均值的偏离程度，并以过去T个季度的标准差进行标准化。正值表示当前营业利润高于其历史平均水平，负值则表示低于历史平均水平。该因子可以反映公司营业利润的短期波动及增长趋势，并用于衡量公司经营状况的相对变化。在多因子模型中，该因子可以和其他基本面因子组合使用，提高模型对股票收益的解释能力。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。曹春晓. (2018). 基本面因子之经营性标准化成长因子. 申万宏源Related Factors 标准化调整营业利润（TTM） 单季度营业利润率同比变动率 单季度营业利润同比增速 经营利润率（TTM） 有形资本回报率环比增长率 (TTM) 经营效率变动因子 (Operating Efficiency Change Factor) 单季度摊薄净资产收益率同比变动 运营成本利润率 (Operating Cost Profit Margin) 单季度成本费用利润率同比增速 ⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。 Factors DirectoryQuantitative Trading Factors标准化营业利润(TTM)基础面因子因子公式标准化营业利润(TTM):OperatingProfitTTM,t−μ(OperatingProfitTTM,t−T:t−1)σ(OperatingProfitTTM,t−T:t−1) \frac{OperatingProfit_{TTM,t} - \mu(OperatingProfit_{TTM,t-T:t-1})}{\sigma(OperatingProfit_{TTM,t-T:t-1})} σ(OperatingProfitTTM,t−T:t−1​)OperatingProfitTTM,t​−μ(OperatingProfitTTM,t−T:t−1​)​其中:OperatingProfitTTM,tOperatingProfit_{TTM,t}OperatingProfitTTM,t​:t 时刻的滚动过去12个月(Trailing Twelve Months, TTM)营业利润。μ(OperatingProfitTTM,t−T:t−1)\mu(OperatingProfit_{TTM,t-T:t-1})μ(OperatingProfitTTM,t−T:t−1​):过去 T 个季度 (不包含 t 时刻)的滚动过去12个月营业利润的均值。σ(OperatingProfitTTM,t−T:t−1)\sigma(OperatingProfit_{TTM,t-T:t-1})σ(OperatingProfitTTM,t−T:t−1​):过去 T 个季度 (不包含 t 时刻)的滚动过去12个月营业利润的标准差。TTT:回溯历史窗...  
DSL公式: /OperatingProfit_TTM,t - mu(OperatingProfit_TTM,t-T:t-1)sigma(OperatingProfit_TTM,t-T:t-1)
OperatingProfit_TTM,t
mu(OperatingProfit_TTM,t-T:t-1)
sigma(OperatingProfit_TTM,t-T:t-1)  
描述: 标准化营业利润(TTM)基础面因子因子公式标准化营业利润(TTM):OperatingProfitTTM,t−μ(OperatingProfitTTM,t−T:t−1)σ(OperatingProfitTTM,t−T:t−1) \frac{OperatingProfit_{TTM,t} - \mu(OperatingProfit_{TTM,t-T:t-1})}{\sigma(OperatingPr...
因子类型: : 基本面指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/basic-surface/standardized-operating-profit
