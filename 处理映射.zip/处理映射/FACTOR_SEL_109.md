# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_109  
因子名称: 二阶动量加速度因子  
分类: : 技术指标  
标签: : 流动性, 技术指标, 二阶动量加速度因子, 技术分析, 质量, 动量, 成长, 价值  
原始公式: P_{i,t} = alpha + beta t + gamma t^2

P_{i,t}

alpha

beta

gamma

参数说明：Pi：,tP_{i,t}Pi,t​:为股票 i 在 t 时刻的价格，通常使用收盘价，也可以使用其他价格类型，如最高价、最低价或加权平均价等。ttt:为时间序列，表示过去一段时间的等差序列。通常取过去n天的数据，其中 t = 1 表示最近一天， t = 2 表示倒数第二天，以此类推， t = n 表示过去第n天。alphaalphaalpha:二次拟合的常数项，表示拟合曲线的截距，其具体数值与时间序列和价格单位相关，不直接参与动量计算。betabetabeta:二次拟合的一次项系数，表示价格的平均变化速度，反映股票价格的平均动量。其正负号代表价格的涨跌方向，绝对值大小代表动量强弱。$beta$ 的估计值可以通过对历史价格序列进行线性回归得到。gammagammagamma:二次拟合的二次项系数，表示价格变化速度的变化率，即价格的加速度，它体现了动量的变化速度。$gamma$ 的估计值可以通过对历史价格序列进行二次回归得到。具体而言，正的$gamma$ 值表示价格上涨趋势正在加速，负的$gamma$ 值表示价格上涨趋势正在减速（或者价格下跌趋势正在加速）。$gamma$ 的绝对值越大，代表价格趋势变化的加速度越明显。因子解释该因子通过拟合股票过去一段时间的价格走势，并提取二次项系数 $gamma$ 作为二阶动量加速度因子。$gamma$ 反映了价格动量的变化速度。正值表示价格加速上涨，负值表示价格加速下跌（或者上涨趋势减缓），绝对值越大，加速度越明显。该因子可以用于捕捉市场对股票价格趋势的过度反应，从而获取超额收益。实际应用中，通常会结合其他因子和风控指标一起使用，以提高选股效果和降低投资风险。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Chen, L. W., & Yu, H. Y.. (2014). Investor Attention, Visual Price Pattern, and Momentum Investing. 27th Australasian Finance and Banking ConferenceRelated Factors 动量加速度因子 归母净利润加速增长动量因子 双向价格差分自相关性标准化因子 多时域移动平均动量因子 多周期标准化移动平均动量因子 过去K个月累计收益率动量因子 Fama-French三因子模型残差动量 行业领头羊动量溢价因子 CAPM残差动量因子 参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Chen, L. W., & Yu, H. Y.. (2014). Investor Attention, Visual Price Pattern, and Momentum Investing. 27th Australasian Finance and Banking Conference Factors DirectoryQuantitative Trading Factors二阶动量加速度技术因子因子公式股票 i 在 t 时刻的价格 P(i,t) 可以用二次函数进行拟合：Pi,t=alpha+betat+gammat2 P_{i,t} = alpha + beta t + gamma t^2 Pi,t​=alpha+betat+gammat2其中：Pi,tP_{i,t}Pi,t​:为股票 i 在 t 时刻的价格，通常使用收盘价，也可以使用其他价格类型，如最高价、最低价或加权平均价等。ttt:为时间序列，表示过去一段时间的等差序列。通常取过去n天的数据，其中 t = 1 表示最近一天， t = 2 表示倒数第二天，以此类推， t = n 表示过去第n天。alphaal...  
DSL公式: P_i,t = alpha + beta t + gamma t**2
P_i,t
alpha
beta
gamma  
描述: 动量加速度因子 归母净利润加速增长动量因子 双向价格差分自相关性标准化因子 多时域移动平均动量因子 多周期标准化移动平均动量因子 过去K个月累计收益率动量因子 Fama-French三因子模型残差动量 行业领头羊动量溢价因子 CAPM残差动量因子 技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量因子价值因子规模因子技术因子情绪因子基础面因子动量因子波动率因子流动性因子成长因子质量...
因子类型: : 技术指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/tech/acceleration-momentum
