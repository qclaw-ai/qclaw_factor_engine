# Selenium增强版因子（自动导入）

因子ID: FACTOR_SEL_310  
因子名称: 客户加权动量因子  
分类: : 动量指标  
标签: : 流动性, 质量, 动量, 成长, 客户加权动量因子, 量化交易, 价值, 动量指标  
原始公式: CMOM_i^{1M} = \sum_{j=1}^{N_i} w_{ij}^{sales} * MOM_j^{1M}, i = 1, 2, ..., N

CMOM_i^{1M}

N_i

MOM_j^{1M}

w_{ij}^{sales}

参数说明：CMOMi1MCMOM_i：^{1M}CMOMi1M​:代表供应商 i 的客户加权月度动量因子值。NiN_iNi​:代表供应商 i 的客户数量。MOMj1MMOM_j^{1M}MOMj1M​:代表供应商 i 的客户 j 过去一个月的股票收益率 (即月度动量)。计算方式通常为 (当月月末价格 - 上月月末价格) / 上月月末价格。wijsalesw_{ij}^{sales}wijsales​:代表供应商 i 对其客户 j 的销售占比权重。计算方式通常为客户 j 的销售额占供应商 i 总销售额的比例。该权重反映了客户 j 对供应商 i 的重要程度。因子解释客户的股票价格动量会对供应商的股票价格产生影响，这种影响可以通过投资者有限注意力等行为金融学理论进行解释。具体而言，当客户的股票表现良好时，投资者可能会更加关注与该客户相关的供应商，从而推高供应商的股票价格；反之亦然。因此，通过构建客户加权动量因子，可以量化并捕捉这种跨公司之间的动量传递效应。本策略的核心思想是，在客户股票动量表现较好时，买入其供应商；在客户股票动量表现较差时，卖出其供应商，从而利用这种价格联动关系来获取超额收益。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Cohen, L., and A. Frazzini. (2008). Economic Links and Predictable Returns. Journal of Finance 63 (4)Related Factors 多层客户关系加权动量因子 基于中心性加权的客户动量因子 过去K个月累计收益率动量因子 分析师共识覆盖加权动量 财务相似度加权收益动量 行业领头羊动量溢价因子 时间序列动量 (TSMOM) 分析师目标价调整动量因子 多周期标准化移动平均动量因子 Factors DirectoryQuantitative Trading Factors客户加权动量因子-基于销售占比动量因子因子公式CMOMi1M=∑j=1Niwijsales∗MOMj1M,i=1,2,...,N CMOM_i^{1M} = \sum_{j=1}^{N_i} w_{ij}^{sales} * MOM_j^{1M}, i = 1, 2, ..., N CMOMi1M​=j=1∑Ni​​wijsales​∗MOMj1M​,i=1,2,...,N其中：CMOMi1MCMOM_i^{1M}CMOMi1M​:代表供应商 i 的客户加权月度动量因子值。NiN_iNi​:代表供应商 i 的客户数量。MOMj1MMOM_j^{1M}MOMj1M​:代表供应商 i 的客户 j 过去一个月的股票收益率 (即月度动量)。计算方式通常为 (当月月末价格 - 上月月末价格) / 上月月末价格。wijsalesw_{ij}^{sales}wijsales​:代表供应商 i 对其客户 j 的销售占比权重。计算方式通常为客户 j 的销售额占供应商 i 总销售额的比例。该权重反映了客户 j 对供应商 i 的重要程度。因子解释客户的股票价格动量会对供应商的股票价格产生影响，这种影响可以通过投资者有限注意力等行为金融学理论进行解释。具体而言，当客户的股票表现良好时，投资者可能会更加关注与该客户相关的供应商，从而推高供应商的股票价格；反之亦然。因此，通过构建客户加权动量因子，可以量化并捕捉这种跨公司之间的动量传递效应。本策略的核心思想是，在客户股票动量表现较好时，买入其供应商；在客户股票动量表现较差时，卖出其供应商，从而利用这种价格联动关系来获取超额收益。⚠️ 因子风险警告本量化因子仅供教育和研究目的使用。历史表现不保证未来收益。用户须独立验证并承担所有风险。参考资料以下学术和行业资源为这个交易因子提供了额外的背景和验证。Cohen, L., and A. Frazzini. (2008). Economic Links and Predictable Returns. Journal of Finance 63 (4)Related Factors 多层客户关系加权动量因子 基于中心性加权的客户动量因子 过去K个月累计收益率动量因子 分析师共识覆盖加权动量 财务...  
DSL公式: CMOM_i**1M = SUM_j=1**N_i w_ij**sales * MOM_j**1M, i = 1, 2, ..., N
CMOM_i**1M
N_i
MOM_j**1M
w_ij**sales  
描述: 客户加权动量因子-基于销售占比动量因子因子公式CMOMi1M=∑j=1Niwijsales∗MOMj1M,i=1,2,...,N CMOM_i^{1M} = \sum_{j=1}^{N_i} w_{ij}^{sales} * MOM_j^{1M}, i = 1, 2, ..., N CMOMi1M​=j=1∑Ni​​wijsales​∗MOMj1M​,i=1,2,...,N其中：CMOMi1MCM...
因子类型: : 动量指标  
适用股票池: ALL_A  
调仓周期: 日线  
因子方向: long  
来源URL: : https://factors.directory/zh/factors/momentum/momentum-customer-momentum
